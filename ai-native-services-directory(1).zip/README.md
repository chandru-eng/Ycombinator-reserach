# AI-Native Service Companies in the YC Ecosystem

A research directory covering 53 YC companies that deliver **services** (not just software
tools) and use AI to automate or replace parts of traditional service delivery.

## Start here

| Open this | What it is |
|---|---|
| `index.html` | The interactive directory — the main deliverable. **Open this first.** |
| `REPORT.md` | Written deep dives, methodology and per-company analysis |
| `companies.csv` | The 53 companies as a flat spreadsheet |

`index.html` is a self-contained static page. Open it directly in a browser, or serve the
folder over HTTP (see "Running locally"). It needs no build step and no network access for
the core views; company logos load from YC's public CDN when online.

## What's in the directory

Seven views, reachable from the left sidebar:

- **Overview** — what the dataset covers and the headline numbers
- **Directory** — all 53 companies, as a gallery or a sortable table, with search and filters
- **Horizontal** — 23 AI-native services that sell the work for *any* industry rather than one
  niche. Works exactly like the Directory: gallery/table toggle, search, sort and quick
  filters (see below)
- **Spectrum** — companies grouped by how much of the work AI actually does, from
  AI-assisted through predominantly autonomous
- **Compare** — a side-by-side matrix across 11 attributes
- **Insights** — aggregate patterns across the set
- **Method & coverage** — how companies were found, screened and classified, plus
  known gaps

Clicking any company opens a side panel with its workflow steps, what AI does at each step,
evidence strength, and sources.

### Vertical vs horizontal

The main 53-company directory is mostly **vertical**: each company replaces one industry's
process (healthcare administration, legal work, insurance, real estate).

The **Horizontal** view covers the opposite kind. These companies sell the work itself for
*any* business problem in *any* industry — sales development, accounting, customer care,
design, documentation, or building software. They are the "tell us the problem, we'll do the
work" kind rather than "here is a tool".

They fall into three groups:

| Group | What they do | Example |
|---|---|---|
| AI transformation firms | Take over the strategy and build work — the consulting layer, AI-native | Foaster ("The AI-native McKinsey") |
| AI coworkers | Give you AI workers plus the tools to direct them | Backdrop, Dock |
| AI employees | Sell a specific job done for you, in any industry | Artisan (sales), Rational (accounting) |

Clicking any company opens the same kind of side panel as the Directory, with its properties,
what the type means, the verbatim evidence quotes and the source links.

Every company in this view carries a **verbatim quote** from its own site plus a source URL,
so each claim can be checked. Data lives in `horizontal.js` (and `data/horizontal_companies.json`).

Two candidates were deliberately excluded on evidence: **Percept.AI** (domain now parked and
for sale) and **Almanac** (now reads as a personal task app, not a service).

## Running locally

```bash
cd <this folder>
python3 -m http.server 8000 --bind 0.0.0.0
# then open http://localhost:8000/index.html
```

A server is only needed because browsers restrict some features on `file://` URLs. Opening
`index.html` directly works too.

## Reproducing the research

The pipeline that produced the dataset is included:

- `research/` — the scraping and classification stages
  - `fetch_yc.py`, `fetch_batches.py`, `fetch_all.py` — pull company records from YC
  - `fetch_sites.py` — fetch company sites
  - `extract_evidence.py` — extract evidence passages
  - `yc_companies_all.json` — the full 6,349-company source set
  - `candidates_*.json` — the screening stages, broad to shortlist
- `build_part1.py`, `build_part2.py` — assemble `data/companies.json`
- `gen_report.py` — generate `REPORT.md`
- `data/` — the classified dataset (`companies.json`) and its build parts

Note: YC's public search key rotates. Re-scrape it from the YC page HTML before re-running
the fetch scripts.

## Verification tooling

Used to audit the UI for layout, contrast and accessibility:

- `audit.mjs` — renders every view, captures screenshots, reports console errors
- `audit2.mjs` — contrast ratios, tap-target sizes, font sizes
- `audit3.mjs` — responsive checks at 1440 / 1024 / 768 / 390 px
- `final.mjs` — overflow, touch-target and mobile side-panel checks
- `shot.sh` — quick screenshot helper

These need `puppeteer-core` and a Chromium binary:

```bash
npm install
node audit.mjs
```

`node_modules/` is not bundled — run `npm install` to restore it.

## Folder layout

```
index.html          interactive directory (main deliverable)
app.css             styles
app.js              core: state, navigation, directory, side panel
views.js            spectrum / compare / insights / method views
data.js             vertical dataset (53 companies) embedded for the page
horizontal.js       horizontal dataset (23 companies) embedded for the page
REPORT.md           written report
companies.csv       dataset as CSV
data/               classified datasets (JSON), incl. horizontal_companies.json
research/           scraping + classification pipeline
shots/              screenshots of every view and breakpoint
```

`data.js` is generated from `data/companies.json` and embedded so the page works without a
server-side API.

## Caveats

Coverage is a screened subset, not every YC company. Classification into the autonomy bands
rests on public evidence of varying quality; the Method & coverage view states which
companies have thin evidence, and the directory shows an evidence-strength rating per company.
Verify claims against the linked sources before relying on them.
