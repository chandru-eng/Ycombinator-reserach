window.__DATA__ = [
{
"company_name": "Fernstone",
"yc_batch": "Fall 2025",
"website": "https://www.fernstone.com",
"industry": "Insurance",
"service_category": "Commercial insurance brokerage (specialty: security guard / staffing)",
"classification": "ai_enabled_service",
"traditional_service_replaced": "Commercial insurance brokerage and risk-management service for security guard and staffing businesses",
"target_customer": "Small and mid-size security guard companies and staffing firms in the US",
"customer_purchases": "A managed brokerage relationship: carrier placement, policy issuance, certificates of insurance, renewals, claims handling, and a risk advisor",
"ai_workflow": [
{
"step": "Platform intake & quoting",
"description": "Clients request quotes through the Fernstone platform; the site advertises a single platform to issue COIs, track claims, manage policies and stay compliant.",
"execution_mode": "hybrid",
"evidence_url": "https://www.fernstone.com"
},
{
"step": "Automated alerts",
"description": "'Get notified before renewals, expirations, or coverage gaps.' Automated monitoring of policy dates.",
"execution_mode": "ai",
"evidence_url": "https://www.fernstone.com"
},
{
"step": "COI issuance",
"description": "'Create and share certificates instantly.' Self-service certificate generation.",
"execution_mode": "hybrid",
"evidence_url": "https://www.fernstone.com"
},
{
"step": "Risk advisory",
"description": "'Every client gets a dedicated risk advisor who learns your operations and grows with you.'",
"execution_mode": "human",
"evidence_url": "https://www.fernstone.com"
},
{
"step": "Claims handling",
"description": "'File and track claims in one place with real people who follow through fast.'",
"execution_mode": "human",
"evidence_url": "https://www.fernstone.com"
}
],
"human_involvement": "Human-led with AI assistance",
"business_model": "Traditional brokerage economics: carrier commissions plus a managed service relationship; pricing not publicly itemised ('clear pricing, no hidden fees')",
"publicly_reported_metrics": [
"Under 48 hours typical quote turnaround when submission is ready",
"Under 24 hours customer response time",
"100+ security guard customers",
"Licensed in all 50 states",
"$2,500 to $100,000+ premium range"
],
"strength_of_evidence": "medium",
"limitations": [
"No public claim that AI performs underwriting or quoting autonomously",
"Marketing emphasises 'dedicated team' and 'TALK TO HUMANS', i.e. human delivery is central",
"Commission economics not disclosed"
],
"sources": [
"https://www.fernstone.com",
"https://www.fernstone.com/security",
"https://www.ycombinator.com/companies/fernstone"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-assisted",
"spectrum_key": "human_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/2529eaf040180126a595ccd660f42824d36e2dae.png",
"yc_url": "https://www.ycombinator.com/companies/fernstone",
"yc_one_liner": "AI-native insurance brokerage. ",
"team_size": 5,
"locations": "New York City, NY, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "RiskCube",
"yc_batch": "Fall 2024",
"website": "https://riskcube.com",
"industry": "Insurance / Fintech",
"service_category": "Commercial insurance brokerage for startups",
"classification": "ai_native_service",
"traditional_service_replaced": "Startup commercial insurance brokerage and policy review work (D&O, cyber, E&O, GL etc.)",
"target_customer": "Startups closing enterprise deals, raising capital, or passing compliance reviews",
"customer_purchases": "Compared quotes from multiple carriers, purchased coverage, Certificates of Insurance, and managed policies/renewals",
"ai_workflow": [
{
"step": "Coverage requirement intake",
"description": "Founders describe contract/enterprise insurance requirements; RiskCube reviews contract requirements for vendor and client insurance terms.",
"execution_mode": "hybrid",
"evidence_url": "https://riskcube.com"
},
{
"step": "Market scan & quote comparison",
"description": "'Our AI agents and licensed brokers scan the market's top-rated carriers to find the best quotes for your business.'",
"execution_mode": "hybrid",
"evidence_url": "https://riskcube.com"
},
{
"step": "Policy/exclusion review",
"description": "'Without expert review, you won't know what's not covered until it's too late.' Expert review of exclusions is offered as a service.",
"execution_mode": "human",
"evidence_url": "https://riskcube.com"
},
{
"step": "Bind & issue COI",
"description": "'purchase coverage digitally, generate Certificates of Insurance, and manage policies and renewals, all in one place' - often in about a day.",
"execution_mode": "hybrid",
"evidence_url": "https://riskcube.com"
},
{
"step": "Licensed broker sign-off",
"description": "'Speak with a licensed broker'; licensed expertise is presented alongside the agentic platform.",
"execution_mode": "human",
"evidence_url": "https://riskcube.com"
}
],
"human_involvement": "Human-supervised AI execution (AI agents + licensed brokers working together)",
"business_model": "Brokerage commission on placed premium; digital self-serve purchasing plus expert review",
"publicly_reported_metrics": [
"COIs often in about a day",
"Case study: Series A fintech, 60% D&O savings with more coverage limit",
"Example comparison shown: best-fit saves $2,400/yr"
],
"strength_of_evidence": "medium",
"limitations": [
"'AI-native' is the company's own label; the split of AI vs broker work is not quantified",
"The precise automation rate of quoting/binding is undisclosed",
"Commission structure not published"
],
"sources": [
"https://riskcube.com",
"https://riskcube.com/faq",
"https://www.ycombinator.com/companies/riskcube"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/93b1b4fbe4b8807a5770f0fad5c76f3b8685dee9.png",
"yc_url": "https://www.ycombinator.com/companies/riskcube",
"yc_one_liner": "AI commercial insurance brokerage for startups. ",
"team_size": 3,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Fintech",
"Insurance",
"Defense",
"AI"
]
},
{
"company_name": "Strada",
"yc_batch": "Summer 2023",
"website": "https://www.getstrada.com/",
"industry": "Insurance / B2B",
"service_category": "AI agents for insurance operations (carrier / TPA / MGA back office)",
"classification": "ai_native_service",
"traditional_service_replaced": "Outsourced insurance back-office operations: endorsement processing, document processing, carrier portal navigation, COI issuance, claims processing support, billing inquiries",
"target_customer": "Insurance carriers, TPAs and MGAs",
"customer_purchases": "A running operation - agents that execute insurance back-office workflows end to end inside the customer's own systems",
"ai_workflow": [
{
"step": "Workflow ingestion",
"description": "Agents handle endorsement processing, browser automation, document processing and carrier portal navigation.",
"execution_mode": "ai",
"evidence_url": "https://www.getstrada.com/"
},
{
"step": "Carrier portal navigation",
"description": "'Carrier portal navigation' listed as an agent capability, i.e. agents operate external insurer portals.",
"execution_mode": "ai",
"evidence_url": "https://www.getstrada.com/"
},
{
"step": "COI issuance & claims support",
"description": "'COI issuance', 'Claims processing support' executed by agents.",
"execution_mode": "ai",
"evidence_url": "https://www.getstrada.com/"
},
{
"step": "Governance & audit trail",
"description": "'Every agent runs inside the permissions your team already uses, and leaves a record a person can read'; access scoped per role, every action logged.",
"execution_mode": "hybrid",
"evidence_url": "https://www.getstrada.com/"
},
{
"step": "Escalation & handover",
"description": "'Escalation thresholds your team defines'; 'Handover passes the whole transcript to a person'.",
"execution_mode": "human",
"evidence_url": "https://www.getstrada.com/"
},
{
"step": "Testing & QA",
"description": "'Run a change against real scenarios before a customer ever hears it'.",
"execution_mode": "hybrid",
"evidence_url": "https://www.getstrada.com/"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Managed service / operations outsourcing replacement (commercial terms not published)",
"publicly_reported_metrics": [
"70% handle time reduction on every submission that comes in",
"98% data accuracy across policy and document processing",
"Metrics measured across live deployments with carriers, TPAs and MGAs"
],
"strength_of_evidence": "high",
"limitations": [
"Pricing model not disclosed",
"Which lines of business are live vs planned is not fully enumerated",
"'70% handle time reduction' has no published methodology"
],
"sources": [
"https://www.getstrada.com/",
"https://www.getstrada.com/customers",
"https://www.ycombinator.com/companies/strada"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/a1ed3e2a5a9fdba541eb63fd5da473fcbac4b34f.png",
"yc_url": "https://www.ycombinator.com/companies/strada",
"yc_one_liner": "AI agents that run insurance operations",
"team_size": 21,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"SaaS",
"B2B",
"Insurance",
"AI"
]
},
{
"company_name": "Velos",
"yc_batch": "Winter 2023",
"website": "https://www.tryvelos.com",
"industry": "Insurance / B2B",
"service_category": "AI BPO for specialty insurance MGAs and program managers",
"classification": "ai_native_service",
"traditional_service_replaced": "Offshore/captive BPO back-office: servicing, bordereaux reporting, data entry, reconciliation, document review, exception handling",
"target_customer": "Specialty insurance MGAs and program managers",
"customer_purchases": "A managed back-office operation delivered as auditable software-driven workflows",
"ai_workflow": [
{
"step": "Process discovery",
"description": "'Velos learns the nuances of your process and turns them into auditable workflows using AI + code'.",
"execution_mode": "hybrid",
"evidence_url": "https://www.tryvelos.com"
},
{
"step": "Validation against real data",
"description": "'Velos tests against your real data, learns your edge cases, and follows your business rules.'",
"execution_mode": "hybrid",
"evidence_url": "https://www.tryvelos.com"
},
{
"step": "Back-office execution",
"description": "Data entry, reconciliation, document review and exception handling run as automated workflows.",
"execution_mode": "ai",
"evidence_url": "https://www.tryvelos.com"
},
{
"step": "Bordereaux reporting",
"description": "Monthly bordereaux built from 200+ trucking dealership submissions in many formats.",
"execution_mode": "ai",
"evidence_url": "https://www.tryvelos.com/customers"
},
{
"step": "Managed end-to-end delivery",
"description": "'We design, deploy, and manage the automation end to end'.",
"execution_mode": "hybrid",
"evidence_url": "https://www.tryvelos.com"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "AI BPO - sold as managed capacity that reduces the expense ratio vs outsourced headcount (per-unit pricing not published)",
"publicly_reported_metrics": [
"98% accuracy achieved",
"6 days faster reporting time",
"0 added headcount",
"Bordereaux built from 200+ dealerships' data"
],
"strength_of_evidence": "high",
"limitations": [
"Customer metrics are from a single published case study",
"Pricing model not disclosed",
"Human escalation volume not quantified"
],
"sources": [
"https://www.tryvelos.com",
"https://www.tryvelos.com/customers",
"https://www.ycombinator.com/companies/velos"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/1521d60e05f3fa5d010d16b7722a46d4fb586f90.png",
"yc_url": "https://www.ycombinator.com/companies/velos",
"yc_one_liner": "AI BPO for Specialty Insurance MGAs",
"team_size": 3,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Reinforcement Learning",
"Robotic Process Automation",
"Insurance",
"Automation",
"AI"
]
},
{
"company_name": "Veltha",
"yc_batch": "Fall 2026",
"website": "https://veltha.ai/",
"industry": "Insurance",
"service_category": "AI claims adjusting (TPA-style whole-file review)",
"classification": "ai_native_service",
"traditional_service_replaced": "Claims adjuster file review: reading claim documents, checking coverage against policy, drafting the decision",
"target_customer": "Insurers and MGAs (starting with crop insurance)",
"customer_purchases": "A reviewed claim file with a drafted payment recommendation, produced from the raw claim documents",
"ai_workflow": [
{
"step": "Whole-file intake",
"description": "'Photos, video, and scans dropped in and sorted by type' - any data in the file is ingested.",
"execution_mode": "ai",
"evidence_url": "https://veltha.ai/"
},
{
"step": "Policy check",
"description": "'Insured, dates, covered property, cause of loss, notice, and coverage compared against the policy.'",
"execution_mode": "ai",
"evidence_url": "https://veltha.ai/"
},
{
"step": "Error fixing & line checking",
"description": "'takes any data in the file ... checks each line against the policy, fixes the errors, and lines up the decision'.",
"execution_mode": "ai",
"evidence_url": "https://veltha.ai/"
},
{
"step": "Decision drafting",
"description": "'draft the decision for your adjuster to approve'.",
"execution_mode": "hybrid",
"evidence_url": "https://veltha.ai/"
},
{
"step": "Adjuster approval",
"description": "The drafted decision is explicitly 'for your adjuster to approve' - a licensed human retains authority.",
"execution_mode": "human",
"evidence_url": "https://veltha.ai/"
}
],
"human_involvement": "AI-led execution with exception-based human review (adjuster approves the drafted decision)",
"business_model": "Not publicly disclosed; positioned as replacing the cost of claim file handling for carriers/MGAs",
"publicly_reported_metrics": [
"Illustrative crop claim: recommendation of a $27,355.03 payment with the math and each check tied to a source page"
],
"strength_of_evidence": "medium",
"limitations": [
"Illustrative walkthrough, not a customer outcome",
"Pricing undisclosed",
"Whether the adjuster must re-check every file or only flagged ones is not stated",
"Very early (Fall 2026 batch)"
],
"sources": [
"https://veltha.ai/",
"https://www.ycombinator.com/companies/veltha"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/086027e8af9fab6d08a460f136457d84dbf6f354.png",
"yc_url": "https://www.ycombinator.com/companies/veltha",
"yc_one_liner": "AI native TPA starting with workers comp",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Fintech",
"Insurance"
]
},
{
"company_name": "Covera",
"yc_batch": "Fall 2026",
"website": "https://www.covera-agents.com/",
"industry": "Insurance",
"service_category": "AI workspace / service layer for independent insurance agencies",
"classification": "hybrid",
"traditional_service_replaced": "Manual agency work: data entry, submission prep, carrier quoting follow-up, file follow-up, COI handling, renewal remarketing",
"target_customer": "Independent insurance agencies (producers, CSRs, account managers)",
"customer_purchases": "Work done inside the agency's own AMS: submissions prepared, quotes gathered, files synced, and account questions answered",
"ai_workflow": [
{
"step": "Submission intake",
"description": "'New submission Restaurant, BOP' - Covera starts from the first email and prepares the submission.",
"execution_mode": "ai",
"evidence_url": "https://www.covera-agents.com/"
},
{
"step": "Carrier quoting",
"description": "Carrier 1/2/3 quotes gathered and compared, 'Best value: Carrier 2', in ~30 sec in the demo.",
"execution_mode": "ai",
"evidence_url": "https://www.covera-agents.com/"
},
{
"step": "Bind & sync",
"description": "'The client signs, your AMS updates, the summary goes out, servicing takes over.'",
"execution_mode": "hybrid",
"evidence_url": "https://www.covera-agents.com/"
},
{
"step": "Day-to-day account assistant",
"description": "'Your team asks, Covera answers from your AMS, emails and policies, with the source.'",
"execution_mode": "ai",
"evidence_url": "https://www.covera-agents.com/"
},
{
"step": "Human review of binding and advice",
"description": "'Binding, pricing, and advice stay under human review'; 'your team approves every action'.",
"execution_mode": "human",
"evidence_url": "https://www.covera-agents.com/"
},
{
"step": "Renewal remarketing",
"description": "X-date tracking with remarketing quotes at 90/60/30 days.",
"execution_mode": "ai",
"evidence_url": "https://www.covera-agents.com/"
}
],
"human_involvement": "AI-led execution with exception-based human review (agency approves every action)",
"business_model": "Not publicly disclosed on the captured pages; marketed on ROI ('12x ROI after 4 weeks', '10 hrs saved per user per week')",
"publicly_reported_metrics": [
"5 min from request to first quote",
"+20% more new business won",
"10 hrs saved per user every week",
"12x ROI after 4 weeks"
],
"strength_of_evidence": "medium",
"limitations": [
"Company describes itself as an 'AI workspace for independent agencies' - the customer remains the agency, so the end client is still served by the agency",
"Pricing not published",
"Metrics appear to be product claims without published methodology"
],
"sources": [
"https://www.covera-agents.com/",
"https://www.ycombinator.com/companies/covera"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-executed, human-supervised",
"spectrum_key": "human_supervised",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/e711e58f600a9ea3c53a45d934c825989e9b5b57.png",
"yc_url": "https://www.ycombinator.com/companies/covera",
"yc_one_liner": "AI-native OS for insurance brokers",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"AIOps",
"SaaS",
"B2B",
"Insurance",
"AI Assistant"
]
},
{
"company_name": "Balance",
"yc_batch": "Winter 2026",
"website": "https://getbalance.ai",
"industry": "Fintech / B2B",
"service_category": "AI-native accounting and bookkeeping service",
"classification": "ai_native_service",
"traditional_service_replaced": "Outsourced bookkeeping and management accounting: reconciling, categorising, matching documents, month-end close, and signing off the books",
"target_customer": "E-commerce, marketplaces, hospitality and other SMEs needing ongoing bookkeeping (150+ companies cited)",
"customer_purchases": "Audit-ready books and ongoing accounting delivered as a service at a flat monthly price, with a named accountant who signs off",
"ai_workflow": [
{
"step": "Document ingestion",
"description": "'Our own agents reconcile, categorise and match documents against your ledger, continuously through the month.'",
"execution_mode": "ai",
"evidence_url": "https://getbalance.ai"
},
{
"step": "Continuous reconciliation",
"description": "'Books that never fall behind' - reconciliation runs through the month rather than at period end.",
"execution_mode": "ai",
"evidence_url": "https://getbalance.ai"
},
{
"step": "Ledger posting",
"description": "The work is automated; agents categorise and match against the ledger.",
"execution_mode": "ai",
"evidence_url": "https://getbalance.ai"
},
{
"step": "Accountant review & sign-off",
"description": "'The AI does the manual work, our accountants review'; 'A real accountant, every month'; 'Signed off by Merlin'.",
"execution_mode": "human",
"evidence_url": "https://getbalance.ai"
},
{
"step": "Client Q&A",
"description": "Financial assistant ('Bea') answers questions such as 'How did our income and expenses look in Q1?' in seconds.",
"execution_mode": "ai",
"evidence_url": "https://getbalance.ai"
}
],
"human_involvement": "AI-led execution with exception-based human review (accountant signs off monthly)",
"business_model": "Flat monthly fee for accounting as a service ('a flat monthly price'); no hourly billing for questions",
"publicly_reported_metrics": [
"Trusted by 150+ companies",
"Customer quote: 'about a third less than we paid before'",
"'Books ... closed in days'"
],
"strength_of_evidence": "high",
"limitations": [
"'About a third less' is a single customer's recollection, not audited pricing",
"No published headcount-to-client ratio",
"Pricing amount not published on the captured pages"
],
"sources": [
"https://getbalance.ai",
"https://getbalance.ai/how-it-works",
"https://getbalance.ai/faq",
"https://www.ycombinator.com/companies/getbalance"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/1ea7352fed58904bc7cc1f143d4af52e98a52d64.png",
"yc_url": "https://www.ycombinator.com/companies/getbalance",
"yc_one_liner": "Full-Stack AI Accounting",
"team_size": 20,
"locations": "London, England, United Kingdom",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Bear",
"yc_batch": "Summer 2026",
"website": "https://bear.inc/",
"industry": "Fintech / B2B",
"service_category": "AI-native accounting firm",
"classification": "ai_native_service",
"traditional_service_replaced": "Traditional accounting firm engagement (bookkeeping, tax, compliance work performed by a firm)",
"target_customer": "Startups and small businesses that would otherwise hire an accounting firm",
"customer_purchases": "An accounting firm's output delivered by an AI-native firm",
"ai_workflow": [
{
"step": "Firm-level delivery",
"description": "YC one-liner: 'AI-native accounting firm.' The website presents the company as an accounting firm, with a countdown teaser ('Looking for Last Accounting Company?').",
"execution_mode": "hybrid",
"evidence_url": "https://bear.inc/"
}
],
"human_involvement": "Unknown or insufficient evidence",
"business_model": "Not publicly disclosed",
"publicly_reported_metrics": [],
"strength_of_evidence": "low",
"limitations": [
"Website content is a teaser/countdown; no workflow detail is public",
"No pricing or delivery detail",
"Classified AI-native on the strength of the firm framing and YC listing only"
],
"sources": [
"https://bear.inc/",
"https://www.ycombinator.com/companies/bear-inc"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 0,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/cd43428f0afb7d0b7a485fc7f4c167fa916c86eb.png",
"yc_url": "https://www.ycombinator.com/companies/bear-inc",
"yc_one_liner": "AI-native accounting firm.",
"team_size": 3,
"locations": "Helsinki, Finland",
"status": "Active",
"yc_tags": [
"Fintech",
"Finance",
"AI"
]
},
{
"company_name": "Billow AI Labs",
"yc_batch": "Summer 2026",
"website": "https://thebillow.ai/",
"industry": "B2B / Fintech",
"service_category": "AI accounting close automation as a delegated service",
"classification": "ai_native_service",
"traditional_service_replaced": "Manual finance-team close work: bank and credit card reconciliations, accruals, prepaids, fixed assets, payroll and expense entries, multi-entity consolidation, reporting and close workpapers",
"target_customer": "Finance teams running NetSuite, Dynamics 365 or QuickBooks",
"customer_purchases": "The month-end close executed on the customer's own accounting stack, with the team reviewing and approving",
"ai_workflow": [
{
"step": "Learn the close",
"description": "'Built from 3 closes you ran by hand' then 'We take over. We learn your process and build around it.'",
"execution_mode": "hybrid",
"evidence_url": "https://thebillow.ai/"
},
{
"step": "Pull trial balance",
"description": "Close workflow step: 'Pull trial balance' from NetSuite.",
"execution_mode": "ai",
"evidence_url": "https://thebillow.ai/"
},
{
"step": "Match transactions",
"description": "Close workflow step: 'Match transactions' performed by an agent.",
"execution_mode": "ai",
"evidence_url": "https://thebillow.ai/"
},
{
"step": "Send for approval",
"description": "Close workflow step: 'Send for approval' - human review of the agent's output.",
"execution_mode": "human",
"evidence_url": "https://thebillow.ai/"
},
{
"step": "Handled work types",
"description": "'Bank and credit card reconciliations, Accruals, prepaids and fixed assets, Payroll and expense entries, Multi-entity consolidation, Financial reporting and close workpapers.'",
"execution_mode": "ai",
"evidence_url": "https://thebillow.ai/"
}
],
"human_involvement": "AI-led execution with exception-based human review ('Your team reviews and approves')",
"business_model": "Not publicly disclosed; sold as delegating manual finance work to AI on top of the customer's existing tools",
"publicly_reported_metrics": [
"Named customer testimonial from a CPA (Corey Pecoraro)"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing not published",
"No quantified automation rate",
"The customer's own team still reviews and approves, so the service augments rather than fully replaces the finance team"
],
"sources": [
"https://thebillow.ai/",
"https://thebillow.ai/case-studies",
"https://www.ycombinator.com/companies/billow-ai-labs"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/2c42b391e7d2cf9beb71d20f5ce1ed2b4e77e77d.png",
"yc_url": "https://www.ycombinator.com/companies/billow-ai-labs",
"yc_one_liner": "AI-native Accounting Firm that's killing Deloitte",
"team_size": 0,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Finance",
"B2B",
"Workflow Automation",
"AI"
]
},
{
"company_name": "Rational",
"yc_batch": "Summer 2026",
"website": "https://rational.to",
"industry": "Fintech / B2B",
"service_category": "End-to-end agentic accounting service",
"classification": "ai_native_service",
"traditional_service_replaced": "Accounting and tax function performed by accountants or an outsourced accounting firm",
"target_customer": "Startups and enterprise teams",
"customer_purchases": "'End-to-end agentic accounting' - accounting work handed off with instant setup, 24/7 support and experts on demand",
"ai_workflow": [
{
"step": "Automatic onboarding",
"description": "'Hand off your accounting and tax with instant setup / Automatic onboarding, 24/7 support, experts whenever you need.'",
"execution_mode": "hybrid",
"evidence_url": "https://rational.to"
},
{
"step": "Agentic execution",
"description": "'Building AI employees for accounting'; 'End-to-end agentic accounting.'",
"execution_mode": "ai",
"evidence_url": "https://rational.to"
},
{
"step": "Accountant review of consequential decisions",
"description": "'Consequential decisions belong with the accountant, with the source material and context close at hand.'",
"execution_mode": "human",
"evidence_url": "https://rational.to"
},
{
"step": "Team capacity review",
"description": "'We'll walk through how Rational handles the work, where your team reviews, and what a first workflow could look like.'",
"execution_mode": "human",
"evidence_url": "https://rational.to"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Subscription: 'From $399/month with an annual agreement' (startup pricing)",
"publicly_reported_metrics": [
"Startup pricing from $399/month with an annual agreement"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing threshold is public but the full price ladder is not",
"No published automation rate or client count",
"'Zero-human accounting firm' appears in the YC one-liner but the site itself keeps accountants on consequential decisions"
],
"sources": [
"https://rational.to",
"https://rational.to/pricing",
"https://www.ycombinator.com/companies/rational"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/88c9150f7633337a9e66431f2838539b473b583f.png",
"yc_url": "https://www.ycombinator.com/companies/rational",
"yc_one_liner": "First Zero-human Accounting Firm",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Finance",
"B2B",
"Enterprise",
"AI"
]
},
{
"company_name": "Sintropix",
"yc_batch": "Fall 2026",
"website": "https://sintropix.com/",
"industry": "Fintech / B2B",
"service_category": "Autonomous multi-country accounting / finance ERP as a service",
"classification": "ai_native_service",
"traditional_service_replaced": "Multi-country bookkeeping and financial close performed by an accounting firm or in-house finance team",
"target_customer": "Multi-country LATAM startups",
"customer_purchases": "Closed books and financial clarity - 'We close your books and give you financial clarity while you run your business'",
"ai_workflow": [
{
"step": "Automated close",
"description": "YC one-liner: 'Autonomous accounting platform for global companies'; the site describes closing the books while the client runs the business.",
"execution_mode": "ai",
"evidence_url": "https://sintropix.com/"
},
{
"step": "Consolidated reporting",
"description": "Live consolidated snapshot across five countries (cash, ARR, burn, runway) with an assistant ('Erwin') answering questions.",
"execution_mode": "ai",
"evidence_url": "https://sintropix.com/"
}
],
"human_involvement": "Unknown or insufficient evidence",
"business_model": "Not publicly disclosed (ERP/finance service framing)",
"publicly_reported_metrics": [
"Illustrative dashboard: consolidated cash $1.37M, ARR $4.2M, monthly burn $312K, 14 months runway"
],
"strength_of_evidence": "low",
"limitations": [
"Site content captured is largely in Spanish; product detail is thin in the captured pages",
"No pricing",
"No published automation rate or customer outcomes",
"Very early (Fall 2026)"
],
"sources": [
"https://sintropix.com/",
"https://www.ycombinator.com/companies/sintropix"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 0,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/8e0565abd52682e4249720fb4eb646f17fbbdd65.png",
"yc_url": "https://www.ycombinator.com/companies/sintropix",
"yc_one_liner": "Autonomous accounting platform for global companies",
"team_size": 2,
"locations": "Santiago, Santiago Metropolitan Region, Chile",
"status": "Active",
"yc_tags": [
"Fintech",
"B2B",
"AI"
]
},
{
"company_name": "Cifrato",
"yc_batch": "Winter 2025",
"website": "https://cifrato.ai",
"industry": "Fintech / B2B",
"service_category": "Agentic invoice processing, reconciliation and compliance",
"classification": "ai_native_service",
"traditional_service_replaced": "Manual accounting data entry: invoice intake, classification, posting, reconciliation",
"target_customer": "Companies in Colombia/LATAM ('Live in & Trusted by 3.5k+ companies')",
"customer_purchases": "Invoices processed, classified, reconciled and posted into the ERP, with only exceptions surfaced for human review",
"ai_workflow": [
{
"step": "Invoice intake",
"description": "'Pulls invoices straight from the tax authority and email automatically, as they arrive.'",
"execution_mode": "ai",
"evidence_url": "https://cifrato.ai"
},
{
"step": "Classification & posting",
"description": "'Classifies and posts each document against the right accounts, taxes, and cost centers.'",
"execution_mode": "ai",
"evidence_url": "https://cifrato.ai"
},
{
"step": "Reconciliation",
"description": "Agents 'process invoices, reconcile, and keep you compliant.'",
"execution_mode": "ai",
"evidence_url": "https://cifrato.ai"
},
{
"step": "Exception approval",
"description": "'Only the entries that genuinely need a human decision are surfaced for your review.'",
"execution_mode": "human",
"evidence_url": "https://cifrato.ai"
},
{
"step": "ERP sync",
"description": "'Posts the finished entries straight into the ERP your team already runs.'",
"execution_mode": "ai",
"evidence_url": "https://cifrato.ai"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Not publicly disclosed; sold on processing volume and time per invoice",
"publicly_reported_metrics": [
"Live in and trusted by 3.5k+ companies",
"Processed money equal to a stated % of Colombia's GDP",
"Avg time per invoice processed vs 360 sec without Cifrato"
],
"strength_of_evidence": "medium",
"limitations": [
"The published metrics are rendered as animated counters and were not captured as final values",
"Pricing not published",
"Regional focus (Colombia) limits generalisation"
],
"sources": [
"https://cifrato.ai",
"https://www.ycombinator.com/companies/cifrato"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/0bb4c15c8e630dcffec655f29ad07b101afe03c5.png",
"yc_url": "https://www.ycombinator.com/companies/cifrato",
"yc_one_liner": "AI Accountant for Accounting Firms",
"team_size": 17,
"locations": "Bogotá, Bogota, Colombia; Remote",
"status": "Active",
"yc_tags": [
"FinOps",
"SaaS",
"AI"
]
},
{
"company_name": "Overdrive Health",
"yc_batch": "Winter 2026",
"website": "https://overdrive.health",
"industry": "Healthcare",
"service_category": "AI-powered medical billing / revenue cycle service",
"classification": "ai_native_service",
"traditional_service_replaced": "Outsourced medical billing (RCM) service: coding, claim submission, eligibility checks, denials management",
"target_customer": "Medical providers and EMS billing companies",
"customer_purchases": "A revenue-cycle service: claims submitted and followed up so providers get paid more, faster",
"ai_workflow": [
{
"step": "Claim intake and submission",
"description": "Overdrive Health offers AI powered medical billing services, helping providers get paid more money in less time.",
"execution_mode": "ai",
"evidence_url": "https://overdrive.health"
},
{
"step": "Eligibility checks",
"description": "Company reports running hundreds of thousands of eligibility checks.",
"execution_mode": "ai",
"evidence_url": "https://overdrive.health"
},
{
"step": "Automated QA",
"description": "Customer quote: 'I'm totally nerding out over the automated QA.' QA is automated as part of the billing pipeline.",
"execution_mode": "ai",
"evidence_url": "https://overdrive.health"
},
{
"step": "Expert biller oversight",
"description": "'Medical billing combining expert billers and advanced technology'; 'cutting-edge AI technology with expert human oversight'; 'we've built an exceptional team of software engineers and expert billers'.",
"execution_mode": "human",
"evidence_url": "https://overdrive.health/about"
}
],
"human_involvement": "Human-supervised AI execution (AI billing with expert biller oversight)",
"business_model": "Medical billing service economics - typically a percentage of collections (not published)",
"publicly_reported_metrics": [
"Processes over $100 million in claims annually",
"Hundreds of thousands of eligibility checks",
"24/7 support"
],
"strength_of_evidence": "high",
"limitations": [
"The human:AI split is not quantified",
"Pricing/percentage not published",
"'Automated QA' is a customer's phrase, not a documented specification"
],
"sources": [
"https://overdrive.health",
"https://overdrive.health/about",
"https://www.ycombinator.com/companies/overdrive-health"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/9f6d5714c40148baca15996e7bc186b870ee0af4.png",
"yc_url": "https://www.ycombinator.com/companies/overdrive-health",
"yc_one_liner": "AI-Native Medical Billing Services",
"team_size": 1,
"locations": "New York City, NY, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Taiga",
"yc_batch": "Spring 2026",
"website": "https://taigabilling.com",
"industry": "Healthcare",
"service_category": "End-to-end medical billing partner (coding, claims, appeals)",
"classification": "ai_native_service",
"traditional_service_replaced": "Medical billing done in-house or by an external billing company: coding, claim scrubbing, submission, denial appeals",
"target_customer": "Medical practices (EMR-integrated)",
"customer_purchases": "'Taiga handles coding, claims, and appeals end-to-end' - the complete billing loop, with a portal for visibility",
"ai_workflow": [
{
"step": "EHR access",
"description": "'From EHR access to reconciliation, each step feeds the next so payer rules are caught earlier over time.'",
"execution_mode": "hybrid",
"evidence_url": "https://taigabilling.com"
},
{
"step": "Coding and claim checks",
"description": "Agent analysis checks claim fields, adds a missing middle initial, checks the NPPES registry, and applies payer-specific rules ('Required for Aetna 99214-25').",
"execution_mode": "ai",
"evidence_url": "https://taigabilling.com"
},
{
"step": "Claim submission",
"description": "'Ready to submit' after rules analysis; claims move to submission.",
"execution_mode": "ai",
"evidence_url": "https://taigabilling.com"
},
{
"step": "Physician code approval",
"description": "'Every generated code is reviewed and approved by your physicians before submission.'",
"execution_mode": "human",
"evidence_url": "https://taigabilling.com"
},
{
"step": "Denial appeals and reconciliation",
"description": "'They've successfully secured payments on several previously rejected claims by resolving complex issues that had persisted for months.'",
"execution_mode": "hybrid",
"evidence_url": "https://taigabilling.com"
}
],
"human_involvement": "AI-led execution with exception-based human review (physician approves codes)",
"business_model": "Medical billing service (typical RCM percentage-of-collections economics; not published)",
"publicly_reported_metrics": [
"Case study: payments secured on previously rejected claims outstanding for months",
"Named customer testimonials"
],
"strength_of_evidence": "high",
"limitations": [
"Pricing not published",
"Physician approval of generated codes is a hard human step",
"No aggregate accuracy or collection-rate statistics published"
],
"sources": [
"https://taigabilling.com",
"https://taigabilling.com/case-studies",
"https://www.ycombinator.com/companies/taiga"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/b29ba4c51cb703681310648e796b95e0311cd952.png",
"yc_url": "https://www.ycombinator.com/companies/taiga",
"yc_one_liner": "Autonomous medical billing",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Beacon Health",
"yc_batch": "Winter 2026",
"website": "https://www.beaconhealth.ai/",
"industry": "Healthcare",
"service_category": "AI workforce for healthcare operations (EHR-native agents)",
"classification": "ai_native_service",
"traditional_service_replaced": "Healthcare administrative labour performed in the EHR: patient chart navigation, care-gap outreach, documentation",
"target_customer": "Physician practices and health systems",
"customer_purchases": "AI agents deployed into the customer's EHR that execute multi-step administrative workflows",
"ai_workflow": [
{
"step": "Workflow capture",
"description": "'Record any workflow in your EHR and turn it into an AI Agent'; 'Beacon captures every step - navigation, clicks, data entry - and converts it into a reusable, deployable agent.'",
"execution_mode": "human",
"evidence_url": "https://www.beaconhealth.ai/"
},
{
"step": "EHR execution",
"description": "'Beacon navigates and operates real EHR systems, just like a human, to automate complex tasks from end to end.'",
"execution_mode": "ai",
"evidence_url": "https://www.beaconhealth.ai/"
},
{
"step": "Multi-step chaining",
"description": "'agents can perform complex, multi-step workflows over long horizons on any EHR - chaining tasks across patient charts, care gaps, outreach, and documentation without any human hand-offs.'",
"execution_mode": "ai",
"evidence_url": "https://www.beaconhealth.ai/"
},
{
"step": "Human monitoring and intervention",
"description": "'Full visibility into every agent's status, with controls to pause, review, or intervene at any time.'",
"execution_mode": "human",
"evidence_url": "https://www.beaconhealth.ai/"
}
],
"human_involvement": "Predominantly autonomous delivery (agents run without human hand-offs, with pause/review controls)",
"business_model": "Not publicly disclosed; deployed as an AI workforce into existing EHRs",
"publicly_reported_metrics": [
"'Trusted by physicians across the country'",
"HIPAA compliant",
"Works with any EHR"
],
"strength_of_evidence": "medium",
"limitations": [
"'Without any human hand-offs' is a strong autonomy claim without published deployment metrics",
"Pricing not disclosed",
"No published accuracy or volume figures"
],
"sources": [
"https://www.beaconhealth.ai/",
"https://www.ycombinator.com/companies/beacon-health"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 5,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/6d74523afde78b3ac3597bb4170a5287e3f38c36.png",
"yc_url": "https://www.ycombinator.com/companies/beacon-health",
"yc_one_liner": "AI Employees for Primary Care",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Arctic Health",
"yc_batch": "Spring 2026",
"website": "https://arctic.health",
"industry": "Healthcare",
"service_category": "AI-native provider credentialing, enrollment and contracting",
"classification": "ai_native_service",
"traditional_service_replaced": "Provider credentialing and payer enrollment work: documentation gathering, application completion, CAQH maintenance, re-credentialing, payer contracting",
"target_customer": "Medical practices; also telehealth platforms, RCM companies and CVOs (via API/white-label)",
"customer_purchases": "Completed credentialing and enrollment: 'We partner with your practice to manage the entire credentialing process'",
"ai_workflow": [
{
"step": "Documentation gathering",
"description": "'Complete documentation gathering and verification'.",
"execution_mode": "hybrid",
"evidence_url": "https://arctic.health"
},
{
"step": "AI document extraction",
"description": "'AI-powered document extraction and error detection' in the API/white-label offering.",
"execution_mode": "ai",
"evidence_url": "https://arctic.health"
},
{
"step": "Payer application submission",
"description": "'Payer application submission within 2 days'; 'Automated onboarding, submissions, and payer status tracking'.",
"execution_mode": "hybrid",
"evidence_url": "https://arctic.health"
},
{
"step": "Specialist review",
"description": "'Specialist review on every application before submission'; 'our team gathers documentation, completes applications, and submits to payers within 2 days'.",
"execution_mode": "human",
"evidence_url": "https://arctic.health"
},
{
"step": "Re-credentialing and monitoring",
"description": "'Ongoing re-credentialing and monitoring'; 'Appeals and revalidation management'.",
"execution_mode": "hybrid",
"evidence_url": "https://arctic.health"
}
],
"human_involvement": "Human-supervised AI execution (specialist reviews every application)",
"business_model": "Managed service (no setup fees advertised); white-label/API tier for platforms",
"publicly_reported_metrics": [
"2-day payer submission",
"300+ insurance networks",
"All 50 states + DC",
"'No setup fees, no onboarding delays'"
],
"strength_of_evidence": "medium",
"limitations": [
"'Specialist review on every application' means human review is mandatory, not exception-based",
"Pricing not published",
"No published error-rate or volume metrics"
],
"sources": [
"https://arctic.health",
"https://arctic.health/case-studies",
"https://www.ycombinator.com/companies/arctic-health"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/efe1f3eb6680314e6f5fa5d9fc1161df9fcbaa31.png",
"yc_url": "https://www.ycombinator.com/companies/arctic-health",
"yc_one_liner": "AI-native credentialing and contracting for healthcare",
"team_size": 4,
"locations": "New York City, NY, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Health Harbor",
"yc_batch": "Summer 2023",
"website": "https://healthharbor.co/",
"industry": "Healthcare",
"service_category": "AI payor calls - benefit verification and claim follow-up",
"classification": "ai_native_service",
"traditional_service_replaced": "Clinic staff calling insurance companies: benefit verification, claim status follow-up, denial reason calls",
"target_customer": "Healthcare clinics and billing teams",
"customer_purchases": "Completed payor calls: benefit verifications and claim status results returned to the practice",
"ai_workflow": [
{
"step": "Call initiation",
"description": "'Our AI talks to health insurance reps on your behalf, enabling your staff to focus on more complex issues.'",
"execution_mode": "ai",
"evidence_url": "https://healthharbor.co/"
},
{
"step": "IVR navigation and hold",
"description": "'Our AI will navigate IVR, wait on hold and then transfer to your staff to complete the call' (Copilot mode).",
"execution_mode": "ai",
"evidence_url": "https://healthharbor.co/"
},
{
"step": "Benefit verification",
"description": "'We check if a patient's plan is active, deductibles/maximums, and coverage for specific procedure codes - details often unavailable on the insurer's website.'",
"execution_mode": "ai",
"evidence_url": "https://healthharbor.co/"
},
{
"step": "Claim follow-up",
"description": "'We ask for the current status (not found, pending, paid, or denied), and can follow up on why the claim was denied.'",
"execution_mode": "ai",
"evidence_url": "https://healthharbor.co/"
},
{
"step": "Staff action on results",
"description": "'Your team can then focus on fixing or adjusting the claim to recover payments left on the table.'",
"execution_mode": "human",
"evidence_url": "https://healthharbor.co/"
}
],
"human_involvement": "AI-led execution with exception-based human review (two modes: fully automated, and Copilot which transfers to staff)",
"business_model": "'Pay per call based on complexity'; custom volume pricing with a dedicated account manager for larger customers",
"publicly_reported_metrics": [
"99% accuracy of fully automated results",
"'More affordable than outsourcing to call centers'"
],
"strength_of_evidence": "high",
"limitations": [
"'99% accuracy' has no published methodology",
"Pricing is per-call but rates are not published",
"The Copilot mode deliberately leaves the human on the call"
],
"sources": [
"https://healthharbor.co/",
"https://healthharbor.co/pricing",
"https://healthharbor.co/product",
"https://www.ycombinator.com/companies/health-harbor"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/707952491ce6520207a9fc042912ea6190fc34a5.png",
"yc_url": "https://www.ycombinator.com/companies/health-harbor",
"yc_one_liner": "Using generative AI to call insurance for healthcare clinics",
"team_size": 4,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"SaaS",
"B2B",
"Healthcare IT",
"Billing",
"AI"
]
},
{
"company_name": "MochaCare",
"yc_batch": "Winter 2026",
"website": "https://www.mochacare.com/",
"industry": "Healthcare",
"service_category": "Agentic management service for home care organisations",
"classification": "ai_native_service",
"traditional_service_replaced": "Home-care agency back-office administration: caregiver recruiting, interviews, offer letters, document collection, scheduling and follow-up",
"target_customer": "Home care agencies",
"customer_purchases": "'AI tools and hands-on services for home care agencies' - the admin work executed on their behalf",
"ai_workflow": [
{
"step": "AI interview scheduling",
"description": "'One ATS for AI and human interviews, offer letters, document collection, and automated caregiver support.'",
"execution_mode": "ai",
"evidence_url": "https://www.mochacare.com/"
},
{
"step": "Routine follow-up",
"description": "'AI handles routine follow-ups and keeps your team in the loop'; 'Calls, texts, emails, and tasks together.'",
"execution_mode": "ai",
"evidence_url": "https://www.mochacare.com/"
},
{
"step": "Automated caregiver support",
"description": "'AI automations move work forward' across recruiting and support workflows.",
"execution_mode": "ai",
"evidence_url": "https://www.mochacare.com/"
},
{
"step": "Human escalation",
"description": "'A human steps in where it matters.'",
"execution_mode": "human",
"evidence_url": "https://www.mochacare.com/"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Not publicly disclosed ('Products / Working with us / Plans' pages exist but pricing was not captured)",
"publicly_reported_metrics": [
"$2.4M raised",
"Named customer testimonials (Senior Helpers, Assisting Hands)"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing plans not captured",
"No quantified automation rate",
"Named customers are testimonials rather than published case-study metrics"
],
"sources": [
"https://www.mochacare.com/",
"https://www.mochacare.com/about",
"https://www.ycombinator.com/companies/mochacare"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/8f0d0e6f741a56de1899f97dfa05142761a40372.png",
"yc_url": "https://www.ycombinator.com/companies/mochacare",
"yc_one_liner": "Agentic Management Service for Care Organizations",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Altair Health",
"yc_batch": "Fall 2026",
"website": "https://www.altair-health.com",
"industry": "Healthcare",
"service_category": "AI medical billing with a free EHR (behavioral health)",
"classification": "ai_native_service",
"traditional_service_replaced": "Behavioral health billing: eligibility verification, claim submission, prior authorisation, patient billing, denial appeals",
"target_customer": "Behavioral health providers",
"customer_purchases": "A free EHR plus AI billing that 'gets you paid': coverage confirmation, claim submission, prior auths, patient bills, appeals",
"ai_workflow": [
{
"step": "Coverage confirmation",
"description": "Live counter shows 'Confirmed coverage on 38 visits'.",
"execution_mode": "ai",
"evidence_url": "https://www.altair-health.com"
},
{
"step": "Claim submission",
"description": "Live counter: 'Submitted 187 claims'.",
"execution_mode": "ai",
"evidence_url": "https://www.altair-health.com"
},
{
"step": "Payment posting",
"description": "Live counter: 'Posted $18,412 in payments'.",
"execution_mode": "ai",
"evidence_url": "https://www.altair-health.com"
},
{
"step": "Prior authorisations",
"description": "Live counter: 'Filed 12 prior authorizations'.",
"execution_mode": "ai",
"evidence_url": "https://www.altair-health.com"
},
{
"step": "Patient billing and appeals",
"description": "Live counters: 'Sent 96 patient bills', 'Appealed 34 denials'.",
"execution_mode": "ai",
"evidence_url": "https://www.altair-health.com"
}
],
"human_involvement": "Unknown or insufficient evidence",
"business_model": "Free EHR with AI billing built in (billing monetisation implied; not published)",
"publicly_reported_metrics": [
"Illustrative live counters: 38 visits coverage-confirmed, 187 claims submitted, $18,412 payments posted, 12 prior auths filed, 96 patient bills sent, 34 denials appealed"
],
"strength_of_evidence": "low",
"limitations": [
"The counters appear to be a product demo, not audited customer results",
"No pricing model published",
"Human involvement not described",
"Very early (Fall 2026)"
],
"sources": [
"https://www.altair-health.com",
"https://www.ycombinator.com/companies/altair-health"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 0,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/54aa8da5f81192f8484dda70b284e56e5b9cb6a6.png",
"yc_url": "https://www.ycombinator.com/companies/altair-health",
"yc_one_liner": "Stripe for medical billing",
"team_size": 4,
"locations": "Austin, TX, USA",
"status": "Active",
"yc_tags": [
"Health Tech",
"Healthcare",
"AI"
]
},
{
"company_name": "Patientdesk.ai",
"yc_batch": "Winter 2026",
"website": "https://patientdesk.ai/",
"industry": "Healthcare",
"service_category": "AI receptionist, scheduling and AI-native practice management for dental",
"classification": "hybrid",
"traditional_service_replaced": "Dental front-desk work: answering calls, booking appointments, patient follow-up, plus practice-management software",
"target_customer": "Dental practices",
"customer_purchases": "A bundle: AI receptionist, online booking, patient follow-ups, marketing, and an AI-native PMS - 'all under one roof'",
"ai_workflow": [
{
"step": "Call answering and booking",
"description": "'Incoming patient call Answered - \"I'd like to book a check-up.\" - Booked into your PMS'.",
"execution_mode": "ai",
"evidence_url": "https://patientdesk.ai/"
},
{
"step": "Online booking",
"description": "'Patients book from your website, straight into your schedule.'",
"execution_mode": "ai",
"evidence_url": "https://patientdesk.ai/"
},
{
"step": "Proactive PMS recommendations",
"description": "'Tomorrow has 3.5 h of open chair time' with Approve/Edit - the PMS 'proposes the next action'.",
"execution_mode": "hybrid",
"evidence_url": "https://patientdesk.ai/"
},
{
"step": "Patient follow-up",
"description": "'Call answering and patient follow-up' handled by the AI receptionist.",
"execution_mode": "ai",
"evidence_url": "https://patientdesk.ai/"
}
],
"human_involvement": "Human-supervised AI execution (staff approve the PMS's proposed actions)",
"business_model": "Published pricing page (practice-level subscription); bundles scheduling, AI receptionist, follow-ups, booking, PMS, marketing, review automation and SEO",
"publicly_reported_metrics": [
"Named dental practice testimonials"
],
"strength_of_evidence": "medium",
"limitations": [
"Sold as software (PMS plus AI receptionist) rather than a pure service - the practice still operates it",
"Published price amounts were not captured",
"No published automation rate"
],
"sources": [
"https://patientdesk.ai/",
"https://patientdesk.ai/pricing",
"https://www.ycombinator.com/companies/patientdeskai"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-executed, human-supervised",
"spectrum_key": "human_supervised",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/61038c47ba4c75630383f542220a03d2ed7b93d4.png",
"yc_url": "https://www.ycombinator.com/companies/patientdeskai",
"yc_one_liner": "AI front & back office agent for dental practices ",
"team_size": 5,
"locations": "",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Allia Health",
"yc_batch": "Summer 2026",
"website": "https://allia.health/",
"industry": "Healthcare",
"service_category": "AI-native medical group for mental health",
"classification": "ai_native_service",
"traditional_service_replaced": "Behavioral health practice operations: documentation, billing/claims, payer rules compliance",
"target_customer": "Behavioral health practices (solo, group, multi-site) - therapy, psychiatry, TMS, medication management",
"customer_purchases": "A practice platform that runs documentation and billing, plus access to a medical group structure",
"ai_workflow": [
{
"step": "AI documentation",
"description": "'AI documentation and automation handling the busywork'.",
"execution_mode": "ai",
"evidence_url": "https://allia.health/"
},
{
"step": "Claims processing",
"description": "'98%+ first-time claims acceptance - practices get paid faster, with far fewer denials.'",
"execution_mode": "ai",
"evidence_url": "https://allia.health/"
},
{
"step": "Multi-state and payer rule handling",
"description": "'A flexible platform that handles multi-state rules, varied payer mixes, different credentials, and hybrid care models'.",
"execution_mode": "ai",
"evidence_url": "https://allia.health/"
}
],
"human_involvement": "Unknown or insufficient evidence",
"business_model": "Not publicly disclosed on the captured pages",
"publicly_reported_metrics": [
"6 hours saved per clinician each week on average",
"98%+ first-time claims acceptance"
],
"strength_of_evidence": "medium",
"limitations": [
"'Medical group' framing suggests a clinical service entity, but clinician delivery sits outside the AI-native service thesis",
"Pricing not captured",
"Human involvement not described"
],
"sources": [
"https://allia.health/",
"https://allia.health/about",
"https://www.ycombinator.com/companies/allia-health"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 0,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/3d6f40f216c0da6b1f8b4caa594f59a5b194dd82.png",
"yc_url": "https://www.ycombinator.com/companies/allia-health",
"yc_one_liner": "AI-Native Medical Group for Mental Health",
"team_size": 3,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Healthcare",
"Mental Health",
"AI"
]
},
{
"company_name": "AgentCollect",
"yc_batch": "Summer 2023",
"website": "https://www.agentcollect.com",
"industry": "B2B / Fintech",
"service_category": "AI collections agency (B2B debt collection)",
"classification": "ai_native_service",
"traditional_service_replaced": "Third-party B2B debt collection agency or outsourced BPO collections team; and manual in-house AR chasing",
"target_customer": "B2B companies with overdue receivables",
"customer_purchases": "Recovered receivables - an AI billing concierge on every customer account that contacts, negotiates and collects",
"ai_workflow": [
{
"step": "Account ingestion",
"description": "'Upload a spreadsheet or connect your billing/ERP' - accounts enter the system from the customer's billing stack.",
"execution_mode": "ai",
"evidence_url": "https://www.agentcollect.com"
},
{
"step": "Contact discovery",
"description": "'We find who to contact' - locating the right person at the debtor.",
"execution_mode": "ai",
"evidence_url": "https://www.agentcollect.com"
},
{
"step": "Multichannel outreach",
"description": "Voice + email + SMS outreach, with an AI agent answering customers 'the moment they ask'.",
"execution_mode": "ai",
"evidence_url": "https://www.agentcollect.com"
},
{
"step": "Negotiation",
"description": "Agents negotiate payment plans ('I can pay, but I need a smaller first installment' - agent presents payment options).",
"execution_mode": "ai",
"evidence_url": "https://www.agentcollect.com"
},
{
"step": "Dispute routing",
"description": "'When a customer disputes, calls on that account stop and the dispute can be routed to your team.'",
"execution_mode": "human",
"evidence_url": "https://www.agentcollect.com"
},
{
"step": "Compliance guardrails",
"description": "State-by-state compliance guides for Reg F, FDCPA and TCPA govern the outreach.",
"execution_mode": "hybrid",
"evidence_url": "https://www.agentcollect.com"
}
],
"human_involvement": "AI-led execution with exception-based human review (disputes routed to the client's team)",
"business_model": "Collections economics - a contingency/commission share of what is recovered, plus a comparison against 'your outsourced agency or BPO'",
"publicly_reported_metrics": [
"23M+ borrowers managed",
"2M+ payments recovered",
"USD $11M+ recovered",
"'15 minutes to finalize the last 10%' of agent setup"
],
"strength_of_evidence": "high",
"limitations": [
"The exact fee/commission percentage is not published",
"Whether all negotiation is autonomous or some is agent-assisted is not stated",
"Regulatory licensing per state is implied by the compliance content but not enumerated"
],
"sources": [
"https://www.agentcollect.com",
"https://www.agentcollect.com/how-it-works",
"https://www.agentcollect.com/customers",
"https://www.ycombinator.com/companies/agentcollect"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/2e7fa66d4491c66a8637435f8ec4ca509a67f236.png",
"yc_url": "https://www.ycombinator.com/companies/agentcollect",
"yc_one_liner": "B2B debt collection powered by AI agents",
"team_size": 42,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Fintech",
"B2B",
"Enterprise Software",
"AI"
]
},
{
"company_name": "Callbook AI",
"yc_batch": "Summer 2026",
"website": "https://callbook.ai",
"industry": "Fintech / B2B",
"service_category": "AI collections agency for late-stage portfolios",
"classification": "ai_native_service",
"traditional_service_replaced": "Debt collection agency / collections call centre work on late-stage portfolios",
"target_customer": "Lenders and debt owners with late-stage portfolios",
"customer_purchases": "Collections outcomes - AI agents that locate, contact and negotiate with each borrower",
"ai_workflow": [
{
"step": "Borrower location",
"description": "'Our AI agents locate, contact, and negotiate with each borrower, adapted to your strategy and measured against your current results.'",
"execution_mode": "ai",
"evidence_url": "https://callbook.ai"
},
{
"step": "Multichannel conversation",
"description": "'Calls, SMS, and email in one continuous conversation'; 'Every channel contributes to the customer history.'",
"execution_mode": "ai",
"evidence_url": "https://callbook.ai"
},
{
"step": "Negotiation and payment plans",
"description": "Agent conversation example ends with 'A new payment plan is ready.'",
"execution_mode": "ai",
"evidence_url": "https://callbook.ai"
},
{
"step": "Continuous improvement loop",
"description": "'Incidents, tests, customer requirements, and system changes feed back into the control environment.'",
"execution_mode": "hybrid",
"evidence_url": "https://callbook.ai"
}
],
"human_involvement": "Predominantly autonomous delivery (agents locate, contact and negotiate; the site advertises no human agents in the loop)",
"business_model": "Collections contingency economics (not published); measured 'against your current results'",
"publicly_reported_metrics": [
"23M+ borrowers managed",
"2M+ payments recovered",
"USD $11M+ recovered",
"'Enterprise-grade security and controls'"
],
"strength_of_evidence": "medium",
"limitations": [
"Metrics mirror AgentCollect's figures and no methodology is published",
"No pricing or commission rate disclosed",
"Whether human collectors supervise calls is not stated",
"Very early (Summer 2026)"
],
"sources": [
"https://callbook.ai",
"https://callbook.ai/security",
"https://www.ycombinator.com/companies/callbook-ai"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 5,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/a36bdaf62a231431b2534670e18c255d0347c7cd.png",
"yc_url": "https://www.ycombinator.com/companies/callbook-ai",
"yc_one_liner": "AI collections agency for late stage portfolios",
"team_size": 7,
"locations": "San Francisco, CA, USA; Remote",
"status": "Active",
"yc_tags": [
"AI"
]
},
{
"company_name": "Wingman Law",
"yc_batch": "Fall 2026",
"website": "https://www.wingmanlaw.com",
"industry": "Legal",
"service_category": "AI-native personal injury law firm",
"classification": "ai_native_service",
"traditional_service_replaced": "Personal injury law firm services for car accident claimants (case evaluation, demand, negotiation with insurers)",
"target_customer": "Personal injury claimants (California), including non-English speakers (Korean, Spanish, Vietnamese)",
"customer_purchases": "Legal representation on contingency: 'No legal fees unless you win'",
"ai_workflow": [
{
"step": "Free case review",
"description": "'Free Case Review' intake for prospective claimants.",
"execution_mode": "hybrid",
"evidence_url": "https://www.wingmanlaw.com"
},
{
"step": "Case data systems",
"description": "'We turn claim data, policy language, medical evidence, and insurer behavior into systems that help our attorneys build sharper cases and challenge low offers.'",
"execution_mode": "ai",
"evidence_url": "https://www.wingmanlaw.com"
},
{
"step": "Case outcome modelling",
"description": "'Gathering the case constellation' - an interface showing injury/outcome/year drawn from publicly available litigated-case data.",
"execution_mode": "ai",
"evidence_url": "https://www.wingmanlaw.com"
},
{
"step": "Attorney case work",
"description": "Attorneys build cases and challenge low offers; the firm describes itself as 'Firm engineered to fight insurance'.",
"execution_mode": "human",
"evidence_url": "https://www.wingmanlaw.com"
}
],
"human_involvement": "Human-led with AI assistance (attorneys remain the delivery mechanism; AI supplies case analytics)",
"business_model": "Contingency fee: 'No upfront attorney's fees, and we only collect a fee if we recover money for you'",
"publicly_reported_metrics": [
"Multilingual intake (Korean, Spanish, Vietnamese)",
"No upfront fees"
],
"strength_of_evidence": "medium",
"limitations": [
"The site is a marketing/lead-gen surface; the AI stack is not described in operational detail",
"No published outcome or settlement metrics",
"Very early (Fall 2026)",
"Legal services are regulated; attorney licensing detail is not published on the captured pages"
],
"sources": [
"https://www.wingmanlaw.com",
"https://www.ycombinator.com/companies/wingman-law"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/2127606306fa68c80f746873e01b87bbfb011128.png",
"yc_url": "https://www.ycombinator.com/companies/wingman-law",
"yc_one_liner": "AI-native personal injury law firm",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Generative AI",
"Legal",
"LegalTech"
]
},
{
"company_name": "Praxis",
"yc_batch": "Fall 2026",
"website": "https://runpraxis.ai",
"industry": "Legal",
"service_category": "AI agents running law firm operations (intake to collections)",
"classification": "ai_native_service",
"traditional_service_replaced": "Law firm administrative operations: lead intake and qualification, client data and document collection, matter tracking, invoicing and collections",
"target_customer": "Law firms (founders and managing attorneys)",
"customer_purchases": "'Praxis is the AI that runs your law firm, from first inquiry to paid invoice' - the admin operation executed end to end",
"ai_workflow": [
{
"step": "Lead intake and qualification",
"description": "'Every inquiry is answered in minutes and qualified against your rules'; 'Every lead answered, qualified and signed'.",
"execution_mode": "ai",
"evidence_url": "https://runpraxis.ai"
},
{
"step": "Client data and document collection",
"description": "'Client data and documents, collected and verified'.",
"execution_mode": "ai",
"evidence_url": "https://runpraxis.ai"
},
{
"step": "Matter tracking",
"description": "'Every matter moving, and your client sees it live'.",
"execution_mode": "ai",
"evidence_url": "https://runpraxis.ai"
},
{
"step": "Invoicing and collections",
"description": "'Invoices sent and chased, revenue collected'.",
"execution_mode": "ai",
"evidence_url": "https://runpraxis.ai"
},
{
"step": "Lawyer supervision",
"description": "'Agents do the admin end to end, and the lawyer supervises and approves every step'; 'Praxis does the work around the client, so your team can stay on the law.'",
"execution_mode": "human",
"evidence_url": "https://runpraxis.ai"
}
],
"human_involvement": "AI-led execution with exception-based human review (lawyer supervises and approves every step)",
"business_model": "Not publicly disclosed ('Get early access'); sold as replacing law-firm admin headcount",
"publicly_reported_metrics": [
"Named testimonials from law firm founders (transactional law firm, New York)"
],
"strength_of_evidence": "medium",
"limitations": [
"'Approves every step' means human review is pervasive, not exception-based in practice",
"Pricing not published",
"Very early (Fall 2026)",
"Does not perform legal work itself - it runs the firm's operations"
],
"sources": [
"https://runpraxis.ai",
"https://runpraxis.ai/security",
"https://www.ycombinator.com/companies/praxis"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/aac3b9688bfcfe828ca1449c50d9d85d7e55ad89.png",
"yc_url": "https://www.ycombinator.com/companies/praxis",
"yc_one_liner": "AI agents that run law firm operations.",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Legal",
"LegalTech",
"AI"
]
},
{
"company_name": "General Legal",
"yc_batch": "Winter 2026",
"website": "https://general.legal",
"industry": "Legal",
"service_category": "AI law firm for high-growth companies",
"classification": "ai_native_service",
"traditional_service_replaced": "Outside counsel and in-house legal work for startups and scaleups: NDAs, commercial contracts, employment, fintech/payments terms",
"target_customer": "Startups, scaleups and enterprises (500+ companies cited)",
"customer_purchases": "Legal work product delivered by a law firm: contracts, redlines, memos, advisory",
"ai_workflow": [
{
"step": "Legal intake",
"description": "'Start a matter' intake on the firm's site.",
"execution_mode": "hybrid",
"evidence_url": "https://general.legal"
},
{
"step": "Drafting and review",
"description": "Client quote: 'No matter what I hand General Legal - partnership agreements, user terms, an FCRA memo - it comes back fast and done right.'",
"execution_mode": "hybrid",
"evidence_url": "https://general.legal"
},
{
"step": "Attorney delivery",
"description": "The work is delivered as legal work product, with the firm recognised by Chambers Spotlight Artificial Intelligence (New York, 2027).",
"execution_mode": "human",
"evidence_url": "https://general.legal"
},
{
"step": "Responsiveness",
"description": "Client quote referencing 'After hours redlines, same-day NDA reviews'.",
"execution_mode": "hybrid",
"evidence_url": "https://general.legal"
}
],
"human_involvement": "Human-led with AI assistance (attorneys deliver; AI accelerates first-pass work)",
"business_model": "Legal fees; the firm is a law firm rather than a software vendor. Specific pricing not published on the captured pages.",
"publicly_reported_metrics": [
"500+ startups, scaleups and enterprises as clients",
"Chambers Spotlight Artificial Intelligence recognition (New York, 2027)"
],
"strength_of_evidence": "medium",
"limitations": [
"The AI stack is not described publicly; the 'AI law firm' positioning rests on firm branding and client testimony",
"Pricing not published",
"Independent verification of the 500+ client figure is not available"
],
"sources": [
"https://general.legal",
"https://general.legal/about",
"https://www.ycombinator.com/companies/general-legal"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/dbf548c3bb9f1d826b76f6c508355bcfc063f988.png",
"yc_url": "https://www.ycombinator.com/companies/general-legal",
"yc_one_liner": "Elite AI law firm for high growth companies",
"team_size": 40,
"locations": "",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Vector Legal",
"yc_batch": "Winter 2026",
"website": "https://vectorlegal.com",
"industry": "Legal",
"service_category": "AI-native law firm for tech companies",
"classification": "ai_native_service",
"traditional_service_replaced": "Big Law outside counsel for tech companies and their investors",
"target_customer": "Tech companies and their investors",
"customer_purchases": "Legal services: 'Experienced attorneys and proprietary AI for tech companies and their investors'; fractional general counsel retainers; outcome-based pricing where it fits",
"ai_workflow": [
{
"step": "First pass by software",
"description": "'Most work is billed hourly, at about half the cost of Big Law, because the firm's software takes the first pass and attorneys spend their time on judgment.'",
"execution_mode": "ai",
"evidence_url": "https://vectorlegal.com"
},
{
"step": "Attorney judgment",
"description": "Attorneys apply judgment on the reviewed work; engagements run as fractional GC retainers or matter-based.",
"execution_mode": "human",
"evidence_url": "https://vectorlegal.com"
},
{
"step": "Intake",
"description": "'start an engagement through the intake form at /contact'.",
"execution_mode": "hybrid",
"evidence_url": "https://vectorlegal.com"
}
],
"human_involvement": "Human-led with AI assistance (software takes the first pass; attorneys deliver judgment)",
"business_model": "Hourly billing 'at about half the cost of Big Law', plus fractional GC retainers and outcome-based pricing where it fits",
"publicly_reported_metrics": [
"Billed hourly at about half the cost of Big Law",
"Outcome-based pricing available where it fits"
],
"strength_of_evidence": "medium",
"limitations": [
"'About half the cost' has no published benchmark or methodology",
"The proprietary AI is not described in operational detail",
"Client count and matter volume not published"
],
"sources": [
"https://vectorlegal.com",
"https://vectorlegal.com/about",
"https://www.ycombinator.com/companies/vector-legal"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/24fe2cfdacb0c9b085052b0bee9ce77035a7373e.png",
"yc_url": "https://www.ycombinator.com/companies/vector-legal",
"yc_one_liner": "A premier AI-native law firm & legal operating system for Startups.",
"team_size": 9,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Moritz",
"yc_batch": "Winter 2026",
"website": "http://moritzlegal.com/",
"industry": "Legal",
"service_category": "Global AI-native law firm with same-day turnaround",
"classification": "ai_native_service",
"traditional_service_replaced": "Big Law and cross-border outside counsel for corporate, commercial and debt finance work",
"target_customer": "Startups, tech companies and cross-border businesses",
"customer_purchases": "Legal work product from a named attorney bench, positioned on same-day turnaround",
"ai_workflow": [
{
"step": "Attorney-led delivery",
"description": "The firm publishes a named attorney bench (Harvard, Oxford, Georgetown; ex-Orrick, Gunderson, Latham & Watkins, Kirkland & Ellis, Weil) across corporate, commercial, tech, fintech and EU e-commerce law.",
"execution_mode": "human",
"evidence_url": "http://moritzlegal.com/"
},
{
"step": "AI acceleration",
"description": "The firm is listed by YC as an 'AI-native law firm handling legal work with same-day turnaround'; the operational AI detail is not published.",
"execution_mode": "hybrid",
"evidence_url": "https://www.ycombinator.com/companies/moritz"
}
],
"human_involvement": "Human-led with AI assistance",
"business_model": "Legal fees (not published on the captured pages)",
"publicly_reported_metrics": [
"Named attorney bench with stated credentials",
"Positioned on same-day turnaround"
],
"strength_of_evidence": "low",
"limitations": [
"The captured site content is almost entirely attorney biographies - no description of the AI stack",
"'AI-native' rests on the YC listing and positioning",
"Pricing and client outcomes not published"
],
"sources": [
"http://moritzlegal.com/",
"https://www.ycombinator.com/companies/moritz"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/ba9cb936197827cdb07b7561ff78521aed096ae7.png",
"yc_url": "https://www.ycombinator.com/companies/moritz",
"yc_one_liner": "Global AI-native law firm handling legal work with same-day turnaround",
"team_size": 10,
"locations": "Oslo, Oslo, Norway",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Relaw",
"yc_batch": "Fall 2025",
"website": "https://www.relaw.ai",
"industry": "Legal",
"service_category": "Legal operating system / AI layer for law practices",
"classification": "ai_copilot_or_tool",
"traditional_service_replaced": "Fragmented law-practice software and manual matter administration (intake, documents, email, billing, trust accounting, follow-up)",
"target_customer": "Law practices",
"customer_purchases": "A legal operating system: intake, matter management, documents, email/calendar, time/billing/trust accounting, marketing and follow-up, with an agent that prepares the day",
"ai_workflow": [
{
"step": "Intake",
"description": "'Intake - The story, captured'.",
"execution_mode": "ai",
"evidence_url": "https://www.relaw.ai"
},
{
"step": "Relationship context",
"description": "'Messages - The relationship, connected'; 'Documents - Your expertise, applied'; 'Follow-through - The next step, ready'.",
"execution_mode": "ai",
"evidence_url": "https://www.relaw.ai"
},
{
"step": "Daily preparation agent",
"description": "'An agent watches your email, matters, and client status, then prepares your day so the work keeps moving' - 'Email priorities with replies drafted' and 'Next steps grounded in your records'.",
"execution_mode": "ai",
"evidence_url": "https://www.relaw.ai"
},
{
"step": "White-glove setup",
"description": "'White-glove setup / Complimentary training / Your templates, configured for you'.",
"execution_mode": "human",
"evidence_url": "https://www.relaw.ai"
}
],
"human_involvement": "Human-led with AI assistance (the lawyer still does the legal work; the system prepares it)",
"business_model": "Software subscription (pricing page exists; amounts not captured)",
"publicly_reported_metrics": [
"Agent prepares a daily dashboard with drafted replies and next steps"
],
"strength_of_evidence": "medium",
"limitations": [
"Explicitly a 'Legal Operating System' - a platform the firm operates, so this is a copilot/tool rather than a service that performs the legal work",
"Pricing amounts not captured",
"No published adoption metrics"
],
"sources": [
"https://www.relaw.ai",
"https://www.relaw.ai/pricing",
"https://www.ycombinator.com/companies/relaw"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-assisted (software the customer operates)",
"spectrum_key": "human_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/bb0260bafa98dc299797de55569bc9898b1505c1.png",
"yc_url": "https://www.ycombinator.com/companies/relaw",
"yc_one_liner": "AI Legal OS",
"team_size": 2,
"locations": "Los Angeles, CA, USA",
"status": "Active",
"yc_tags": [
"SaaS",
"Legal",
"AI"
]
},
{
"company_name": "Erinys",
"yc_batch": "Summer 2026",
"website": "https://erinys.ai",
"industry": "Legal",
"service_category": "Launching and operating AI-native law firms (firm-in-a-box)",
"classification": "ai_native_service",
"traditional_service_replaced": "The overhead of standing up and running an independent law practice (entity, operations, back office)",
"target_customer": "Lawyers who want to start their own firm",
"customer_purchases": "A launched and operated law firm: 'Erinys launches and operates AI-native law firms for lawyers ready to build something of their own'",
"ai_workflow": [
{
"step": "Firm launch",
"description": "'Erinys launches and operates AI-native law firms'; 'Welcome to the firm you almost started.'",
"execution_mode": "hybrid",
"evidence_url": "https://erinys.ai"
},
{
"step": "Operating loop",
"description": "'You practice law.' plus 'Automatable with Erinys - the full operating loop', i.e. Erinys automates the operating loop around the lawyer's practice.",
"execution_mode": "ai",
"evidence_url": "https://erinys.ai"
}
],
"human_involvement": "Human-led with AI assistance (the lawyer practises law; Erinys runs the firm's operations)",
"business_model": "Not publicly disclosed (waitlist stage)",
"publicly_reported_metrics": [],
"strength_of_evidence": "low",
"limitations": [
"Very thin public detail - the captured page is a waitlist landing page",
"Pricing, structure and legal/regulatory model not published",
"The captured page mentions 'For NPOs' with a contact address, which is not explained"
],
"sources": [
"https://erinys.ai",
"https://www.ycombinator.com/companies/erinys"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/3ecec9425d412cfc7fa1460b155883f078a7f023.png",
"yc_url": "https://www.ycombinator.com/companies/erinys",
"yc_one_liner": "We help lawyers start and scale AI-native law firms.",
"team_size": 3,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Legal",
"LegalTech",
"AI"
]
},
{
"company_name": "SafetyKit",
"yc_batch": "Summer 2023",
"website": "https://www.safetykit.com/",
"industry": "B2B / Compliance",
"service_category": "Trust and safety decisioning (API plus expert labelling)",
"classification": "ai_copilot_or_tool",
"traditional_service_replaced": "Manual trust-and-safety review and generic abuse-detection models",
"target_customer": "Trust and Safety teams at marketplaces and platforms",
"customer_purchases": "Decision models via API and/or labelled datasets to train the customer's own models; the customer operates the enforcement",
"ai_workflow": [
{
"step": "Content and entity evaluation",
"description": "Identifies hazardous materials, harmful websites and domains, transaction laundering, evaluating 'site content, ownership, and payment flows'.",
"execution_mode": "ai",
"evidence_url": "https://www.safetykit.com/"
},
{
"step": "Model delivery",
"description": "'Leverage our decision models out-of-the-box via API. Or train your own models on our labeled datasets.'",
"execution_mode": "ai",
"evidence_url": "https://www.safetykit.com/"
},
{
"step": "Expert labelling",
"description": "'Labeled by experts and specialists to ensure the accuracy needed for Trust & Safety policies and enforcement.'",
"execution_mode": "human",
"evidence_url": "https://www.safetykit.com/"
}
],
"human_involvement": "AI-led execution with exception-based human review (human experts label data; the customer's team enforces)",
"business_model": "API/usage-based and dataset licensing; the customer still performs enforcement",
"publicly_reported_metrics": [
"Expert-labelled datasets",
"'The best data builds the best models'"
],
"strength_of_evidence": "medium",
"limitations": [
"Sold as data/models via API, so the customer performs the work - included here as a comparison case, not as an AI-native service",
"Pricing not published"
],
"sources": [
"https://www.safetykit.com/",
"https://www.safetykit.com/product",
"https://www.ycombinator.com/companies/safetykit"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-assisted (software the customer operates)",
"spectrum_key": "human_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/2e6e9147312768cd270c02c7f00e0de9c130d05d.png",
"yc_url": "https://www.ycombinator.com/companies/safetykit",
"yc_one_liner": "AI agents for risk, compliance, and safety",
"team_size": 10,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Fintech",
"Compliance",
"Trust & Safety"
]
},
{
"company_name": "throxy",
"yc_batch": "Spring 2025",
"website": "https://throxy.com/",
"industry": "B2B",
"service_category": "AI-native sales development agency (B2B outbound)",
"classification": "ai_native_service",
"traditional_service_replaced": "B2B outbound sales development: hiring and training SDRs, list building, copywriting, sequencing and calling",
"target_customer": "B2B companies needing outbound pipeline",
"customer_purchases": "Booked meetings - 'throxy does the work for you' as a sales agency, with no SDRs to hire",
"ai_workflow": [
{
"step": "Data discovery",
"description": "'We run your entire outbound using our own custom-built tech that uncovers niche-specific data'.",
"execution_mode": "ai",
"evidence_url": "https://throxy.com/"
},
{
"step": "Messaging at scale",
"description": "'delivers unique messaging at scale, and keeps your emails landing in inboxes'.",
"execution_mode": "ai",
"evidence_url": "https://throxy.com/"
},
{
"step": "Calling",
"description": "'71% More meetings with calling added' - calling is part of the delivered service.",
"execution_mode": "hybrid",
"evidence_url": "https://throxy.com/"
},
{
"step": "Human SDR layer",
"description": "The YC one-liner reads 'Vertical AI agents running B2B outbound on autopilot, with human SDRs', i.e. humans remain part of delivery.",
"execution_mode": "human",
"evidence_url": "https://www.ycombinator.com/companies/throxy"
}
],
"human_involvement": "Human-supervised AI execution (AI agents run outbound; human SDRs are part of the service)",
"business_model": "Agency retainer/performance model; positions against the cost of hiring and training SDRs ('0 People you need to hire or train')",
"publicly_reported_metrics": [
"71% more meetings with calling added",
"121% more meetings booked per week since Maestro",
"11% booking rate on calls over 2 minutes",
"0 people you need to hire or train",
"12 meetings in 20 days for a named client in December"
],
"strength_of_evidence": "medium",
"limitations": [
"Metrics are customer testimonials without published methodology",
"The 'human SDRs' element means delivery is not fully autonomous",
"Pricing not published",
"'First AI-native sales agency' is a self-applied label"
],
"sources": [
"https://throxy.com/",
"https://www.ycombinator.com/companies/throxy"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/5384c6c535d7bcbaf2c4cee7af212ec06f70e79d.png",
"yc_url": "https://www.ycombinator.com/companies/throxy",
"yc_one_liner": "Vertical AI agents running B2B outbound on autopilot, with human SDRs",
"team_size": 55,
"locations": "London, England, United Kingdom",
"status": "Active",
"yc_tags": [
"B2B",
"Sales",
"Automation",
"AI"
]
},
{
"company_name": "Adside.ai",
"yc_batch": "Fall 2026",
"website": "https://adside.ai",
"industry": "B2B / Marketing",
"service_category": "AI agency for paid ads (self-serve and managed tiers)",
"classification": "hybrid",
"traditional_service_replaced": "Paid media agency work: market research, strategy, creative production, campaign monitoring, creative rotation",
"target_customer": "Startups and brands running paid ads on Meta, Google, LinkedIn, Reddit and Twitter",
"customer_purchases": "Either the agent team operated by the customer, or a fully managed service with a human expert from Adside's network",
"ai_workflow": [
{
"step": "Research and strategy",
"description": "'An AI team that researches your market, drafts a strategy'.",
"execution_mode": "ai",
"evidence_url": "https://adside.ai"
},
{
"step": "Creative production",
"description": "'creates static and video ads'; activity feed shows refreshed, resized and bulk-imported creatives.",
"execution_mode": "ai",
"evidence_url": "https://adside.ai"
},
{
"step": "Campaign monitoring and rotation",
"description": "'monitors your accounts, rotates creatives, and much more'.",
"execution_mode": "ai",
"evidence_url": "https://adside.ai"
},
{
"step": "Managed service layer",
"description": "'Managed service - Your AI agency, plus an expert human from our network to manage it'; 'A dedicated expert from our network manages your accounts and agents for you'.",
"execution_mode": "human",
"evidence_url": "https://adside.ai/pricing"
}
],
"human_involvement": "Human-supervised AI execution (managed tier) or human-led with AI assistance (self-serve tier)",
"business_model": "Two published tiers: AI Agency at $590/month per brand billed annually ($990 monthly), unlimited users, no per-seat pricing; Managed service starting at $3,500/month, or 10% of ad spend with a $3,500 monthly minimum",
"publicly_reported_metrics": [
"AI Agency: $990/month or $590/month billed annually (40% saving)",
"Managed service: from $3,500/month, or 10% of ad spend with a $3,500 minimum",
"Unlimited users, no per-seat pricing"
],
"strength_of_evidence": "high",
"limitations": [
"The self-serve tier is software the customer operates, so only the managed tier is a true service",
"No published performance outcomes for managed clients",
"Very early (Fall 2026)"
],
"sources": [
"https://adside.ai",
"https://adside.ai/pricing",
"https://www.ycombinator.com/companies/adside-ai"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-executed, human-supervised",
"spectrum_key": "human_supervised",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/4e762367db2ece01156d1933d40f463f680d2397.png",
"yc_url": "https://www.ycombinator.com/companies/adsideai",
"yc_one_liner": "AI agency that manages paid ads on Meta, Google, LinkedIn, etc. ",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Swarm AI",
"Marketing"
]
},
{
"company_name": "Superside",
"yc_batch": "Winter 2016",
"website": "http://www.superside.com",
"industry": "B2B / Creative",
"service_category": "AI-amplified creative-as-a-service (design and video subscription)",
"classification": "ai_enabled_service",
"traditional_service_replaced": "Creative and design agencies, in-house creative teams, and freelance design marketplaces",
"target_customer": "Enterprise marketing and creative teams (400+ top global brands cited)",
"customer_purchases": "A subscription to a senior creative team that delivers design and video work, with AI built into the workflow",
"ai_workflow": [
{
"step": "Team configuration",
"description": "'The same AI-native team every month, configured around your use case and live in about three weeks.'",
"execution_mode": "human",
"evidence_url": "http://www.superside.com"
},
{
"step": "Brand modelling",
"description": "'Brand Brain, custom brand models and AI workflows are built into the setup'.",
"execution_mode": "ai",
"evidence_url": "http://www.superside.com"
},
{
"step": "Creative production",
"description": "Design, video and motion production delivered by 'Every path is a real senior team with AI built in'.",
"execution_mode": "human",
"evidence_url": "http://www.superside.com"
},
{
"step": "AI-assisted throughput",
"description": "The site reports '12K+ AI-powered projects' and a '90%+ AI-certified creative team', i.e. AI raises human throughput rather than replacing the human.",
"execution_mode": "hybrid",
"evidence_url": "http://www.superside.com"
}
],
"human_involvement": "Human-led with AI assistance (senior creative teams deliver; AI amplifies them)",
"business_model": "Creative-as-a-service subscription: flexible subscription, dedicated team, or fixed-scope projects; 'far better value than holding an agency on retainer'",
"publicly_reported_metrics": [
"200K+ projects delivered",
"12K+ AI-powered projects",
"90%+ AI-certified creative team",
"95%+ projects rated 4+ stars in the past year",
"400+ top global brands"
],
"strength_of_evidence": "high",
"limitations": [
"Delivery remains fundamentally human - included here as an AI-enabled service comparison, not an AI-native service",
"The 'AI-certified creative team' metric describes training, not autonomous delivery",
"Subscription prices are not published"
],
"sources": [
"http://www.superside.com",
"http://www.superside.com/case-studies",
"https://www.ycombinator.com/companies/superside"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-assisted",
"spectrum_key": "human_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/3f97e6f72e5f0f939f199ac6282cab34c72f7945.png",
"yc_url": "https://www.ycombinator.com/companies/superside",
"yc_one_liner": "AI-First Creative Partner for Enterprise Teams",
"team_size": 850,
"locations": "Oslo, Oslo, Norway; Remote",
"status": "Active",
"yc_tags": [
"SaaS",
"Design Tools",
"Marketing",
"AI"
]
},
{
"company_name": "The Vibe Company",
"yc_batch": "Winter 2024",
"website": "https://thevibecompany.co",
"industry": "B2B",
"service_category": "AI-native product studio and agent operator",
"classification": "ai_native_service",
"traditional_service_replaced": "Software development agencies and internal engineering/ops teams; also manual customer-support handling",
"target_customer": "Companies needing products built, agents operated, or teams trained",
"customer_purchases": "Delivered work: shipped products, agents run inside the client's company, and advisory/training",
"ai_workflow": [
{
"step": "Build",
"description": "'Build AI products and internal tools, end-to-end.'",
"execution_mode": "hybrid",
"evidence_url": "https://thevibecompany.co"
},
{
"step": "Operate",
"description": "'Operate Agents inside your company.'",
"execution_mode": "ai",
"evidence_url": "https://thevibecompany.co"
},
{
"step": "Advise",
"description": "'Strategy, training, and the AI playbook for your team.'",
"execution_mode": "human",
"evidence_url": "https://thevibecompany.co"
},
{
"step": "Case study - support drafting",
"description": "For LocService: 'Hundreds of tickets a day, our drafts used on 87% of them', with 'a support agent reviews the draft, fixes it if needed, then sends it.'",
"execution_mode": "hybrid",
"evidence_url": "https://thevibecompany.co/case-studies"
},
{
"step": "Case study - product build",
"description": "For a healthcare client: shipped a caregiver app, a nurse CRM (Lifeline) and the API tying them together in two months.",
"execution_mode": "hybrid",
"evidence_url": "https://thevibecompany.co/case-studies"
}
],
"human_involvement": "Human-supervised AI execution (agents produce drafts; human staff review and send)",
"business_model": "Agency/studio engagement model ('we build, we run, we train'); the company states it runs on AI itself 'so you ship faster and for far less than a traditional team'",
"publicly_reported_metrics": [
"87% of LocService support tickets answered with AI drafts",
"Two-month build of caregiver app, nurse CRM and API for a healthcare client",
"165-question caregiver assessment converted into an action plan"
],
"strength_of_evidence": "high",
"limitations": [
"Agency model - the human team is the delivery mechanism, with AI as leverage",
"Pricing not published",
"Case studies are self-published"
],
"sources": [
"https://thevibecompany.co",
"https://thevibecompany.co/case-studies",
"https://www.ycombinator.com/companies/the-vibe-company"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/48a2e57e5dd1d60b9593214bad1c5d81f0340c27.png",
"yc_url": "https://www.ycombinator.com/companies/the-vibe-company",
"yc_one_liner": "AI-native agency that scales like software, run on our own AI agents.",
"team_size": 5,
"locations": "Paris, Île-de-France, France",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Humoniq",
"yc_batch": "Summer 2025",
"website": "https://humoniq.ai",
"industry": "B2B / Travel",
"service_category": "Fully automated airline customer service (managed service)",
"classification": "ai_native_service",
"traditional_service_replaced": "Airline customer service and contact-centre operations: resolving passenger requests over email, chat and phone",
"target_customer": "Airlines",
"customer_purchases": "Resolved passenger requests end to end, delivered as a managed service, with optional in-house support mode",
"ai_workflow": [
{
"step": "Request intake",
"description": "'We resolve passenger requests across email, chat and phone.'",
"execution_mode": "ai",
"evidence_url": "https://humoniq.ai"
},
{
"step": "Rules-grounded resolution",
"description": "'Resolving requests end-to-end' using 'Passenger, booking and airline rules.'",
"execution_mode": "ai",
"evidence_url": "https://humoniq.ai"
},
{
"step": "Service-model choice",
"description": "'Choose the service model that fits your airline' - including 'In-house support / Your team' where 'Your experts step in when needed.'",
"execution_mode": "hybrid",
"evidence_url": "https://humoniq.ai"
},
{
"step": "Managed service layer",
"description": "'AI and experienced travel specialists, together in one managed service.'",
"execution_mode": "human",
"evidence_url": "https://humoniq.ai"
},
{
"step": "Approval points",
"description": "'Your scope and approval points'; 'Every case and action in view'.",
"execution_mode": "human",
"evidence_url": "https://humoniq.ai"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Managed service for airlines; a pricing page exists but rates were not captured",
"publicly_reported_metrics": [
"60% reduction in human labour hours",
"75% of complex cases automated",
"Built exclusively for airlines"
],
"strength_of_evidence": "high",
"limitations": [
"The metrics have no published methodology",
"Pricing not captured",
"The 'in-house support' mode keeps the airline's own team in the loop"
],
"sources": [
"https://humoniq.ai",
"https://humoniq.ai/pricing",
"https://www.ycombinator.com/companies/humoniq"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/dd360d85931a0845b568ab55a8dd586fb4c3941c.png",
"yc_url": "https://www.ycombinator.com/companies/humoniq",
"yc_one_liner": "Airline customer service, fully automated.",
"team_size": 5,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Travel",
"AI",
"Conversational AI"
]
},
{
"company_name": "Riviera",
"yc_batch": "Winter 2025",
"website": "https://www.withriviera.com",
"industry": "B2B / Hospitality",
"service_category": "AI hotel employee - calls, dining orders and reservations",
"classification": "ai_native_service",
"traditional_service_replaced": "Hotel front-desk and reservations phone handling: guest calls, dining orders, reservations, multilingual guest questions",
"target_customer": "Hotels",
"customer_purchases": "'AI Agents for Hospitality' that handle guest calls, dining orders and reservations around the clock",
"ai_workflow": [
{
"step": "Guest call answering",
"description": "'AI agents that handle calls, dining orders, and reservations in any language, around the clock.'",
"execution_mode": "ai",
"evidence_url": "https://www.withriviera.com"
},
{
"step": "Language detection and switching",
"description": "'Riviera detects the guest's language in real time and switches fluently'; 'If a guest switches languages, the agent follows seamlessly.'",
"execution_mode": "ai",
"evidence_url": "https://www.withriviera.com"
},
{
"step": "Guest intelligence",
"description": "Imports guest guides (e.g. 'Grand Palais Guest Guide.pdf') to ground answers.",
"execution_mode": "ai",
"evidence_url": "https://www.withriviera.com"
},
{
"step": "Human handoff",
"description": "'When a guest needs a human, Riviera transfers with the full conversation and context already loaded' - 'Your staff picks up with the full story.'",
"execution_mode": "human",
"evidence_url": "https://www.withriviera.com"
}
],
"human_involvement": "AI-led execution with exception-based human review (smart transfer to staff)",
"business_model": "Not captured (pricing page exists on the site); sold as an 'AI hotel employee'",
"publicly_reported_metrics": [
"Multilingual with mid-call language switching",
"Always-on coverage"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing not captured",
"No published call-volume, containment or accuracy metrics",
"The handoff design means humans remain a first-class path"
],
"sources": [
"https://www.withriviera.com",
"https://www.ycombinator.com/companies/riviera"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/790dbe46b89475fab7c527c1403f9dcbd5c92c33.png",
"yc_url": "https://www.ycombinator.com/companies/riviera",
"yc_one_liner": "AI Employees for Hotels",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"SaaS",
"B2B",
"Travel",
"Analytics",
"AI"
]
},
{
"company_name": "Agency",
"yc_batch": "Winter 2022",
"website": "https://GetAgency.com",
"industry": "B2B / Compliance",
"service_category": "Managed compliance execution service (virtual CISO plus AI products)",
"classification": "ai_native_service",
"traditional_service_replaced": "Outsourced security and compliance work: virtual CISO services, compliance management, security engineering, vendor risk, pen testing and audit coordination",
"target_customer": "Companies needing SOC 2, ISO 27001, HIPAA, GDPR, CMMC and similar compliance",
"customer_purchases": "'End-to-end compliance execution' delivered by forward-deployed engineers with AI products, including a virtual CISO and compliance manager",
"ai_workflow": [
{
"step": "Control implementation",
"description": "Engineers 'operate a proprietary orchestration layer and AI agents to execute control implementation, evidence, monitoring, vendor risk, pen testing, and audit coordination'.",
"execution_mode": "hybrid",
"evidence_url": "https://GetAgency.com"
},
{
"step": "AI product layer",
"description": "'13 purpose-built AI products that operate your security and compliance program - from command-and-control orchestration to audit-ready evidence.'",
"execution_mode": "ai",
"evidence_url": "https://GetAgency.com"
},
{
"step": "Forward-deployed engineers",
"description": "'Run end-to-end by U.S.-based forward-deployed compliance engineers, supercharged by proprietary AI that plugs into the tools you already trust.'",
"execution_mode": "human",
"evidence_url": "https://GetAgency.com"
},
{
"step": "Multi-party scope",
"description": "Executes across 'BYOD, contractor fleets, and multi-party environments'.",
"execution_mode": "hybrid",
"evidence_url": "https://GetAgency.com"
}
],
"human_involvement": "Human-supervised AI execution (engineers run the program; AI products do the execution work)",
"business_model": "Managed service with published pricing tiers ('Express Comply Pricing', 'Managed Comply Pricing'); the virtual CISO, compliance manager and security engineering are included in the service",
"publicly_reported_metrics": [
"13 purpose-built AI products",
"Frameworks operated: SOC 2, ISO 27001, HIPAA, GDPR, CMMC and more",
"Virtual CISO, compliance manager and security engineering included in the service"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing amounts were not captured (pricing pages exist)",
"'We do what automation can't' is explicitly a human-value claim",
"No published client or audit-outcome metrics"
],
"sources": [
"https://GetAgency.com",
"https://www.ycombinator.com/companies/agency"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/0b9732a89bf577bd80a0c7d0b377bd35fcce86ce.png",
"yc_url": "https://www.ycombinator.com/companies/agency",
"yc_one_liner": "Agency replaces traditional security and compliance headcount with AI.",
"team_size": 50,
"locations": "New York City, NY, USA",
"status": "Active",
"yc_tags": [
"SaaS",
"B2B",
"Compliance",
"Security",
"Enterprise"
]
},
{
"company_name": "Asendia AI",
"yc_batch": "Spring 2026",
"website": "https://asendia.ai/",
"industry": "B2B / HR",
"service_category": "Agentic recruiting - AI interviews and candidate screening for staffing firms",
"classification": "ai_native_service",
"traditional_service_replaced": "Top-of-funnel recruiting work: candidate phone screening, scheduling and qualification",
"target_customer": "Staffing agencies and enterprise recruiting organisations",
"customer_purchases": "Screened candidates: AI interviews that screen far more candidates, with the AI handling the entire top of funnel",
"ai_workflow": [
{
"step": "AI phone screen",
"description": "'Day 1: Sarah, the AI agent, calls the candidate to conduct a preliminary phone screen' - a scripted AI voice interview.",
"execution_mode": "ai",
"evidence_url": "https://asendia.ai/"
},
{
"step": "Candidate matching",
"description": "Agent scores and matches candidates (e.g. 'Alen 72% Match Sales Manager, New York').",
"execution_mode": "ai",
"evidence_url": "https://asendia.ai/"
},
{
"step": "Funnel ownership",
"description": "'The AI handles the entire top-of-funnel so our team can focus on closing the best candidates.'",
"execution_mode": "ai",
"evidence_url": "https://asendia.ai/"
},
{
"step": "Recruiter closes",
"description": "Human recruiters handle the close; the service is positioned as cloning a firm's best recruiters rather than replacing them.",
"execution_mode": "human",
"evidence_url": "https://asendia.ai/"
}
],
"human_involvement": "AI-led execution with exception-based human review (AI owns the top of funnel; recruiters close)",
"business_model": "Not publicly disclosed; sold to staffing firms and enterprises as an agentic recruiting platform",
"publicly_reported_metrics": [
"'AI interviews that screen 10x more candidates'",
"'The #1 agentic recruiting platform for staffing and enterprise'"
],
"strength_of_evidence": "medium",
"limitations": [
"'10x more candidates' has no published methodology",
"Pricing not published",
"Explicitly designed not to replace recruiters ('Don't replace your recruiters, Clone your best ones')"
],
"sources": [
"https://asendia.ai/",
"https://www.ycombinator.com/companies/asendia-ai"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/e735fee67a48586d3de061beb544a8ab8d481fc6.png",
"yc_url": "https://www.ycombinator.com/companies/asendia-ai",
"yc_one_liner": "AI recruiters for staffing agencies",
"team_size": 10,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Zomma",
"yc_batch": "Summer 2026",
"website": "https://zommalabs.com",
"industry": "B2B / Fintech",
"service_category": "Computer-use agents for enterprise operations (AI BPO for financial services)",
"classification": "ai_native_service",
"traditional_service_replaced": "Financial-services back-office and operations outsourcing: work performed in portals, registries, case managers and internal systems",
"target_customer": "Financial services and other enterprises with operations that 'can't fail'",
"customer_purchases": "Operations work executed by computer-use agents, validated on the customer's own past cases before going live",
"ai_workflow": [
{
"step": "Agent connection",
"description": "'Zomma builds computer-use agents for the enterprise'; 'Connect - Agents with their own computers.'",
"execution_mode": "ai",
"evidence_url": "https://zommalabs.com"
},
{
"step": "Private benchmark validation",
"description": "'Each one is proven on a private benchmark from your own past cases before it goes live, and again after every change'; 'We run it on work your team has already completed and compare its output with your team's decisions, item by item.'",
"execution_mode": "hybrid",
"evidence_url": "https://zommalabs.com"
},
{
"step": "Execution in customer systems",
"description": "'bank and custodian portals, company registries, case managers, ticketing tools, PDFs, statements and spreadsheets, and your own internal systems, under credentials you control'.",
"execution_mode": "ai",
"evidence_url": "https://zommalabs.com"
},
{
"step": "Recommendation only",
"description": "'Even live, it only recommends; your team makes every determination, and every step is recorded so the reviewer can see what was checked, what was found and why.'",
"execution_mode": "human",
"evidence_url": "https://zommalabs.com"
}
],
"human_involvement": "Human-supervised AI execution (agents recommend; the customer's team makes every determination)",
"business_model": "Not publicly disclosed; positioned as an 'AI BPO for financial services, run by computer-use agents'",
"publicly_reported_metrics": [
"Private benchmark validation against the customer's own historical cases",
"Full step-level audit records for reviewers"
],
"strength_of_evidence": "medium",
"limitations": [
"'Only recommends' means the customer's humans still make every determination",
"Pricing not published",
"No published client count or accuracy figures",
"Very early (Summer 2026)"
],
"sources": [
"https://zommalabs.com",
"https://zommalabs.com/security",
"https://www.ycombinator.com/companies/zomma"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/019855257e473ab4938156b12e16e4a3214a2f51.png",
"yc_url": "https://www.ycombinator.com/companies/zomma",
"yc_one_liner": "The AI BPO for financial servies, run by computer-use agents",
"team_size": 5,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Robotic Process Automation",
"Finance",
"B2B",
"Workflow Automation",
"AI"
]
},
{
"company_name": "TrueMile",
"yc_batch": "Fall 2026",
"website": "https://TrueMile.AI/",
"industry": "Industrials / Logistics",
"service_category": "AI-native trucking company",
"classification": "ai_native_service",
"traditional_service_replaced": "Trucking carrier operations: sourcing freight, dispatching, driver management and customer updates",
"target_customer": "Shippers needing freight moved",
"customer_purchases": "Freight moved - a trucking service, not software",
"ai_workflow": [
{
"step": "Freight sourcing",
"description": "'From finding freight to keeping customers updated, our AI agents connect the work across the fleet.'",
"execution_mode": "ai",
"evidence_url": "https://TrueMile.AI/"
},
{
"step": "Operations coordination",
"description": "'Our AI agents put it into motion' - agents connect work across the fleet.",
"execution_mode": "ai",
"evidence_url": "https://TrueMile.AI/"
},
{
"step": "Driving",
"description": "The site explicitly states 'Human drivers', i.e. the physical work is human.",
"execution_mode": "human",
"evidence_url": "https://TrueMile.AI/"
}
],
"human_involvement": "Human-supervised AI execution (AI runs coordination; human drivers do the physical work)",
"business_model": "Freight/trucking revenue (per-load economics); the company operates as a carrier rather than selling software",
"publicly_reported_metrics": [],
"strength_of_evidence": "low",
"limitations": [
"Thin public detail beyond positioning",
"No pricing, volume or fleet metrics published",
"Very early (Fall 2026)",
"The physical work (driving) remains human"
],
"sources": [
"https://TrueMile.AI/",
"https://www.ycombinator.com/companies/truemile"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/94408cc02a79b94fd281d47aabc0056465683df6.png",
"yc_url": "https://www.ycombinator.com/companies/truemile",
"yc_one_liner": "AI-native trucking company",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"AIOps",
"Machine Learning",
"Logistics",
"Data Science"
]
},
{
"company_name": "LinkLane",
"yc_batch": "Winter 2027",
"website": "https://linklane.ai/",
"industry": "Industrials / Logistics",
"service_category": "AI-powered freight brokerage",
"classification": "ai_native_service",
"traditional_service_replaced": "Freight brokerage service: quoting, carrier sourcing, rate negotiation, tracking and carrier payment",
"target_customer": "Shippers",
"customer_purchases": "Booked and tracked freight: 'Your Freight Partner', with instant quotes, vetted carriers and live tracking",
"ai_workflow": [
{
"step": "Instant quoting",
"description": "'LinkLane quotes every load against real-time market rates'; 'Shippers get a price in under a minute'; quotes accepted by email 'in any format'.",
"execution_mode": "ai",
"evidence_url": "https://linklane.ai/"
},
{
"step": "Carrier sourcing and vetting",
"description": "'Capacity is secured instantly through our trusted network of carriers ... every load is fully covered, automatically.'",
"execution_mode": "ai",
"evidence_url": "https://linklane.ai/"
},
{
"step": "Rate negotiation",
"description": "'our human specialists and AI agents find a qualified carrier, negotiate the rate and manage the shipment from pickup to delivery'.",
"execution_mode": "hybrid",
"evidence_url": "https://linklane.ai/about"
},
{
"step": "Tracking and payment",
"description": "'Real-time tracking door to door, with the carrier paid the instant delivery is confirmed.'",
"execution_mode": "ai",
"evidence_url": "https://linklane.ai/"
},
{
"step": "Exception handling",
"description": "'Our team handles the exceptions'; 'Every load has a LinkLane specialist watching it, and you can reach us by phone or email whenever you need a person.'",
"execution_mode": "human",
"evidence_url": "https://linklane.ai/"
}
],
"human_involvement": "AI-led execution with exception-based human review (specialists watch every load and handle exceptions)",
"business_model": "Freight brokerage: the price booked is the price paid; brokerage margin on loads (rates not published)",
"publicly_reported_metrics": [
"Price in under a minute",
"Quote in under a minute for full truckload or LTL",
"Real team behind every load around the clock"
],
"strength_of_evidence": "medium",
"limitations": [
"No published load volumes, margins or automation rate",
"Brokerage margin structure not disclosed",
"Very early (Winter 2027)"
],
"sources": [
"https://linklane.ai/",
"https://linklane.ai/about",
"https://www.ycombinator.com/companies/linklane"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/622f0cd8620407da036d7d0809c1bb429c984f34.png",
"yc_url": "https://www.ycombinator.com/companies/linklane",
"yc_one_liner": "AI-powered freight brokerage. Quote, book, and track loads in seconds.",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Digital Freight Brokerage",
"Marketplace",
"Workflow Automation"
]
},
{
"company_name": "Atlia",
"yc_batch": "Summer 2026",
"website": "https://www.atlia.com",
"industry": "Real Estate",
"service_category": "AI-native short-term rental property management",
"classification": "ai_native_service",
"traditional_service_replaced": "Short-term rental property management companies charging 20-35% of revenue for guest communication, pricing, turnovers, maintenance coordination and owner reporting",
"target_customer": "Short-term rental owners",
"customer_purchases": "Full-service property management at a flat 10% fee: guests handled, pricing set, turnovers and maintenance coordinated, owner reporting",
"ai_workflow": [
{
"step": "Guest communication",
"description": "'Atlia coordinates guest communication, pricing, turnovers, maintenance, supplies, and property-specific decisions'.",
"execution_mode": "ai",
"evidence_url": "https://www.atlia.com"
},
{
"step": "Dynamic pricing",
"description": "Operators supervise pricing; the system handles day-to-day pricing decisions.",
"execution_mode": "hybrid",
"evidence_url": "https://www.atlia.com"
},
{
"step": "Property memory",
"description": "'House rules, vendors, calendars, pricing, and operating details stay in context for every booking.'",
"execution_mode": "ai",
"evidence_url": "https://www.atlia.com"
},
{
"step": "Local operator oversight",
"description": "'A real operator stays close to your home and coordinates guests, vendors, and urgent property issues'; 'Experienced operators supervising the system.'",
"execution_mode": "human",
"evidence_url": "https://www.atlia.com"
},
{
"step": "Owner reporting",
"description": "'Clear approvals, transparent reporting, and a flat fee keep the model simple.'",
"execution_mode": "hybrid",
"evidence_url": "https://www.atlia.com"
}
],
"human_involvement": "Human-supervised AI execution (experienced operators supervise the system)",
"business_model": "Flat 10% management fee (explicitly contrasted with the traditional 20-35% STR management fee)",
"publicly_reported_metrics": [
"10% flat management fee vs traditional 20-35%",
"Local staffed operations in Fort Lauderdale and San Diego"
],
"strength_of_evidence": "high",
"limitations": [
"Operators remain central ('experienced operators supervising the system'), so this is supervised rather than autonomous",
"No published portfolio size or owner outcomes",
"Limited to two metro areas"
],
"sources": [
"https://www.atlia.com",
"https://www.atlia.com/about",
"https://www.ycombinator.com/companies/atlia"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 3,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/7a4b2fb5aaa99f5f795d2aa898508681eae26222.png",
"yc_url": "https://www.ycombinator.com/companies/atlia",
"yc_one_liner": "The AI-native property management company for short-term rentals",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Real Estate",
"Proptech",
"Big Data",
"AI"
]
},
{
"company_name": "Assembly HOA",
"yc_batch": "Summer 2024",
"website": "https://assemblyhoa.com",
"industry": "Real Estate",
"service_category": "AI-native HOA management company",
"classification": "ai_enabled_service",
"traditional_service_replaced": "Homeowners association management: budgeting, reserve planning, assessment collection, maintenance coordination, vendor management and board reporting",
"target_customer": "HOA boards and communities",
"customer_purchases": "HOA management delivered by expert managers with modern software - budgeting, reserve planning, collections, maintenance and reporting",
"ai_workflow": [
{
"step": "Financial management",
"description": "'Budgeting that reflects actual needs ... Reserve planning ... Assessment collection and delinquency enforcement ... Real-time reporting with board-ready insights.'",
"execution_mode": "hybrid",
"evidence_url": "https://assemblyhoa.com"
},
{
"step": "Maintenance coordination",
"description": "'Tracking service requests from submission to completion'; 'Matching vendors to the right scope and budget'; 'Set and enforce a recurring maintenance schedule'.",
"execution_mode": "hybrid",
"evidence_url": "https://assemblyhoa.com"
},
{
"step": "Automated invoicing",
"description": "'Invoices are automatically processed and sent for one-click board approval, ensuring vendors are paid instantly and accurately.'",
"execution_mode": "ai",
"evidence_url": "https://assemblyhoa.com"
},
{
"step": "Expert manager delivery",
"description": "'Expert-led HOA management, backed by modern tech'; 'We combine the best managers with modern transparent software'.",
"execution_mode": "human",
"evidence_url": "https://assemblyhoa.com"
}
],
"human_involvement": "Human-led with AI assistance (expert managers deliver; software automates invoicing and tracking)",
"business_model": "HOA management fees (not published); 'Request a proposal' intake",
"publicly_reported_metrics": [
"4.5 on Google",
"Customer quote about saving money by finding better vendors"
],
"strength_of_evidence": "medium",
"limitations": [
"Explicitly 'expert-led', i.e. human delivery with tech support",
"Pricing not published",
"No published portfolio or automation metrics",
"The site describes 'modern transparent software' rather than AI agents doing the work"
],
"sources": [
"https://assemblyhoa.com",
"https://www.ycombinator.com/companies/assembly-hoa"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-assisted",
"spectrum_key": "human_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/251db0cfd3ffbbbe376cb8fa8066246654b8bd87.png",
"yc_url": "https://www.ycombinator.com/companies/assembly-hoa",
"yc_one_liner": "AI-native HOA Management Company",
"team_size": 12,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Fintech",
"Real Estate",
"Housing",
"Proptech",
"AI"
]
},
{
"company_name": "PARES AI",
"yc_batch": "Summer 2025",
"website": "https://www.pares.ai/",
"industry": "Real Estate",
"service_category": "AI-native real estate services firm (underwriting, BOVs, property management)",
"classification": "ai_native_service",
"traditional_service_replaced": "Real estate analyst and property-management work: valuation, underwriting, broker opinion of value (BOV), decks, deal distribution",
"target_customer": "Real estate investors and operators",
"customer_purchases": "Completed real estate work product: underwritten deals, BOVs, decks and property management",
"ai_workflow": [
{
"step": "Underwriting",
"description": "'$2B+ Underwritten' with '10 min Underwriting' advertised; the firm performs valuation and underwriting as a service.",
"execution_mode": "ai",
"evidence_url": "https://www.pares.ai/"
},
{
"step": "Comps and analysis",
"description": "Customer quote: 'PARES help provided me sales comps I haven't seen before. It suggested ways to increase additional income and items to renovate to save repair costs while achieving higher rents.'",
"execution_mode": "ai",
"evidence_url": "https://www.pares.ai/"
},
{
"step": "Deal materials",
"description": "'Valuation / Underwriting', 'OMs / BOVs / Decks', 'Deal Distribution'.",
"execution_mode": "ai",
"evidence_url": "https://www.pares.ai/"
},
{
"step": "Property management",
"description": "'Tenant portal & communication, Applications & leasing, Accounting & reporting, Automated notifications & reminders'.",
"execution_mode": "hybrid",
"evidence_url": "https://www.pares.ai/"
}
],
"human_involvement": "Unknown or insufficient evidence",
"business_model": "Not publicly disclosed; sold as an end-to-end workflow across underwriting, deals and property management",
"publicly_reported_metrics": [
"$2B+ underwritten",
"10 min underwriting",
"Nationwide market coverage"
],
"strength_of_evidence": "medium",
"limitations": [
"'$2B+ underwritten' has no published methodology or time frame",
"Pricing not published",
"Human involvement is not described on the captured pages"
],
"sources": [
"https://www.pares.ai/",
"https://www.ycombinator.com/companies/pares-ai"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 0,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/dbbb70598f14b005aa7da32e84d2d14fed9e3e3a.png",
"yc_url": "https://www.ycombinator.com/companies/pares-ai",
"yc_one_liner": "AI-native real estate services firm",
"team_size": 3,
"locations": "Los Angeles, CA, USA",
"status": "Active",
"yc_tags": [
"Real Estate",
"Proptech",
"AI",
"Conversational AI"
]
},
{
"company_name": "Alder",
"yc_batch": "Fall 2025",
"website": "https://meetalder.com/",
"industry": "B2B / Fintech",
"service_category": "AI employee for accounts receivable",
"classification": "ai_native_service",
"traditional_service_replaced": "Accounts receivable work: chasing unpaid invoices, resolving short-pays and missing POs, confirming cash receipt",
"target_customer": "Finance and receivables teams",
"customer_purchases": "'Alder is the AI employee for your receivables team' - the AR chasing and resolution work performed on the customer's behalf",
"ai_workflow": [
{
"step": "Invoice chasing",
"description": "'Alder follows up on every overdue invoice with the person who can pay it, remembers when they promised to pay, and checks that the money arrived.'",
"execution_mode": "ai",
"evidence_url": "https://meetalder.com/"
},
{
"step": "Issue diagnosis",
"description": "Example: invoice missing a PO leads to a Monday 9:12 AM email to the payer; 'It was short-paid' triggers the next action.",
"execution_mode": "ai",
"evidence_url": "https://meetalder.com/"
},
{
"step": "Evidence assembly for humans",
"description": "'Alder pulls the PO, receipt, and rate, and hands your analyst a decision with the supporting evidence.'",
"execution_mode": "hybrid",
"evidence_url": "https://meetalder.com/"
},
{
"step": "Analyst decision",
"description": "The analyst makes the final call with Alder's assembled evidence.",
"execution_mode": "human",
"evidence_url": "https://meetalder.com/"
}
],
"human_involvement": "AI-led execution with exception-based human review (analyst decides on flagged items)",
"business_model": "Not captured (pricing page exists); sold as an 'AI employee' for the receivables team",
"publicly_reported_metrics": [
"Example workflow: PO retrieval, receipt and rate assembled for analyst decision"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing not captured",
"No published recovery-rate or volume metrics",
"The analyst remains the decision-maker for exceptions"
],
"sources": [
"https://meetalder.com/",
"https://meetalder.com/product",
"https://www.ycombinator.com/companies/alder"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/f394904d91685ab676105f88e9090848b7a6f1b2.png",
"yc_url": "https://www.ycombinator.com/companies/alder",
"yc_one_liner": "AI employees for finance, starting with accounts receivable. ",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"B2B",
"AI"
]
},
{
"company_name": "Rex",
"yc_batch": "Summer 2026",
"website": "https://www.ycombinator.com/companies/rex",
"industry": "B2B",
"service_category": "AI operations partner for enterprise order-to-cash",
"classification": "ai_native_service",
"traditional_service_replaced": "Enterprise order-to-cash operations: order processing, invoicing, collections and cash application, often outsourced to shared-service centres or BPOs",
"target_customer": "Enterprises with complex order-to-cash operations",
"customer_purchases": "An operations partner that runs order-to-cash - an operations outcome rather than software",
"ai_workflow": [
{
"step": "Order-to-cash execution",
"description": "YC one-liner: 'AI operations partner for enterprise order-to-cash.' Detailed workflow not published on the captured pages.",
"execution_mode": "hybrid",
"evidence_url": "https://www.ycombinator.com/companies/rex"
}
],
"human_involvement": "Unknown or insufficient evidence",
"business_model": "Not publicly disclosed",
"publicly_reported_metrics": [],
"strength_of_evidence": "low",
"limitations": [
"No company website content captured - the entry rests on the YC one-liner only",
"No pricing, workflow or outcome detail available",
"Flagged as a candidate requiring further research"
],
"sources": [
"https://www.ycombinator.com/companies/rex"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 0,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/b14c16514ac7654483b96e54e1bf49a45714e8f6.png",
"yc_url": "https://www.ycombinator.com/companies/rex-inc",
"yc_one_liner": "AI operations partner for enterprise order-to-cash ",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"B2B",
"Enterprise",
"Enterprise Software",
"AI"
]
},
{
"company_name": "Autotab",
"yc_batch": "Summer 2023",
"website": "https://autotab.com",
"industry": "B2B",
"service_category": "General AI agent for knowledge work (BPO replacement positioning)",
"classification": "hybrid",
"traditional_service_replaced": "Business process outsourcing - the site explicitly addresses 'replacing your BPO with something better'",
"target_customer": "Enterprises with repetitive back-office processes",
"customer_purchases": "A general AI agent that 'learns and works like a human' - the agent, which the customer deploys",
"ai_workflow": [
{
"step": "Agent learning",
"description": "'Autotab is a general AI agent that both learns and works like a human.'",
"execution_mode": "ai",
"evidence_url": "https://autotab.com"
},
{
"step": "BPO replacement conversation",
"description": "'If you are interested in replacing your BPO with something better, please email us.'",
"execution_mode": "hybrid",
"evidence_url": "https://autotab.com"
}
],
"human_involvement": "Unknown or insufficient evidence",
"business_model": "Not publicly disclosed on the captured page",
"publicly_reported_metrics": [],
"strength_of_evidence": "low",
"limitations": [
"The captured site content is a single-page enterprise teaser",
"The agent appears to be software the enterprise runs, though the site frames it as a BPO replacement",
"No pricing, workflow or outcome detail"
],
"sources": [
"https://autotab.com",
"https://www.ycombinator.com/companies/autotab"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-executed, human-supervised",
"spectrum_key": "human_supervised",
"autonomy_score": 0,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/4967676cdc6058f952822347fafe9d59a61218fb.png",
"yc_url": "https://www.ycombinator.com/companies/autotab",
"yc_one_liner": "AI agents reliable enough to do real work",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Acquired",
"yc_tags": [
"Productivity",
"Enterprise",
"Automation",
"AI"
]
},
{
"company_name": "Dock",
"yc_batch": "Summer 2026",
"website": "https://trydock.ai",
"industry": "B2B",
"service_category": "Hire agents for business work (agent marketplace with included agents)",
"classification": "ai_copilot_or_tool",
"traditional_service_replaced": "Hiring additional staff for business work; individual point-solution SaaS tools",
"target_customer": "Business teams",
"customer_purchases": "Access to specialised agents with skills, tools and a computer; priced per person on the team",
"ai_workflow": [
{
"step": "Agent marketplace",
"description": "'Hire agents for business work - Specialized agents with skills, tools, and a computer.'",
"execution_mode": "ai",
"evidence_url": "https://trydock.ai"
},
{
"step": "Agents included",
"description": "'The agents come included'; 'Agents that take on the work you never get to.'",
"execution_mode": "ai",
"evidence_url": "https://trydock.ai"
},
{
"step": "Customer operates the agents",
"description": "'You pay for the people on your team' - the pricing model is per-seat for humans, and the customer directs the agents.",
"execution_mode": "human",
"evidence_url": "https://trydock.ai/pricing"
}
],
"human_involvement": "Human-led with AI assistance (the customer's team directs and operates the agents)",
"business_model": "Published per-person subscription: Starter $20/person/month (one agent), Standard $100/person/month (a small team of agents, always on, 10,000 business credits, base model usage, 5 GB storage)",
"publicly_reported_metrics": [
"Starter $20 per person/month",
"Standard $100 per person/month with 5 agents always on and 10,000 business credits"
],
"strength_of_evidence": "high",
"limitations": [
"Per-seat pricing on the customer's own people is a software model - the customer remains responsible for directing the work",
"Included as a comparison case to contrast with AI-native service pricing",
"No published outcome metrics"
],
"sources": [
"https://trydock.ai",
"https://trydock.ai/pricing",
"https://www.ycombinator.com/companies/dock"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-assisted (software the customer operates)",
"spectrum_key": "human_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/94f67a762d3f3ae2966b1300c5b2c0c8e7e007de.png",
"yc_url": "https://www.ycombinator.com/companies/dock",
"yc_one_liner": "AI agents that run your business.",
"team_size": 2,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"B2B",
"AI"
]
},
{
"company_name": "RamAIn",
"yc_batch": "Winter 2026",
"website": "https://ramain.ai",
"industry": "B2B",
"service_category": "Digital workers that operate portals and legacy systems (AI employees)",
"classification": "ai_native_service",
"traditional_service_replaced": "Human back-office operators working inside portals, legacy systems and spreadsheets",
"target_customer": "Enterprises (mortgage lender, marketplace, industrial materials, B2B sourcing, healthcare billing, used-car marketplace cited)",
"customer_purchases": "'AI Employees with a computer to perform business tasks' - work performed inside the customer's systems",
"ai_workflow": [
{
"step": "Digital worker sign-in",
"description": "'Digital workers sign in to your portals and legacy systems and do the manual work your team does today.'",
"execution_mode": "ai",
"evidence_url": "https://ramain.ai"
},
{
"step": "Task execution",
"description": "'If your team does it on a computer, Ramain can do it.'",
"execution_mode": "ai",
"evidence_url": "https://ramain.ai"
},
{
"step": "Benchmarked performance",
"description": "Company benchmark: RamAIn completed 89% of 85 enterprise tasks at 1x cost, vs Claude Code 87% at 1.7x and Codex 86% at 3.3x.",
"execution_mode": "ai",
"evidence_url": "https://ramain.ai"
},
{
"step": "Human oversight",
"description": "The product is deployed as an AI employee alongside the customer's team; supervision detail is not published on the captured pages.",
"execution_mode": "human",
"evidence_url": "https://ramain.ai"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Not captured (pricing page exists); sold as AI employees replacing manual computer work",
"publicly_reported_metrics": [
"89% of 85 enterprise tasks completed (RamAIn) vs 87% (Claude Code) and 86% (Codex)",
"Cost per task: RamAIn 1x vs Claude Code 1.7x and Codex 3.3x",
"Running daily work for a national mortgage lender and other named enterprise types"
],
"strength_of_evidence": "medium",
"limitations": [
"The benchmark is self-run and compares agent harnesses rather than business outcomes",
"Pricing not captured",
"Named customers are described by category rather than company",
"Human oversight model not documented"
],
"sources": [
"https://ramain.ai",
"https://ramain.ai/customers",
"https://www.ycombinator.com/companies/ramain"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/1a10a6d3695c38f916de546238a447f1633ea982.png",
"yc_url": "https://www.ycombinator.com/companies/ramain",
"yc_one_liner": "RamAIn - AI Employees with a computer to perform business tasks just…",
"team_size": 7,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": [
"Robotic Process Automation",
"Automation",
"AI"
]
},
{
"company_name": "Jarmin",
"yc_batch": "Fall 2025",
"website": "https://jarmin.ai/",
"industry": "B2B",
"service_category": "AI employees for human-level roles (managed AI workforce)",
"classification": "ai_native_service",
"traditional_service_replaced": "Hiring and managing staff in defined roles: ML engineer, financial analyst, account executive, compliance analyst, data analyst, project manager, paralegal",
"target_customer": "Companies wanting capacity in specific roles without hiring",
"customer_purchases": "A managed AI employee that 'learns the job and your standards, works in the tools you already use'",
"ai_workflow": [
{
"step": "Role setup",
"description": "'We set up your AI employee, and it gets to work.' The customer selects a role or builds a custom one.",
"execution_mode": "hybrid",
"evidence_url": "https://jarmin.ai/"
},
{
"step": "Scoped execution",
"description": "'Owns the work inside an agreed scope, produces reviewable output, and escalates the decisions that require you.'",
"execution_mode": "ai",
"evidence_url": "https://jarmin.ai/"
},
{
"step": "Tool operation",
"description": "The AI employee 'works in the tools you already use'.",
"execution_mode": "ai",
"evidence_url": "https://jarmin.ai/"
},
{
"step": "Escalation",
"description": "'escalates the decisions that require you' - human decisions retained for consequential calls.",
"execution_mode": "human",
"evidence_url": "https://jarmin.ai/"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Not captured (pricing page exists); sold as AI employees replacing role-based headcount",
"publicly_reported_metrics": [
"Role catalogue: ML Engineer, Financial Analyst, Account Executive, Compliance Analyst, Data Analyst, Project Manager, Paralegal",
"ML engineering offering covers models, evals and RL environments"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing not captured",
"No published client outcomes or accuracy figures",
"Role scope and quality control are described in marketing terms only"
],
"sources": [
"https://jarmin.ai/",
"https://jarmin.ai/pricing",
"https://www.ycombinator.com/companies/jarmin"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/a48984c0a7bc281e9b076876c8d571aaf44c799e.png",
"yc_url": "https://www.ycombinator.com/companies/jarmin",
"yc_one_liner": "AI Employees for human-level roles",
"team_size": 5,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": []
},
{
"company_name": "Openroll",
"yc_batch": "Fall 2025",
"website": "https://www.openroll.com",
"industry": "B2B / HR",
"service_category": "AI workforce for People and Finance teams",
"classification": "ai_native_service",
"traditional_service_replaced": "People/HR and finance operations work: headcount planning, actuals vs budget tracking, compensation and workforce reporting",
"target_customer": "People and Finance teams (Notion, Wallenstam cited)",
"customer_purchases": "An AI workforce that connects to the customer's people systems and runs planning and reporting work",
"ai_workflow": [
{
"step": "System connection",
"description": "'Openroll connects to your pe[ople systems]' - integration into existing HR/finance data.",
"execution_mode": "ai",
"evidence_url": "https://www.openroll.com"
},
{
"step": "Headcount planning",
"description": "'See your headcount live, track it against your plan, forecast hiring costs, and understand what's driving variance down to the team, manager, or individual level.'",
"execution_mode": "ai",
"evidence_url": "https://www.openroll.com"
},
{
"step": "Actuals vs budget",
"description": "'Track actuals against budget in real time and instantly understand what's driving variance down to the underlying data.'",
"execution_mode": "ai",
"evidence_url": "https://www.openroll.com"
},
{
"step": "Human use of output",
"description": "Customer quote: 'They ship fast, automate the busy work, and free our lean team to focus on high-impact work.'",
"execution_mode": "human",
"evidence_url": "https://www.openroll.com"
}
],
"human_involvement": "Human-led with AI assistance (the team uses the outputs; automation removes busywork)",
"business_model": "Not captured (pricing page exists); 'Try Openroll' with an application to join",
"publicly_reported_metrics": [
"Named customers: Notion (Head of Total Rewards), Wallenstam (Head of HR)",
"Customer quote: 'What used to take hours of modeling now takes seconds'"
],
"strength_of_evidence": "medium",
"limitations": [
"The offering reads as an AI-powered platform the team operates, closer to a tool than a delivered service",
"Pricing not captured",
"No published accuracy or automation-rate metrics"
],
"sources": [
"https://www.openroll.com",
"https://www.ycombinator.com/companies/openroll"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 2,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/e85636cc8d85e40e183c3547b34d3f05a5aa19c6.png",
"yc_url": "https://www.ycombinator.com/companies/openroll",
"yc_one_liner": "The AI workforce for People and Finance teams",
"team_size": 4,
"locations": "Stockholm, Stockholm County, Sweden",
"status": "Active",
"yc_tags": [
"B2B",
"Productivity",
"HR Tech",
"Enterprise Software",
"AI"
]
},
{
"company_name": "Pollen",
"yc_batch": "Winter 2026",
"website": "https://www.pollen.cx/",
"industry": "B2B / Fintech",
"service_category": "AI employees trained on a firm's workflows",
"classification": "ai_native_service",
"traditional_service_replaced": "Repetitive knowledge work in wealth management, accounting/tax, private equity, insurance and family offices",
"target_customer": "Wealth management, accounting and tax, private equity, insurance, family offices",
"customer_purchases": "An AI employee ('Pollenator') trained on the firm's exact workflows that accepts work by email or chat",
"ai_workflow": [
{
"step": "Workflow training",
"description": "'Give Paul examples of your workflows. Get them automated perfectly.'",
"execution_mode": "hybrid",
"evidence_url": "https://www.pollen.cx/"
},
{
"step": "Document intake",
"description": "Inputs include Client_Statements.pdf, Risk_Profile.docx feeding a household master record (e.g. 'Client Walker Household, Assets $8.4M, Risk band B').",
"execution_mode": "ai",
"evidence_url": "https://www.pollen.cx/"
},
{
"step": "Delegation by email or chat",
"description": "'Delegate like a teammate - Send work by email or chat, no special interface or prompting required.'",
"execution_mode": "ai",
"evidence_url": "https://www.pollen.cx/"
},
{
"step": "Quality positioning",
"description": "'Other AI leaves your team to check, correct, and finish the output' - Pollen positions its output as needing less rework.",
"execution_mode": "ai",
"evidence_url": "https://www.pollen.cx/"
}
],
"human_involvement": "AI-led execution with exception-based human review",
"business_model": "Not captured (pricing page exists); sold as hiring an AI employee",
"publicly_reported_metrics": [
"Documented workflow example producing a household master record"
],
"strength_of_evidence": "medium",
"limitations": [
"Pricing not captured",
"No published client outcomes or accuracy metrics",
"The 'less rework than other AI' claim is a competitive assertion, not measured evidence"
],
"sources": [
"https://www.pollen.cx/",
"https://www.ycombinator.com/companies/pollen"
],
"last_verified": "2026-10-28",
"spectrum_label": "AI-led service delivery",
"spectrum_key": "ai_led",
"autonomy_score": 4,
"logo": "https://bookface-images.s3.amazonaws.com/small_logos/c0773674b66df3e340de671d0a00eeaa6701eeca.png",
"yc_url": "https://www.ycombinator.com/companies/pollen",
"yc_one_liner": "AI employees trained on your firm's workflows.",
"team_size": 3,
"locations": "San Francisco, CA, USA",
"status": "Active",
"yc_tags": []
}
];
