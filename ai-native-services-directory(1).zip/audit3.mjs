import puppeteer from 'puppeteer-core';
const browser = await puppeteer.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--hide-scrollbars'],headless:true});
const page = await browser.newPage();
const errs=[]; page.on('pageerror',e=>errs.push(e.message));

const WIDTHS=[{w:1440,h:900,n:'desktop'},{w:1024,h:900,n:'laptop'},{w:768,h:1000,n:'tablet'},{w:390,h:844,n:'mobile'}];
const VIEWS=['overview','directory','horizontal','spectrum','compare','insights','method'];
const out={};
for(const {w,h,n} of WIDTHS){
  await page.setViewport({width:w,height:h});
  await page.goto('http://127.0.0.1:12000/index.html',{waitUntil:'networkidle2'});
  await new Promise(r=>setTimeout(r,500));
  out[n]={};
  for(const v of VIEWS){
    await page.evaluate(vv=>{document.querySelectorAll('.nav-item[data-v]').forEach(b=>{if(b.dataset.v===vv)b.click()})},v);
    await new Promise(r=>setTimeout(r,350));
    out[n][v]=await page.evaluate(()=>{
      const res={hOverflow:document.documentElement.scrollWidth-window.innerWidth, clipped:[], overlap:[], beyond:[]};
      // clipped text
      document.querySelectorAll('.view:not([style*="none"]) *').forEach(el=>{
        if(el.children.length||!el.textContent.trim())return;
        if(el.scrollWidth>el.clientWidth+2&&getComputedStyle(el).overflow!=='visible'){
          res.clipped.push({cls:String(el.className).slice(0,24),t:el.textContent.trim().slice(0,30),sw:el.scrollWidth,cw:el.clientWidth});
        }
      });
      // elements beyond viewport right
      document.querySelectorAll('.view:not([style*="none"]) *').forEach(el=>{
        const r=el.getBoundingClientRect();
        if(r.width>0&&r.right>window.innerWidth+1) res.beyond.push({cls:String(el.className).slice(0,24),right:Math.round(r.right)});
      });
      // nav / sidebar visibility
      const sb=document.querySelector('.sidebar').getBoundingClientRect();
      const burger=document.querySelector('#btnSidebar')||document.querySelector('[data-burger]');
      res.sidebar={x:Math.round(sb.x),w:Math.round(sb.width),visible:sb.width>0&&sb.x>=-1};
      return res;
    });
  }
  await page.screenshot({path:`shots/${n}.png`,fullPage:false});
}
console.log(JSON.stringify({errs,out},null,1));
await browser.close();
