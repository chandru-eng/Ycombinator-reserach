import json, urllib.request, time, re

APP="45BWZJ1SGC"
h=open('research/raw/companies.html',encoding='utf-8').read()
KEY=re.search(r'"key":"([^"]+)"',h).group(1)
URL=f"https://{APP}-dsn.algolia.net/1/indexes/YCCompany_production/query"
HDR={"X-Algolia-Application-Id":APP,"X-Algolia-API-Key":KEY,"Content-Type":"application/json"}

def q(params):
    req=urllib.request.Request(URL,data=json.dumps(params).encode(),headers=HDR)
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req,timeout=90) as r:
                return json.load(r)
        except Exception as e:
            print("retry",attempt,e); time.sleep(2*(attempt+1))
    raise RuntimeError("failed")

all_hits=[]
page=0
while True:
    r=q({"query":"","hitsPerPage":1000,"page":page,
         "attributesToRetrieve":["name","slug","website","one_liner","long_description","batch","industry","industries","subindustry","tags","all_locations","team_size","status","top_company","launched_at","small_logo_thumb_url","stage","regions","former_names"]})
    hits=r["hits"]
    all_hits.extend(hits)
    print("page",page,"got",len(hits),"total",len(all_hits),"of",r["nbHits"])
    if page+1>=r["nbPages"]: break
    page+=1
    time.sleep(0.5)

json.dump(all_hits,open('research/yc_companies_all.json','w'))
print("SAVED",len(all_hits))
# industry facets
r=q({"query":"","hitsPerPage":0,"facets":["industry","batch"]})
json.dump({"industry":r.get("facets",{}).get("industry",{}),"batch":r.get("facets",{}).get("batch",{})},open('research/yc_facets.json','w'))
print("industries:",len(r.get("facets",{}).get("industry",{})))
