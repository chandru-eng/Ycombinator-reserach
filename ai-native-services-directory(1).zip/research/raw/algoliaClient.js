
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="087ced50-b322-5635-9242-83502ba32262")}catch(e){}}();
import{o as e}from"./rolldown-runtime-C0FnF6B9.js";import{r as t}from"./browserCredentialOwner-PCH5XwGB.js";import{t as n}from"./algoliasearch-BsUxDjUA.js";var r=e(n());function i(){let e={},n=!1;function i(){if(n)return e;if(n=!0,typeof window<`u`)try{!window.AlgoliaOpts||window.AlgoliaOpts.indices_not_set?console.debug(`Algolia indices not set`):e=t(r.default)||{}}catch(e){console.error(e)}return e}return i}var a=i();export{a as t};
//# debugId=087ced50-b322-5635-9242-83502ba32262
