
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b0642019-3825-548d-84ad-7c3ab54f16be")}catch(e){}}();
import{o as e}from"./rolldown-runtime-C0FnF6B9.js";import{t}from"./react-B3wg_K76.js";import{n,r,t as i}from"./emotion-react-jsx-runtime.browser.esm-3hm_-iI-.js";import{w as a}from"./renderMarkdown-FFhz8jVT.js";import{t as o}from"./withRailsContext-DnG90AOL.js";import{t as s}from"./YCAlerts-B5twHjyT.js";import{s as c}from"./NewPage-CDTBMSJD.js";import{t as l}from"./cls-CPxvutoM.js";import{t as u}from"./YouTube.esm-CghaFaIo.js";var d=e(t()),f=[{id:`winter-2027`,title:`Winter 2027`,description:`AI's biggest bottlenecks are moving beyond the models. We're excited about a new wave of startups building the hardware, infrastructure, financial systems, and specialized software needed to bring intelligence into the real economy, from factories and data centers to government and space.`,items:[{id:`startups-in-a-world-of-abundant-space-access`,title:`Startups in a World of Abundant Space Access`,description:`SpaceX is projecting a near future in which there will be 10,000 Starship launches per year.

Already, an expendable Starship is almost as cheap as a **reusable** Falcon 9 and much lower cost per kilogram. As Starship scales and becomes reusable, we are going to see several orders of magnitude reduction in launch costs per kg.

This means it's now time to think about startups for a world of abundant space access. What business models maybe don't quite work today but could work when launch costs fall 100x or more, and the orbital economy takes off? We think those companies should be started now, and if you're a builder with an idea for one, we'd love to see you apply.`,author:{firstName:`Ankit`,lastName:`Gupta`,profileUrl:`https://www.ycombinator.com/people/ankit-gupta`},videoId:`e5W-7cggAg0`,isShorts:!0},{id:`the-15-an-hour-expert`,title:`The $15-an-Hour Expert`,description:`Most people talk about AI replacing workers. We're excited about the opposite: AI that turns an ordinary worker into an expert. We're seeing companies hire smart people without credentials, back them with AI, and have them do work that used to need specialists. Imagine a really good customer service rep who's also really good at using AI suddenly able to consult on complicated mergers and acquisitions, supply chain optimization, or global trade.

There are millions of jobs like this in benefits, taxes, insurance claims, medical billing, and immigration paperwork. Anywhere a credential is the bottleneck, this model works.

The last industrial revolution built a middle class out of factory jobs. This one could build it out of expert jobs. We want to fund the companies that do it.`,author:{firstName:`Brad`,lastName:`Flora`,profileUrl:`https://www.ycombinator.com/people/brad-flora`},videoId:`vaKVoWc3TtY`,isShorts:!0},{id:`robots-made-in-america`,title:`Robots Made in America`,description:`The best robot foundation models are starting to transfer skills from one robot to another, and I think the bottleneck is moving to the hardware.

The U.S. installed 38,400 industrial robots in 2025, up 12 percent, but most robots here are still imported from Japan and Europe. Even the ones assembled here can depend on Chinese magnets. China made 94 percent of the world's sintered rare-earth magnets in 2024, and when it restricted exports in April 2025, some automakers had to cut production.

In July, the FCC stopped authorizing new models of connected mobile robots unless they're made here or get an exemption. To count, more than 65 percent of a robot's component cost has to be domestic, rising to 75 percent in 2029. Assembling imported parts won't get you there.

We want to fund founders building robots and their supply chain here: rare-earth magnets, motors, strain-wave gears, encoders, force sensors, grippers, chips, battery packs, and the machines that make them.

If you're building this, we'd love to talk.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`7adYEc1XkEs`,isShorts:!0},{id:`llms-that-write-well`,title:`LLMs That Write Well`,description:`As LLMs have gotten better at coding and math, they've actually gotten worse at writing. You're not just imagining it: the current models really do sound more robotic than the models from 2024 and 2025.

This appears to be not just a temporary glitch, but a structural issue. The same reward signals that make models good at code actively flatten voice and style.

If forced to choose, the major labs will always choose to focus on coding and agentic workflows over style. This has left an opportunity open for a startup that cares about producing a model that people like talking to. So if this is something you'd like to work on, we'd love to hear from you.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`674Efd5Scfg`,isShorts:!0},{id:`plaid-for-government-benefits`,title:`Plaid for Government Benefits`,description:`If you've ever applied for government benefits, you know how it works. Prove your income. Prove who lives with you. Prove where you live. Then do it all again for the next program, and again at renewal.

Every agency has its own portal, and none of them share data. People get rejected over a missing document. Government workers check pay stubs by hand.

The same system that keeps honest people out also lets fraud in. The Government Accountability Office estimates fraud costs the federal government up to half a trillion dollars a year. Now AI can forge a pay stub in seconds.

Before Plaid, every fintech app built its own bank connections. After Plaid, all it took was one tap. The government needs the same layer.

With your consent, it pulls verified income, tax, and residency records straight from the source, into every program at once. Verify once, apply everywhere. The right people get approved faster, and fraudsters have nothing to fake.

Starting in 2027, states must re-check millions of Medicaid enrollees every six months. And soon AI agents will handle enrollment, but only if they can trust the data.

Whoever builds these pipes will own the infrastructure for our safety nets. If you're building this, we'd love to hear from you.`,author:{firstName:`Gustaf`,lastName:`Alströmer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`3CDvfm9DYjw`,isShorts:!0},{id:`wall-street-for-the-physical-buildout`,title:`Wall Street for the Physical Buildout`,description:`Software is cheap to start. Robots, GPU clusters, and data centers aren't. Somebody has to pay for all that steel and silicon up front, and the financing mostly doesn't exist yet.

Today, banks underwrite a robot like a forklift. Founders we work with are inventing the instruments themselves, like a lender for robots that each earn $500k/year and put options on GPU capacity.

Every great buildout, from railroads to electricity to telecom, created giant financial companies alongside it. We want founders building lenders, leasing companies, securitization, and hedges for the physical AI economy.

If you understand both the machines and the money, we'd love to talk.`,author:{firstName:`Brad`,lastName:`Flora`,profileUrl:`https://www.ycombinator.com/people/brad-flora`},videoId:`KlHzPbZ6PNI`,isShorts:!0},{id:`vertical-foundation-models`,title:`Vertical Foundation Models`,description:`I think Jev hit a nerve because it gives developers a typed decision and a probability instead of generated text, without training a classifier for every task.

I'd like to see more research labs build specialized foundation models for manufacturing, energy, and biology that work zero-shot or from a handful of examples. The bar is matching or beating general-purpose models at orders of magnitude less inference compute, so they're cheap enough to run on everything.

For example, Google's TimesFM-3 shows what this looks like for forecasting. It's a 330M-parameter model that forecasts related time series at once with no task-specific fine-tuning and outputs the whole forecast in one forward pass. Training happens once, and each new user brings their own history as context.

The hard part is getting high-quality, vertical-specific, verifiable rewards. You'll need rights to the data and a clear win in accuracy and compute over existing specialist models. If you know a field well enough to build its model, we'd like to hear from you.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`LI9NqE2iIqg`,isShorts:!0},{id:`ai-for-city-hall`,title:`AI for City Hall`,description:`If you want to build a house or start a business in America, you first need permission from your city. Forms, plan reviews, inspections, and many months of waiting. In some cities, getting the permit takes longer than building the house.

City staff are buried in repetitive work: checking drawings against the code, matching applications to zoning rules, sending corrections back and forth. AI models can do all of this.

And the delay really matters. Every month of waiting makes projects more expensive, and some just never get built. Every new building pays property tax for decades. We did some math: if all building permits in America were approved in 10% of the current time, US cities would make $16 billion a year in additional tax revenue.

We want to fund companies that let AI help run City Hall. Start with permits, but also take on 311, public records, licensing, and inspections.

There are 19,000 cities in America, and almost all of them still do all this by hand. The conventional wisdom says you can't sell software to government. That used to be true. It isn't anymore. YC has funded several companies selling AI to government, and some of them are growing faster than almost anything else we've seen.

If you're building this, we'd love to hear from you.`,author:{firstName:`Gustaf`,lastName:`Alströmer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`VoSVN7H07-Q`,isShorts:!0},{id:`data-center-supply-chain`,title:`Data Center Supply Chain`,description:`The AI data center buildout is the largest capital investment project in American history - bigger than the railroads, the highways, and the Manhattan Project - combined.

A buildout that large creates opportunities up and down the supply chain. Some of them are famous - everyone knows that there's unprecedented demand for GPUs, electrical power, and skilled electricians.

There are also many non-obvious bottlenecks. Large power transformers have a three-year lead time. Switchgear, circuit breakers, and liquid cooling equipment are all sold out. Even raw materials are under pressure: the grain-oriented electrical steel that's used in transformer cores is made in only a single plant in the US, and they're unable to keep up.

We're interested in funding companies that are enabling every aspect of the data center supply chain. If that's something you're working on, we'd love to hear from you.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`9EJM4LNMK0I`,isShorts:!0},{id:`ai-for-the-air-gapped-economy`,title:`AI for the Air-Gapped Economy`,description:`The most valuable data in the world isn't in the cloud. Defense contractors, banks, hospitals, and nuclear plants keep it behind walls, and they can't send it to an AI API.

That's why so much of the economy is still waiting on AI. Founders we work with keep hitting the same wall: the customer loves the product and wants it running entirely inside their own building, with no internet connection.

We want to fund the companies that bring frontier AI inside those walls. That means on-prem models, deployment tooling, security accreditation, and hardware.

It's slower and harder to sell. It's also where the largest budgets and the most defensible companies are. If you're building this, we'd love to talk.`,author:{firstName:`Brad`,lastName:`Flora`,profileUrl:`https://www.ycombinator.com/people/brad-flora`},videoId:`x21EgQzfZaM`,isShorts:!0},{id:`own-your-intelligence`,title:`Own Your Intelligence`,description:`Today, nearly every company building with AI rents its intelligence. You send tokens to a frontier lab, get answers back, and pay the bill. That was an easy trade when the best models were years ahead of everything else, and nothing you did with your own data could close the gap.

That has changed. Open-weight models are now competitive with the top frontier models on meaningful benchmarks. And as AI moves to the center of how businesses run, companies have become more aware of their dependency on model rental.

We think more companies will want to own the models they rely on: improve them on their own data, run them where they choose, and decide for themselves when they change. This matters most in regulated industries, where strict data governance and locked-down infrastructure make renting even more expensive for the performance they get.

But there's still a big gap between downloading an open model and owning intelligence that improves a business. Someone has to turn workflows into evals, expertise into training data, production failures into improvements, and carry all of it forward with each new base model.

Companies will keep renting frontier intelligence for their hardest problems, but we think many will also own specialized models that encode how their business works and that become more valuable as the business learns.

If you're helping companies own their intelligence, we want to hear from you.`,author:{firstName:`Jon`,lastName:`Xu`,profileUrl:`https://www.ycombinator.com/people/jon-xu`},videoId:`DzblM1Mc-J8`,isShorts:!0}]},{id:`fall-2026`,title:`Fall 2026`,description:`AI is moving into the physical world. We're excited about a new wave of startups rebuilding the systems that power the real world, from education and healthcare to defense, finance, infrastructure, and work itself. This batch's requests come from YC partners and founders building on the frontier, and include, for the first time, one from the sitting U.S. Secretary of the Army.`,items:[{id:`the-primer`,title:`The Primer`,description:`In Neal Stephenson's The Diamond Age, a young girl is given an interactive book called A Young Lady's Illustrated Primer. It looks like a tool for learning to read, but it's far more. It adapts to her completely, and through stories tuned to her life, it teaches her not just to read but to think, to reason, and eventually to grapple with the hardest questions of ethics, meaning, and character. She returns to it day after day for years, and as she grows, it grows too. Continually reshaping itself around who she is becoming and the life she is living.

For the first time in history, something like the Primer is starting to feel possible.

The best education has always come from one-on-one tutoring. Aristotle taught Alexander. But that privilege has been reserved for the few. AI can bring it to every child. And great tutors do more than drill facts. Over years, they learn a child's mind, and with it how to teach what can't be drilled at all: thinking, reasoning, even wisdom.

In Stephenson's story, the Primer is an AI tutor that never runs out of patience or time. We're a long way from building one, but we can start today. What we'd love to see now is a product that adaptively teaches young children to read, write, and do arithmetic, at the quality of a devoted private tutor and at consumer scale. Not a replacement for teachers, but a supplement that makes them more effective.

While we think this begins as something a parent buys to help their child learn basic skills, it is also the entry point to far greater ambitions. A company that gets it right could build toward something like the Primer, and even a fraction of that vision would have a profound effect on society.

If you're building this, we'd love to hear from you.`,author:{firstName:`Andrew`,lastName:`Miklas`,profileUrl:`https://www.ycombinator.com/people/andrew-miklas`},videoId:`e7TyxRj-GDU`,isShorts:!0},{id:`the-future-of-american-defense`,title:`The Future of American Defense`,description:`Warfare is at an inflection point, and the old ways of Army acquisition simply don't keep pace with modern threats. Modern combat demands commercially developed, modular open-system solutions, and that's why we ripped up the old acquisition playbook.

We need hungry, innovative founders to build for the crucible of ground combat. The threats we face change daily, and the Army must dominate everywhere, from the Arctic to the archipelago and from space to subterranean environments. So here is our request for startups. We are actively funding low-cost interceptors or any component that helps us lower the cost per kill.

We need next-gen sensors, software, payloads, and other hardware that plugs directly into our open system architecture. We need cutting-edge drones, resilient logistics, and advanced manufacturing, and we need it all to survive the most extreme climates on Earth. Bring us your ideas, and we will give you the capital and the proving ground to scale.

There has never been a better time to build for the Army. The door is wide open, so let's get to work.`,author:{firstName:`Daniel P.`,lastName:`Driscoll`,title:`US Secretary of the Army`,profileUrl:`https://www.army.mil/leaders/sa/`},videoId:`iOeW40N-1VI`,isShorts:!0},{id:`a-cloud-for-small-software`,title:`A Cloud for Small Software`,description:`Using agents to build personal software to solve your own problems is a lot of fun.

This is "Small Software". Purpose-built tools that will only ever have one or a small handful of users.

Small software is useful for teams too: Every team does things differently, and there's unlimited demand for bespoke tools for running workflows, tracking important numbers, managing sprints, sharing prototypes, and so on.

Software like this is now very easy to build, but still hard to deploy and share.

Incumbent clouds like Azure and AWS were designed for shipping Big Software that scales with many users… at the cost of complexity.

A cloud designed for small software could delete most of this complexity and unlock a big set of new use cases that agents have only recently made possible.

At the same time, there are other hard problems to solve: every company will want to customize the environment this software runs in, auth & permissions are hard, and allowing nontechnical users to share arbitrary code is tricky to do securely.

Small software should be as easy to share with your colleagues as a Google Doc.

If you're working on something like this, we'd love to hear from you.`,author:{firstName:`Pete`,lastName:`Koomen`,profileUrl:`https://www.ycombinator.com/people/pete-koomen`},videoId:`G3WEOXKN2SI`,isShorts:!0},{id:`multiplayer-ai`,title:`Multiplayer AI`,description:`The best work tools of the last two decades won by going multiplayer. Google Docs replaced Microsoft Word. Figma beat Photoshop. And they turned solo tools into places where teams do their best work together.

But AI hasn't had its multiplayer moment yet.

AI agents are the most powerful new tool a team has, but it's the one thing people still use by themselves. That's because right now, working with AI is largely single-player. You open a chat, type a prompt, and get an answer, in a box only you can see. When you want to collaborate with your teammates and agents, the best you can do is send a link to a read-only transcript they can't touch.

That's about to change.

Agents are starting to run tasks that take hours, days, even weeks. Work at that scale was never meant to be done alone, and pulls in many people across a company. Anyone on a team should be able to drop into the same live agent session to watch it work, redirect it, and hand it off, the way they'd work with any other human team member. This turns the work a team does with agents into a shared, living thing instead of a thousand private threads.

We think there's a version of this for every kind of work. Shared agents for engineers coding together in real time. For sales teams working a deal together. For support teams resolving a ticket. For lawyers drafting a contract, analysts building a model, and marketers shipping a campaign. Anywhere a team already crowds around one problem, there should be multiplayer agents they all share.

So if you're building AI that's multiplayer by default, we'd love to hear from you.`,author:{firstName:`Aaron`,lastName:`Epstein`,profileUrl:`https://www.ycombinator.com/people/aaron-epstein`},videoId:`CzQbI8_bBEs`,isShorts:!0},{id:`compute-at-sea`,title:`Compute at Sea`,description:`Artificial intelligence is running out of compute. And data centers are running out of electricity and land.

The demand for data centers is insatiable. But new data centers can take years for approval and enough megawatts, and still could get killed by local government intervention.

While communities increasingly oppose the land, the water is open.

It sounds crazy, but we think part of the answer may be to move compute offshore.

The ocean is 70% of the Earth's surface area, has abundant sunlight, no permitting process, and is an enormous natural heat sink that is already getting hit by the sun all day anyway. Think of them as compute flotillas: many standardized, modular vessels operating together as one global cloud.

We want to fund founders who are bringing the world's compute to the oceans.`,author:{firstName:`Francois`,lastName:`Chaubard`,profileUrl:`https://www.ycombinator.com/companies/focal-systems`},videoId:`xZW8fR9ediE`,isShorts:!0},{id:`ai-powered-consumer-products-for-1-billion-people`,title:`AI-Powered Consumer Products for 1 Billion People`,description:`Every platform shift mints consumer giants. The web gave us Google + Airbnb. Mobile gave us Instagram + DoorDash. AI is the biggest shift YET. But three years in, the only new icon on your home screen is ChatGPT.

So why do we think NOW is a great time to build AI-powered consumer products? Intelligence just got good enough: you can treat an agent like a person. And it's about to get cheap enough, too: today, the magic can run $1,000 a month in tokens for each user, but that is falling 10x a year. Follow the curve, and you can predict the consumer moment: it lands very soon. Whoever builds now, owns it.

What do you build? How we get things done, get around, learn, stay healthy, manage our money, play, connect with friends. It all opens up again.

CONSUMER is going to be so back. If you're building for a billion people, we'd love to hear from you.`,author:{firstName:`Raphael`,lastName:`Schaad`,profileUrl:`https://x.com/raphaelschaad`},videoId:`eY20SPBpQEg`,isShorts:!0},{id:`ai-for-the-aging-population`,title:`AI for the Aging Population`,description:`By 2030, one in five Americans will be over 65, and there's nowhere near enough people to take care of everyone. The US is projected to have millions of unfilled caregiving jobs within the decade, and 53 million family members are already doing this work unpaid.

Meanwhile, almost no technology is actually built for older people. Even Alexa and Google Home are frustrating for most seniors to use.

AI finally makes a new class of products possible: voice interfaces that can hold real conversations, monitoring that helps older adults stay safe and independent, robotics that can assist with physical tasks around the home, and software that helps family caregivers coordinate care, appointments, and emergencies.

This is one of the largest, most underserved markets in the world, and it's growing every single day. If you're building for the aging population, we'd love to hear from you.`,author:{firstName:`Max`,lastName:`Kolysh`,profileUrl:`https://x.com/maxkolysh`},videoId:`WUDIBATKh4Y`,isShorts:!0},{id:`new-operating-systems-for-the-physical-world`,title:`New Operating Systems for the Physical World`,description:`80% of the global workforce doesn't sit at a desk.

But the software for the physical world hasn't really changed in over 20 years. In construction, maintenance, and fleet operations, the software basically does some combination of: dispatching people, tracking them, managing assets, and billing the customer.

We're excited about how AI changes that entire model of work.

There are now three kinds of workers:
- AI agents that can quote complex work and schedule teams.
- Robots actually deployed in the field.
- And humans who increasingly use wearables to record everything they're doing.

Today's operating systems weren't designed to manage all three types of workers. And this creates all sorts of cool new opportunities for a startup. How do you route a job between an agent, a robot, and a person? What does safety look like when humans and robots work literally side-by-side? And how do you measure reliability?

The opportunity here is heck of a lot bigger than the existing software. The incumbents charge for human coordination and visibility. The new operating systems will manage the robot and human labor together. And these industries spend 10 to 100x more on labor than software.

There's another reason you should build here. You'll record all the work as it actually happens. The frontier models, robotics startups, or software incumbents won't have that kind of end-to-end data.

So if you're building this new kind of operating system for the physical world, we'd love to hear from you.`,author:{firstName:`Charlie`,lastName:`Warren`,profileUrl:`https://x.com/charliewarren`},videoId:`V_gDce8hBrg`,isShorts:!0},{id:`the-best-time-to-build-in-crypto`,title:`The Best Time to Build in Crypto`,description:`It's a dispiriting moment in crypto: prices are down, hot narratives have fallen flat, and many builders are leaving.

It sounds crazy, but at Y Combinator we're more optimistic than ever. We've invested in more than 100 crypto startups, but we expect that number to go up a lot. Eventually, we expect every YC startup to use crypto rails from capital raising to payments, though most will probably never even know. Here's why we're bullish.

Many YC-funded fintechs way outside crypto are building on crypto, like Deel and Gusto. Regulatory clarity is finally here, stablecoins are being adopted by every major financial institution, tokenized stocks are transforming trading. Projects like Hyperliquid, with a tiny team, are making the top stock exchanges squeamish about their edge. And it feels inevitable that agents are going to use crypto networks as financial rails.

Just as importantly, bear markets let the real projects build and thrive while bull markets are the worst time to build. In crypto, prices are decoupled from reality. In bear markets, you don't need to compete with a criminal offering infinite yield. They attract a different type of founder, more focused on building than getting an early liquidity event.

We've funded major teams building in crypto like Stripe, Coinbase, and Axiom, but also lots of infrastructure and bets on the future. For example, BlindPay and Infinia are building the developer interface and ramps for Latin America. Aspora is building the easiest way to transfer money to India.

Just some of the things we're excited about are capital raising, new stablecoins and stablecoin applications, agentic commerce, trading, institutional products, and scalable and private blockchains.`,author:{firstName:`Nemil`,lastName:`Dalal`,profileUrl:`https://x.com/nemild`},videoId:`M861XfrOR5s`,isShorts:!0},{id:`data-for-the-real-world`,title:`Data for the Real World`,description:`AI has gotten remarkably good at learning from data. We now have superhuman models for code, language, and images. But for the physical world? We're still working with sparse data from remote sensors designed for humans, not AI. With improving foundation models and plummeting sensor costs, dense physical-world data collection is now feasible.

And it's happening. Gecko Robotics uses robots to collect data in hard-to-reach places and builds predictive models. At Sorcerer, we use autonomous weather balloons to collect data about the atmosphere, which the US government uses to make better weather forecasts.

And the opportunity is much bigger.

The world's biggest industries are in energy, agriculture, logistics, and construction. They rely on limited data and intuition-based models. More real-world data enables precise modeling. And once you can model a system, you can control it. Steering hurricanes. Reversing desertification. Cooling the planet.

We're interested in more companies like Sorcerer building new ways to collect physical-world data. If you're working on this, we'd love to hear from you!`,author:{firstName:`Austin`,lastName:`Tindle`,profileUrl:`https://www.ycombinator.com/companies/sorcerer`},coauthor:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`uW7RxkLRsd0`,isShorts:!0},{id:`proving-youre-human`,title:`Proving You're Human`,description:`Recently, a finance worker joined a video call with his CFO and several colleagues, and wired out $25 million. Every other person on that call turned out to be a deepfake. This isn't science fiction anymore. Voice clones and fake video calls are getting cheap and ultra-realistic, and fraud like this is exploding.

The scary part is we don't have a good way to tell who's real anymore. It used to be that if you saw someone's face or heard their voice, that was enough. Not anymore. Every trust signal we have was built for a world where faking a human was expensive, and that world is gone.

So we think one of the most important problems of the next decade is rebuilding the trust layer of the internet: knowing there's a verified human on the other end of a call, a message, a transaction. We don't know exactly what the solution looks like. Ideally it's one that doesn't make everyone give up their privacy. And it's not just about stopping scams. Imagine Twitter with no bots in the replies, dating apps where every match is a real person, and reviews written by people who actually bought the thing.

Whoever builds this becomes the layer every bank, app, and video call checks before it trusts anyone. If you're working on this, we'd love to hear from you.`,author:{firstName:`Max`,lastName:`Kolysh`,profileUrl:`https://x.com/maxkolysh`},videoId:`nB7QBdjrOwE`,isShorts:!0},{id:`ai-native-compliance-infrastructure`,title:`AI-Native Compliance Infrastructure`,description:`Financial compliance is still stitched together with spreadsheets, siloed tools, and expensive headcount. Companies hire chief compliance officers and assemble stacks of point solutions just to understand what's happening under the hood. As businesses expand into new markets, the complexity compounds and the cost of staying compliant grows faster than revenue.

This is an AI-native problem. Most compliance work is monitoring regulatory changes, flagging anomalies, generating reports, and keeping audit trails. These are tasks that AI can handle faster and cheaper than humans. Yet most solutions today are still built around manual workflows and human review bottlenecks.

The pain is especially acute for businesses navigating state-by-state licensing, renewal cycles, audits, and regulatory patchwork that varies widely across jurisdictions. The current process is slow, fragmented, and expensive, often requiring dedicated legal teams just to maintain what you already have.

We're looking for founders building compliance infrastructure that consolidates fragmented tools, reduces reliance on specialized headcount, and gives finance teams real-time visibility across regulatory regimes. The best version of this doesn't just automate existing processes, but rethinks what compliance operations look like when AI is the default.

The companies that get this right will become essential infrastructure for any business operating globally. If you're building in compliance infrastructure, please apply!`,author:{firstName:`Daivik`,lastName:`Goel`,profileUrl:`https://www.ycombinator.com/companies/shor`},videoId:`BSElxGxgoIA`,isShorts:!0},{id:`self-maintaining-apis`,title:`Self-Maintaining APIs`,description:`Over the past year, I've worked with over 50 API vendors, mostly early-stage startups. One pattern is consistent: API communication is broken.

Breaking changes ship with little warning. Useful features quietly launch and go unnoticed. Changelogs don't get read. Heck, when I worked at AWS, over 30% of our service downtime was due to external api/package changes going unnoticed. This friction made sense before agentic coding tools existed. However, now it doesn't.

Agentic coding tools like Claude Code, Devin, Greptile, etc prove that developers and enterprises are willing to give codebase access to external tools, provided they're valuable. Two years ago, this was unthinkable. Now it's standard practice.

The infrastructure for automated code changes exists. What's missing is the application layer connecting API providers to their customers' codebases. API providers shouldn't just announce changes; they should apply them.

When Stripe ships a breaking change or a new feature, an agent should scan customer codebases, identify affected usages, and open a PR with the fix.

This could work as per-provider agents. "Install Stripe's update agent", or as a neutral third-party service tracking changes across vendors, like Dependabot but for APIs. If you're working on this, consider applying to YC.`,author:{firstName:`Harsha`,lastName:`Gaddipati`,profileUrl:`https://www.ycombinator.com/companies/slashy`},videoId:`c3TxAUir2R8`,isShorts:!0}]},{id:`summer-2026`,title:`Summer 2026`,description:`AI has stopped being a feature and started being the foundation. We're excited about a new wave of startups rebuilding software, services, and silicon— and pushing AI into the physical world. Several come directly from YC founders sharing what they're seeing on the frontier.`,items:[{id:`ai-for-low-pesticide-agriculture`,title:`AI for Low-Pesticide Agriculture`,description:`Modern agriculture runs on chemicals.

That worked for a while. But now the cracks are obvious. Pesticide residues are everywhere: in food, in water, in soil. People worldwide are worrying about long-term health risks with glyphosate.

At the same time, nature is adapting. Weeds and pests evolve. What used to work stops working. So farmers spray more. Costs go up. Margins go down. The pipeline for new chemicals? Slower and more expensive than ever.

Farmers are stuck in a bad loop: Use more chemicals → get diminishing results → pay more → take on more risk. And yet they can't just stop. If pests win, crops die. Food prices go up. People might starve. It's existential.

For a long time, this looked like an unsolvable problem. Now it doesn't.

A few things changed all at once:

AI can now see. It can identify individual weeds and pests in real time.
Sensors and cameras got cheap enough to put everywhere.
Robotics can act with precision, treating one plant instead of blanketing an entire field.

And biology is catching up too:

Microbes, peptides, RNA-based solutions; these aren't science fiction anymore. They can replace entire classes of synthetic chemicals. We can engineer plants to defend themselves. To outcompete weeds. To need less external input. And of course, so is AI. Real science breakthroughs will be augmented by AGI, and now's the time to see it.

This is a massive shift. Agriculture is one of the biggest markets in the world. If you can lower costs and increase yields at the same time, adoption isn't slow. It's explosive.

The company that cuts pesticide use by 90% **and** helps farmers grow more food?
That's not just a good business. That's a generational company.

If you're working on this, if you're building tools that help farmers produce more with fewer chemicals, we want to talk.`,author:{firstName:`Garry`,lastName:`Tan`,profileUrl:`https://www.ycombinator.com/people/garry-tan`},videoId:`uwe-5PB9p4Y`,isShorts:!0},{id:`ai-native-discovery-engines`,title:`AI-Native Discovery Engines`,description:`For centuries, scientific discovery has run on the same loop: hypothesize, experiment, interpret, repeat. The loop works, but it's slow—and every step requires significant human effort to advance.

That's changing fast as frontier models have reached PhD-level performance on many scientific reasoning benchmarks. Models can now assist researchers in proposing hypotheses, generating experiments, analyzing data, and suggesting next steps in discovery. Increasingly, the frontier is shifting from copilot research assistants to intelligent systems that can run closed discovery loops.

We're already seeing this in specific domains. In drug discovery, materials science, and protein engineering, intelligent systems are starting to run the full design-make-test-analyze loop: models propose candidate molecules, automated labs synthesize and test them, and the results feed back in to iteratively improve candidates.

The companies that make meaningful contributions to scientific progress won't just sell research copilots. They'll be AI-native discovery engines that work alongside researchers to propose and validate hypotheses. If you're building this, we want to talk to you.`,author:{firstName:`Jon`,lastName:`Xu`,profileUrl:`https://www.ycombinator.com/people/jon-xu`},videoId:`mcXrvjPKJas`,isShorts:!0},{id:`ai-native-service-companies`,title:`AI-Native Service Companies`,description:`AI models are improving really fast, and they're now able to do complex work far beyond engineering.

Historically, services became SaaS software. More recently, they became AI copilots. That's what most startups from 2023 to 2025 built: tools that help people do their jobs.

What we're excited about now is the next step:

AI-native companies that don't sell software—they sell the service. Instead of giving you a tool, they just do the work.

The reason this matters is simple. The total spend on services is many times larger than the spend on software. And a lot of these services are already outsourced, which makes them much easier to replace with an AI-native product.

We're especially interested in areas like:
- Insurance brokerage
- Accounting, tax, and audit
- Compliance
- Healthcare administration

If you're building a company that replaces a service—not just improves it—we'd love to hear from you.`,author:{firstName:`Gustaf`,lastName:`Alströmer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`lsRnwM_ZdJY`,isShorts:!0},{id:`ai-personalized-medicine`,title:`AI Personalized Medicine`,description:`Intelligent agents are enabling a new level of personalization in medical care. We can now use an agent harness like Claude Code to analyze personalized health data, whether that be a diagnostic test, genome scan, EHR data, or wearables information to get highly accurate, user-specific suggestions.

At the same time, two big revolutions in science are occurring.

First, the cost of generating personalized diagnostics is plummeting. The cost of genome sequencing has fallen at a rate faster than Moore's law, and a variety of new diagnostics are entering the market enabling early detection of a variety of health signals.

Second, the cost of printing n of 1 genetic therapies is plummeting. We can now design and deliver personalized medicines through delivery vectors like mRNA, and the FDA has expressed more openness to letting patients try out these procedures.

We think these factors collectively are going to bring about a revolution in care delivery.

Abundant data and intelligence can help patients more accurately assess their disease risk and democratize access to treatments for the most serious illnesses.

To enable this, we believe a wide variety of new startups will support every step of this ecosystem. If you're building for the future of intelligent personalized care, we'd love to hear from you.`,author:{firstName:`Ankit`,lastName:`Gupta`,profileUrl:`https://www.ycombinator.com/people/ankit-gupta`},videoId:`fzVuQ2sYEn8`,isShorts:!0},{id:`company-brain`,title:`Company Brain`,description:`The biggest blocker to AI automation of companies is no longer the models, they just got so good so quickly. Now the blocker is the domain knowledge.

Every company has critical know-how scattered everywhere. Some of it lives in people's heads. Some of it is buried in old email accounts, Slack threads, support tickets, and databases. The company works because humans vaguely remember where that knowledge is and how to apply it.

But AI agents can't operate like that. If we want every company to run on AI automation, we need a new primitive: a company brain.

We need Garry's G-Brain, but for every business in the world. A system that pulls knowledge out of all these fragmented sources, structures it, keeps it current, and turns it into an executable skills file for AI.

This isn't a company-wide search or a chatbot over documents. It's a living map of how a company works: how refunds get handled, how pricing exceptions are decided or how engineers respond to incidents.

Then AI systems can use that skills file to actually do the work safely and consistently.

The company brain becomes the missing layer between raw company data and reliable AI automation.

I think every company in the world is going to need one.

If you're building this, you should apply to YC.`,author:{firstName:`Tom`,lastName:`Blomfield`,profileUrl:`https://www.ycombinator.com/people/tom-blomfield`},videoId:`IaWIazkWWog`,isShorts:!0},{id:`counter-swarm-defense`,title:`Counter-Swarm Defense`,description:`Last month, a swarm of cheap Iranian drones took out an AWS data center. Nobody stopped them.

Now imagine an incoming swarm of a thousand coordinated drones. We'd stand no chance. While everyone is racing to stop individual drones, the next wave is coming and it's worse: not one drone, but swarms. Cheap, autonomous, jam-resistant, and lethal.

A Patriot missile costs three million dollars. An FPV drone? Five hundred bucks. All of the cost advantage lies with the attackers. We are not ready.

Today, counter-drone defense is a messy pile of radars, cameras, jammers, interceptors, humans with binoculars, and systems that don't talk to each other. That might work against a hobby drone. It will not work against a swarm.

I want to fund founders building the counter-swarm stack.

That could mean high-capacity interceptors — a single platform that neutralizes fifty drones, not one. Software that fuses every sensor and every defender on a site into a single real-time picture. We need non-kinetic defenses that don't exist yet: aerosols that foul rotors, streamers that entangle swarms. We need new attacks on the autonomy stack itself now that radio jamming is becoming obsolete.

The key insight is drone defense is looking less and less like operating a weapon and more like running a real-time distributed system. The winning companies will look more like Cloudflare than Raytheon.

If you're working on the future of drone defense, and how we can restore the cost advantage to defenders — we want to hear from you.`,author:{firstName:`Tyler`,lastName:`Bosmeny`,profileUrl:`https://www.ycombinator.com/people/tyler-bosmeny`},videoId:`O8JiNHcI3jI`,isShorts:!0},{id:`dynamic-software-interfaces`,title:`Dynamic Software Interfaces`,description:`Before AI, users of a piece of software all interacted with the same interface. There were only light customizations like a few different views or theme and color options. When users think about "personalization" like on Netflix, it still has the same layout for everyone, just different imagery. As a result, most software has a one-sized-fits-all feel rather than being hypercustomized to a user. As an example: the way I use an email is very different from how most college students use email, yet all email clients look basically the same.

The exception is in enterprise software, where forward deployed engineers customize software for each customer to make it a great experience for them.

We think that coding agents have now gotten good enough to allow users to become their own forward deployed engineers and more radically customize the software they consume. I'm imagining users designing widely different interfaces for their use cases — perhaps my email client looks more like a task list, and a students' looks more like an events calendar. But these two interfaces likely share some underlying primitives and design decisions that a software team can build and ship.

We think that in the future, software companies will ship these shared primitives with full intention that users will heavily modify the final interfaces.

To enable this future, we will have to rethink the whole stack of software delivery. How will a developer make software that can be accessed by the user's coding agents? Do they have to deliver source code rather than packaged binaries? Can they only modify front-end visual elements, or are there ways for them to modify middleware on the fly to enable more interesting use-cases? If you're a radical thinker looking to define the future of software, we'd love to hear from you.`,author:{firstName:`Ankit`,lastName:`Gupta`,profileUrl:`https://www.ycombinator.com/people/ankit-gupta`},videoId:`_2LcG-3zCdY`,isShorts:!0},{id:`electronics-in-space`,title:`Electronics in Space`,description:`We are about to see an absolutely huge increase in the capacity that humanity has to put things in space because of reusable rockets from SpaceX and Stoke Space. This means that we're going to need enormous amounts of new compute capacity in space.

The particular electronics in space we'd like to see is inference chips. There's going to be an absolutely enormous market for inference chips in space. What we mean by chips in space is something that is slightly optimized for mass, slightly optimized for thermal, and slightly optimized for radiation.

If you are working at SpaceX or NVIDIA and you've been spending time doing chip design, then Y Combinator would love to hear from you.`,author:{firstName:`Philip`,lastName:`Johnston`,profileUrl:`https://www.ycombinator.com/companies/starcloud`},videoId:`pAV8f4Snx7Q`,isShorts:!0},{id:`hardware-supply-chain`,title:`Hardware Supply Chain`,description:`We are funding more and more hardware companies, from medical devices to home robots to space companies.

But building hardware in the US is still far too slow compared to China. In Shenzhen, a team can go from design to a new physical part in a day. In the US, that same loop often takes weeks. And that gap compounds.

The problem isn't just the supply chain. It's iteration speed.

China wins because hardware teams can move fast. They have dense supplier networks, rapid turnaround, and tight coordination between design and production. In the US, this system barely exists.

A few startups are starting to build parts of it. For example, Hlabs (W26) is building actuators; Prototyping.io (P26) helps turn designs into mechanical parts in days. But the overall stack is still missing.

We believe the next generation of great hardware companies will be built on much faster iteration loops.

We're especially interested in startups that:
- produce parts dramatically faster
- enable rapid hardware iteration
- tightly integrate design, manufacturing, and logistics

If you're helping hardware teams move at an order of magnitude faster, we want to hear from you.`,author:{firstName:`Nicolas`,lastName:`Dessaigne`,profileUrl:`https://www.ycombinator.com/people/nicolas-dessaigne`},videoId:`0gCeJFyRYx4`,isShorts:!0},{id:`industrial-capabilities-in-space`,title:`Industrial Capabilities in Space`,description:`The broad idea we would like to see is developing industrial capabilities on the moon and in space, particularly extracting raw materials such as silicon, aluminum, iron, and titanium through electrolysis and 3D printing of complex structures from molten regolith on the moon, which should be more efficient than on Earth due to lack of supports.

If you are working on something like that in the space, then Y Combinator would like to hear from you.`,author:{firstName:`Adi`,lastName:`Oltean`,profileUrl:`https://www.ycombinator.com/companies/starcloud`},videoId:`S8Z2v2bxocM`,isShorts:!0},{id:`inference-chips-for-agent-workflows`,title:`Inference Chips for Agent Workflows`,description:`Most AI chips are designed for a world where inference means "prompt in, response out." Agents don't work that way. They loop: calling tools, branching, backtracking, holding context across dozens of steps. That's a completely different hardware problem.

Current GPUs hit 30 to 40 percent of peak utilization on these workloads because the work is bursty, bouncing between memory-bound model calls, I/O-bound tool use, and CPU-bound orchestration. That gap is where purpose-built silicon wins.

NVIDIA bought Groq for $20 billion because it saw this coming. Google built TPU v7 for inference specifically. But nobody's designing for the agent loop itself: fast context switching between models, native speculative decoding, memory built for KV caches that persist across an entire execution graph.

Groq's real insight wasn't the chip. It was the compiler that made the chip work. We think that'll be true for whoever builds this next. If you understand both chip architecture and how agents actually execute, this is a rare moment where both halves of that experience matter.

If you're building inference silicon for agentic AI, we'd love to hear from you.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`4YzFuHk84K0`,isShorts:!0},{id:`saas-challengers`,title:`SaaS Challengers`,description:`Everyone's talking about how AI coding means the end of SaaS. Investors have wiped trillions off software market caps.

Well, that might be bad news for incumbents, but it's good news for startups. If the incumbents really are this vulnerable, it should be the biggest startup opportunity in a decade. So, go build a challenger!

The SaaS model won because custom software was too expensive. A five-person startup couldn't outbuild Salesforce. But AI has collapsed the cost of producing software by 10-100x, and that changes everything. The moat that once protected legacy SaaS — millions of lines of code, built over decades — is gone.

There's a spectrum of ways to attack this. The simplest: clone an existing product and sell it for one-tenth the price. But you can go much further. You can build a product that's AI-native from the ground up. Not a chatbot bolted onto a 2010 UI, but software that fundamentally rethinks the workflow. You can take ten SaaS point solutions and bundle them into a single suite. You can build an open-source replacement for a product that costs $50K per seat and give it away, then monetize through services and hosting.

Most people drawn to this idea start with simple targets like project management tools. We'd encourage you to think bigger. Go after the products that seem invulnerable: chip design software, ERPs, industrial control systems, supply chain management. The giant, 10-million-line codebases that have been untouchable for decades.

The last generation of great software companies was built by replacing on-premise with cloud. The next generation will be built by replacing legacy SaaS with AI-native software.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`DhYJ1GENLoQ`,isShorts:!0},{id:`software-for-agents`,title:`Software for Agents`,description:`The next trillion users on the internet won't be people, they'll be AI agents. And now is the time to "Make Something Agents Want".

Agents are already browsing the web, doing research, making purchases, and managing legacy CRMs – but they're doing it on top of software that was designed for humans clicking buttons in a browser, which is slow, inconsistent, and brittle.

Agents need a completely different foundation. Instead of visual interfaces like forms, buttons, and dashboards, they need machine-readable interfaces like APIs, MCPs, and CLIs. Agents also need thorough documentation, to enable them to discover, sign up for, and instantly start using new tools programmatically, without needing a human in the loop.

That means every major category of software that people use today needs to be rebuilt for agents. And the new agent-first software won't come from incumbents bolting on agent support, it'll come from startups that build explicitly for agents as first-class citizens.

While everyone else is building agents, the biggest opportunity might be building the software those agents depend on. So if you're Making Something Agents Want, we'd love to hear from you.`,author:{firstName:`Aaron`,lastName:`Epstein`,profileUrl:`https://www.ycombinator.com/people/aaron-epstein`},videoId:`515J0QD9p6w`,isShorts:!0},{id:`startups-selling-to-huge-companies`,title:`Startups That Want to Sell to Huge Companies`,description:`One of PG's wisest pieces of advice has always been that startups should sell to other startups. It's always been a hack to quickly get really smart, forward-thinking users that can help you shape your product into something awesome and important.

It turns out there's another type of company that has really smart, forward-thinking buyers but it's one that's been out of reach to startup founders until AI came along: Massive Enterprises. We're not talking about just "big" companies, we're talking about the biggest companies in the world, which, it turns out, are run by incredibly smart, forward-thinking people. It's just always been too hard to get a hold of the right people there, too hard to build a product with the right depth and mix of features for a big company to use quickly and too low ROI for these companies to take on the risk of working with an early stage company.

AI has changed the score on all three of these fronts: the people running these companies, again not just "big companies," but "the biggest companies in the world" F100 size companies, aren't hiding behind their computers, they're out there looking for teams that can bend AI to solve key problems for them. In the last 3 years for the first time ever we've seen YC companies land pilots and actual multimillion dollar deals within their first year if not during the actual YC batch. It's not unusual at all to see a company's first customer be one of the largest companies in the world. The buyers are awake and want to talk.

Second AI has made it possible for the first time for small teams to ship incredibly thoughtful, nuanced products to large orgs in months, not years. The meme where some startups want to operate in stealth for 3 years until they reach feature parity with incumbents before launching is dead. For the first time a 2-3 person team can ship something a Fortune 10 can find useful before the ink is dry on their incorporation docs.

Finally, leaders at these companies understand where their companies should create value internally, what they should outsource and what will happen to their companies if they don't adapt. Again, these companies are run by really smart people.

We think this is a terrific environment for founders to sell into and want to back more teams that want to go after deals with the most famous, important customers in the world.`,author:{firstName:`Harshita`,lastName:`Arora`,profileUrl:`https://www.ycombinator.com/people/harshita-arora`},coauthor:{firstName:`Brad`,lastName:`Flora`,profileUrl:`https://www.ycombinator.com/people/brad-flora`},videoId:`Lrh1JVxqrKE`,isShorts:!0},{id:`supply-chain-for-semiconductors`,title:`Supply Chain 2.0 for Semiconductors`,description:`A single advanced AI chip goes through about 1,400 process steps, crosses a dozen countries, and takes five months to build. This supply chain is managed with spreadsheets, SAP, and phone calls.

In 2021 a $300 chip held up a $50,000 car, and $210 billion in vehicles didn't get built. Companies could see their direct suppliers but had zero visibility into the second and third tiers. It's gotten worse. TSMC's advanced packaging is the single biggest bottleneck in AI compute right now, and NVIDIA has locked up over 60 percent of it. HBM memory is booked through 2026. Export controls change quarterly.

At the same time the CHIPS Act is standing up new American fabs in Arizona, Texas, Ohio, and New York, each needing a supply chain built nearly from scratch.

Almost none of the tooling you'd expect exists: real-time allocation tracking, multi-tier risk monitoring, export compliance. You need to understand wafer allocation and packaging constraints at a deep level to build this, which is exactly why it's a startup opportunity and not a feature inside SAP.

If you're building supply chain 2.0 for chips, we'd love to talk.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`lw6xcZ9uuuw`,isShorts:!0},{id:`ai-operating-system-for-companies`,title:`The AI Operating System for Companies`,description:`The best AI-native companies we're seeing have figured out something most haven't: they've made their entire company queryable. Every meeting recorded, every ticket tracked, every customer interaction captured, all legible to an intelligence layer that learns from it.

This turns a company from an open loop into a closed loop. In an open loop, you make a decision and maybe check the results weeks later. In a closed loop, the system monitors what's happening, compares it to what should be happening, and adjusts. I've seen teams that do this cut sprint time in half and ship twice as much.

The problem is building this today requires brutal integration work, stitching together Slack, Linear, GitHub, Notion, call recordings, and a dozen other tools with custom glue code. There's no product that connects all this context into a single intelligence layer that can reason across it, flag when engineering is building the wrong thing, or generate specs agents can execute on.

We think there's a big opportunity to build the connective layer that makes a company legible to AI by default. Not another dashboard. The system that turns a company's own artifacts into a self-improving loop.

If you're building this, we'd love to talk.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`K46ZNekw2Tk`,isShorts:!0}]},{id:`spring-2026`,title:`Spring 2026`,description:`The way startups are built has shifted quickly. AI-native companies can now be built faster, cheaper, and with more ambition than ever. We're excited about a range of startup ideas that span AI-native workflows, new financial primitives, modernized industrial systems, and more. This time around, a few even come directly from YC founders sharing opportunities they're seeing on the frontier.`,items:[{id:`cursor-for-product-managers`,title:`Cursor for Product Managers`,description:`Over the last few years, we've seen an explosion of AI tools for writing code. Cursor and Claude Code are great at helping teams build software once it's clear what needs to be built.

But writing code is only part of building a product people want. The most important part is figuring out what to build in the first place!

Every successful product requires product management: talking to users, understanding markets, synthesizing feedback, and deciding what problems are worth solving and how the product should work. Whether this process is done by founders, engineers, or product managers, the activity is the same. Historically, the output has been product requirements docs, Figma mocks, and Jira tickets — artifacts designed to communicate intent to human engineers.

Today, teams use AI in isolated parts of this process, but there's no system that supports the full loop of product discovery.

Imagine a tool where you upload customer interviews and product usage data, ask "what should we build next?", and get the outline of a new feature complete with an explanation based on customer feedback as to why this is a change worth making. The tool would also propose specific changes to your product's UI, data model, and workflows, and would break down the development tasks so they could be handled by your favorite coding agent.

We think there's an opportunity to build a "Cursor for product management": an AI-native system focused on helping teams figure out what to build, not just how to build it.

As agents increasingly take the first pass at implementation, the way we define and communicate "what to build" needs to change.

If you're building in this space, we'd love to hear from you.`,author:{firstName:`Andrew`,lastName:`Miklas`,profileUrl:`https://www.ycombinator.com/people/andrew-miklas`},videoId:`iLP0YyNwpTc`,isShorts:!0},{id:`ai-native-hedge-funds`,title:`AI-Native Hedge Funds`,description:`In the 1980s, a small group of funds started using computers to analyze markets. At the time it seemed silly, but quantitative trading is now obvious. We're at a similar inflection point now, and the next Renaissance, Bridgewater, and D.E. Shaw's are going to be built on AI.

The biggest funds in the world have been slow to adapt. I worked as a quant researcher at one of these funds, and when I asked compliance to let us use ChatGPT, I didn't even get a response.

It made it clear to me that the hedge funds of the future won't just bolt AI onto their existing strategies. They'll use it to come up with entirely new ones. That's where the alpha is.

We've already got swarms of Claude agents writing our codebases. Imagine swarms of agents doing what hedge fund traders do now - combing through 10-Ks, earnings calls, and SEC filings, synthesizing analyst ideas and making trades. An AI-native hedge fund will be the first to do this well.`,author:{firstName:`Charlie`,lastName:`Holtz`,profileUrl:`https://www.ycombinator.com/companies/conductor`},videoId:`3-Zj8i8XNP8`,isShorts:!0},{id:`ai-powered-agencies`,title:`AI-Native Agencies`,description:`Agencies have always been crazy hard to scale. Low margins, slow manual work, and the only way to grow is to add more people.

But AI changes this.

Now instead of selling software to customers to help them do the work, you can charge way more by using the software yourself and selling them the finished product at 100x the price.

Think of a design firm that uses AI to produce custom design work for clients upfront, to win the business before the contract is even signed. Or an ad agency that uses AI to create stunning video ads without the time and expense of setting up a physical shoot. Or a law firm that uses AI to write legal docs in minutes, rather than weeks.

That's why agencies of the future will look more like software companies, with software margins. And they'll scale far bigger than any agencies that exist in these fragmented markets today.

If you're rethinking how agencies and service businesses of the future will be built, we'd love to hear from you.`,author:{firstName:`Aaron`,lastName:`Epstein`,profileUrl:`https://www.ycombinator.com/people/aaron-epstein`},videoId:`pOZi4PKW54M`,isShorts:!0},{id:`stablecoin-financial-services`,title:`Stablecoin Financial Services`,description:`Stablecoins are rapidly becoming critical infrastructure for global finance, yet much of the financial services layer remains unbuilt. The GENIUS and CLARITY Acts are placing stablecoins in a unique position between DeFi and TradFi, compliant but crypto-native.

This creates room for financial services that offer DeFi benefits like better yield or access to tokenized real-world assets while operating under traditional compliance frameworks.

Today, businesses and individuals must choose between regulated financial products with limited upside and unregulated crypto with real risk. Stablecoins sitting in the regulatory middle ground can bridge this gap, whether that's yield-bearing accounts, new investment access, or infrastructure that makes money move faster and cheaper across borders.

The regulatory window is open. The rails are being laid. It's the perfect time to build something that blurs the line between the two worlds.`,author:{firstName:`Daivik`,lastName:`Goel`,profileUrl:`https://www.ycombinator.com/companies/shor`},videoId:`N8ajU0uav80`,isShorts:!0},{id:`ai-for-government`,title:`AI for Government`,description:`The first wave of AI companies has helped businesses and normal people fill in forms and complete online applications with unprecedented speed and accuracy. On the flip side, many of these forms will be received by local, state, and federal government, where they're currently printing them out and processing them by hand.

Government desperately needs AI tools to deal with the huge increase that's coming down the line. And the benefit is that it will also make government much more cost-effective and responsive.

We've seen hints of this digital government in places like Estonia, but we need to spread it to the rest of the world.

This kind of startup is not for the faint of heart. Selling to government is extremely hard, but once you've figured out how to land your first customer, they tend to be very sticky and can expand to huge contracts.`,author:{firstName:`Tom`,lastName:`Blomfield`,profileUrl:`https://www.ycombinator.com/people/tom-blomfield`},videoId:`s44_2s9Lkzk`,isShorts:!0},{id:`modern-metal-mills`,title:`Modern Metal Mills`,description:`When people talk about reindustrializing America, they usually focus on labor costs or geopolitics. But a bigger problem is hiding in plain sight: American metal mills are slow by design.

If you buy rolled aluminum or steel tube in the U.S., lead times of 8 to 30 weeks are normal. Most buyers can't even purchase directly from mills. And despite high prices, mills still operate on thin margins. That's not because demand is weak or workers are unskilled—it's because the systems running these mills were designed decades ago.

Production planning, scheduling, quoting, and execution are fragmented. Mills optimize for tonnage and utilization, not speed, flexibility, or margin. Short runs and spec changes are treated as disruptions instead of opportunities.

Automation has lagged at the exact moment the workforce is shrinking. Material handling, changeovers, inspection, and quality control still rely on tribal knowledge held by a few experienced operators. Automation is mostly used to push more tons through a slow system, not to eliminate setup time or variability.

Energy is the other half of the problem. Aluminum and steel are extremely energy-intensive, yet most mills rely on legacy power contracts and inflexible grids. New energy models—on-site generation, smarter power management, even next-generation nuclear—could dramatically reduce costs, but they're rarely designed into mills from the start.

What's changed is that software and energy technology are finally good enough to rethink the entire system. AI-driven planning, real-time MES, and modern automation can compress lead times and raise margins at the same time.

We think this creates an opportunity to build modern, software-defined American mills—especially in aluminum rolling and steel tube—where long lead times and energy costs are most entrenched.

Modernizing mills isn't just about going faster. It's about making domestic metal cheaper, more flexible, and more profitable—and rebuilding the industrial foundation of the U.S.`,author:{firstName:`Zane`,lastName:`Hengsperger`,profileUrl:`https://www.ycombinator.com/companies/nox-metals`},videoId:`F-KQMMJ73s4`,isShorts:!0},{id:`ai-guidance-for-physical-work`,title:`AI Guidance for Physical Work`,description:`You know that scene in The Matrix, where Neo plugs a cable into the back of his head and wakes up a while later and says "I know Kung Fu"? Physical work is about to get something similar – not through brain implants, but through real-time AI guidance.

Much of the AI conversation focuses on which desk jobs will get replaced. But for physical work—stuff like field services, manufacturing, healthcare—AI can't yet act in the world. What it can do is see, reason, and guide the human who does.

Imagine wearing a small camera while an AI sees what you see and talks you through the job: "turn off that valve", "use the ⅜ inch wrench", "that part looks worn, replace it". Instead of needing months or years of training, workers can become effective immediately, with AI coaching them and accessing new skills when needed.

Why now? Three things have converged. First, multimodal models can now see and reason about real-world situations reliably. Second, the hardware is already everywhere – phones, AirPods, Smart Glasses. And third, skilled labor shortages make this economically urgent and a high wage job for millions of people.

There are a few approaches you could take. The most obvious is to build this system and sell it to companies with existing workforces. Or, you could pick a vertical, like HVAC repair or nursing, and build a full-stack superpowered workforce. Or, you could build a platform that lets anyone sign up and become a skilled worker or start their own business.

If you're interested in giving physical workers the same type of AI superpowers that Claude Code gives you, we'd love to see you apply.`,author:{firstName:`David`,lastName:`Lieb`,profileUrl:`https://www.ycombinator.com/people/david-lieb`},videoId:`hSDlgCKBx6w`,isShorts:!0},{id:`large-spatial-models`,title:`Large Spatial Models`,description:`Large language models have driven most of the recent breakthroughs in AI, but their impact has been constrained to domains that can be expressed primarily through language. Unlocking the next wave of AI capability, and enabling artificial general intelligence, will require models that are capable of spatial reasoning.

Today's systems can handle limited spatial tasks, such as basic relationships or depth estimation, but they cannot robustly reason about spatial manipulation, 2D and 3D features, their relationships, or operations like mental rotation. This limits AI's ability to understand and interact with the physical world.

There is an opportunity to build large-scale spatial reasoning models that treat geometry and physical structure as first-class primitives, not approximations layered on top of language. Such models would enable AI systems to reason about and design real-world objects and environments. A company that succeeds in building this capability could define the next AI foundation model, on the scale of OpenAI or Anthropic.`,author:{firstName:`Ryan`,lastName:`McLinko`,profileUrl:`https://www.ycombinator.com/companies/astranis`},videoId:`bLFl8OffFLE`,isShorts:!0},{id:`infra-for-government-fraud-hunters`,title:`Infra for Government Fraud Hunters`,description:`We want to fund startups that bring government fraud investigation into the modern era.

Government is the biggest customer on earth—it spends trillions annually at the federal, state and local levels, and it hemorrhages a commensurate amount in fraud. Medicare alone loses tens of billions a year to improper payments.

One of the most effective ways to claw this money back at scale is the qui tam provision under the False Claims Act. This lets private citizens file lawsuits on behalf of the government against companies defrauding it. If the case succeeds, these citizens get to keep a percentage of whatever's recovered.

At the moment, this process is painfully slow: An insider tips off a law firm, and then the firm spends months or years manually pulling documents and building the case.

This should be accelerated with software. Not dashboards, but intelligent systems that can take an insider tip and organize the evidence around it—parsing messy PDFs, tracing opaque corporate structures, and packaging the findings into complaint-ready files.

Some startups are already filing FCA claims themselves, but we think there's a big opportunity to build tools that dramatically speed up whistleblower law firms, state AGs, and inspectors general.

Founder profile matters here. We're looking for teams where at least one founder has actually done work like this, whether that's a former FCA counsel, compliance lead or auditor.

Now is the time to build this: the AI capabilities are finally here, and there's bipartisan tailwind to act. If you can make fraud recovery 10x faster, you'll build a huge business — and return billions to taxpayers.`,author:{firstName:`Garry`,lastName:`Tan`,profileUrl:`https://www.ycombinator.com/people/garry-tan`},videoId:`1mUTuQlEnCc`,isShorts:!0},{id:`make-llms-easy-to-train`,title:`Make LLMs Easy to Train`,description:`Training large language models is still surprisingly difficult. My co-founder Eric and I have spent the last three years training diffusion and language models at Can of Soup, and despite all the attention AI has received, the tooling has barely improved.

On any given day we may spend significant time dealing with broken SDKs, SSHing into busted GPU instances (that you only find out are busted after spinning them up for half an hour), or discovering major bugs in open-source tooling.

Not to mention the work of managing, sourcing, processing, and visualizing terabytes of data.

I'd love to use products that make LLM training easy.

• APIs that abstract training.
• Databases to easily manage very large datasets.
• Dev environments built with ML research in mind.

As post-training and model specialization become more important, I could see these products becoming the foundation of how software is built in the future.`,author:{firstName:`Gabriel`,lastName:`Birnbaum`,profileUrl:`https://www.ycombinator.com/companies/yn`},videoId:`asalbJSHS8g`,isShorts:!0}]},{id:`fall-2025`,title:`Fall 2025`,description:`The last few years were about proving what AI can do. Now, it's about building with it. We've put together a new list of startup ideas we're especially excited about— ideas that treat AI not as a feature, but as a foundation. They reflect where we think some of the biggest opportunities are right now.`,items:[{id:`retraining-workers-ai-economy`,title:`Retraining Workers for the AI Economy`,description:`We talk a lot about the AI revolution in terms of models, chips, and software. But to make it a reality, there needs to be a huge buildout of physical infrastructure like data centers and semiconductor fabs.

And that's where we have a problem. While we're focused on the race for AI talent, we also have a shortage of skilled tradespeople—the electricians, the HVAC technicians, the welders—who are essential to building this physical infrastructure.

The government's new AI Action plan creates a forcing function to solve this. There's a big emphasis on a "worker-first" agenda, and directions to the Departments of Labor and Commerce to fund new rapid retraining programs for exactly these kinds of physical labor jobs.

This creates opportunities for startups. We want to fund startups building a new kind of vocational school for the AI economy to train people for these jobs. We think you could use AI to create personalized training programs to get people job-ready in months, not years.

The challenge is, how do you teach someone to weld or fix pipes via AI? Unlike coding, you can't learn these skills by typing on a keyboard — you need to learn by practicing them in the real world.

This is where multimodal AI could create opportunities — for example, maybe a voice AI could coach someone through these tasks. Or perhaps some combination of AR/VR could let people practice the work in simulation with an AI tutor using vision models to watch them and give feedback.

It's clear how you'd make money from this business — employers would pay to hire your well-trained workers. In the past, these types of training businesses — like coding bootcamps — have struggled to expand because it's hard to scale the quality of human tutors, but AI might solve this problem too. If you can make one effective AI teacher, it'll scale infinitely.

This is a chance to build a huge business that lets everyone benefit from and participate in the new AI economy that's changing the world. If you want to work on this, we'd love to hear from you.`,author:{firstName:`Harj`,lastName:`Taggar`,profileUrl:`https://www.ycombinator.com/people/harj-taggar`},videoId:`F40PQKJVWJY`,isShorts:!0},{id:`video-generation-primitive`,title:`Video Generation as a Primitive`,description:`Video generation models are getting really good. Google's Veo 3 already produces 8-second, photorealistic, sound-on clips for just a few dollars per video, often indistinguishable from reality. Soon, you'll be able to generate near-perfect footage of anything, on the fly, for a marginal cost approaching 0, and video will become a new basic building block for software.

When this happens, a lot of new ideas become possible.

It's definitely going to change media and entertainment:

Imagine being able to create a brand new season of your favorite canceled TV series. Or a personalized kids cartoon starring your own family as the characters. Or an AI-native successor to TikTok, where every video is made for exactly one viewer.

Video generation will also change how we buy things:

Imagine you're shopping online, you'll be able to see yourself wearing the clothes or using the products you're browsing. And when you're apartment hunting, your stuff will be auto-staged in every listing you click on.

This new primitive also opens up major changes to gaming and simulation:

We'll have video games built with no game engine. We'll have APIs that return infinite robotic training data. And we'll definitely be able to have video calls with loved ones long after they're gone.

And these are just the obvious ideas we can imagine today.
We're interested in founders who treat generative video as a new computing primitive—not an output—and build new apps, tooling, and infrastructure for a world with limitless, low-latency video.`,author:{firstName:`David`,lastName:`Lieb`,profileUrl:`https://www.ycombinator.com/people/david-lieb`},videoId:`tJ2C9a5GBOs`,isShorts:!0},{id:`first-10-person-100b-company`,title:`The First 10-person, $100B Company`,description:`Thanks to new AI tools, we believe it's now possible for small, high-agency teams – even solo founders – to build multi-billion dollar companies with as little as just $500k in funding from YC.

15 years ago, cloud computing came along and eliminated the need for spending tons of money on physical server infrastructure, making it easier to build a big company with way less capital. This is happening again now, with new AI tools that make it easier for ambitious founders to scale with far fewer people.

That's why the best high-agency startups of the future will all optimize for one metric: revenue per employee.

These small teams have incredible advantages over bloated incumbents, too. With smaller, efficient teams at scale, they won't get bogged down with the politics, excessive meetings, and lack of focus that grinds huge companies to a halt. They can just focus on winning with better speed and execution.

We want to fund these high-agency founders to help them build the first 10-person, $100b dollar company.`,author:{firstName:`Aaron`,lastName:`Epstein`,profileUrl:`https://www.ycombinator.com/people/aaron-epstein`},videoId:`lkFiTvXu9Zw`,isShorts:!0},{id:`infrastructure-multi-agent-systems`,title:`Infrastructure for Multi-Agent Systems`,description:`AI agents are evolving from single-threaded loops into distributed workflows that fan out many sub‑agent calls in a single run. These multi-agent systems are useful for everything from long-running workflows to agentic mapreduce jobs where hundreds of thousands of subagents apply human-level judgment to filter and search through large amounts of data in parallel.

These systems are difficult to build. They require solving traditional distributed systems problems to ensure high throughput and reliability while controlling costs.

They also introduce new problems that look familiar but can be solved at a higher level of abstraction, like:

- how to write effective agent and subagent prompts
- how to handle untrusted context
- how to monitor and debug these agents

We're looking for builders who have felt this pain in production and want to build tools to make these systems easier to build and maintain. If you want to make operating fleets of agents as routine and reliable as deploying a web service or running a Spark job, we'd love to hear from you.`,author:{firstName:`Pete`,lastName:`Koomen`,profileUrl:`https://www.ycombinator.com/people/pete-koomen`},videoId:`0qGjxsMzuxc`,isShorts:!0},{id:`ai-native-enterprise-software`,title:`AI Native Enterprise Software`,description:`Salesforce and ServiceNow are two of the world's largest enterprise software vendors, each making more than $10B a year in revenue, and each with a market cap of more than $200B. Both produce software needed to run the world's biggest businesses.

Interestingly, both were founded about 25 years ago. Coincidence? I don't think so! Salesforce built the first cloud-native CRM, and ServiceNow built the first cloud-native ITSM system. Both rode the cloud computing wave to victory over their respective incumbents.

The story is much the same for Netsuite, Successfactors, and a host of other B2B startups from the early two thousands. The founders of these businesses realized that SaaS offered a way to build a ten times better product. Just as important, these founders knew the incumbents would struggle to adapt to the new world of cloud computing, giving them the edge they needed to go up against them and win.

AI presents the same once-in-a-generation opportunity for today's founders. Tomorrow's enterprise software systems won't just be the "system of record" for work done by humans. They'll have AI embedded deeply and thoughtfully throughout, and will help employees do their work faster and more accurately. Think Cursor for sales, HR, and accounting.

Just as before, today's incumbents will struggle to rebuild their product around this new technology, giving today's startups the time they need to win. History doesn't repeat itself, but it sure does rhyme.

Interested in building AI-native enterprise software? If so, we should chat.`,author:{firstName:`Andrew`,lastName:`Miklas`,profileUrl:`https://www.ycombinator.com/people/andrew-miklas`},videoId:`amNO1hHARqI`,isShorts:!0},{id:`using-llms-instead-government-consulting`,title:`Using LLMs Instead of Government Consulting`,description:`The U.S. government spends over $100 billion a year on consulting. As you might imagine, this isn't the most efficient or innovative part of our economy.

But over the last couple of years, there have been a few big reasons we believe this will change. Most importantly, today, there is political pressure to cut wasteful consulting and spending. Every part of the government now runs on software, but usually custom software built by a consulting company, and anyone who has used this software knows we can do a lot better. Finally, LLMs today are so good that they can already do the jobs of many consulting firms.

We've recently funded companies that help companies get approved to sell to the government, called FedRAMP. We've also recently funded companies that help the government cut regulation and use LLMs to help make sure the laws and policies coming out of the government are actually legal.

We think there is a lot more work that government consulting firms like Deloitte and Accenture do for the government today, and we want to fund startups that build LLM software to do that work.`,author:{firstName:`Gustaf`,lastName:`Alstromer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`MbFcWCCqImk`,isShorts:!0}]},{id:`summer-2025`,title:`Summer 2025`,description:`2025 is indeed shaping up to be the "year of AI agents".  We've put together a list of AI Agent startup ideas that we think are especially promising.  Some of these draw attention to trends that are already in full swing, and some of them are where we think things are going next.`,items:[{id:`full-stack-ai`,title:`Full-stack AI Companies`,description:`At YC, I would like to fund more founders working on full-stack AI companies. What is a full-stack AI company, you ask? Let me give an example.  

Suppose you believe that LLMs are now able to automate a lot of legal work. There are two things you might do with that idea. You could build an AI agent and sell it to law firms. That's what most people do. 

Or, you could start your own law firm, staff it with AI agents, and compete with the existing law firms.  

That, my friends, is going full-stack. You could do this for any industry, especially one dominated by slow-moving incumbents.  Instead of selling to the dinosaurs, you could make them extinct.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`s-okz_-pUHo`,isShorts:!0},{id:`more-design-founders`,title:`More Design Founders`,description:`More designers should be founders.

Over the next decade, as new coding tools make it easier than ever to build and ship products quickly, great design is going to matter even more.

Especially as many designers are worried about AI replacing their jobs, the real opportunity is for designers to use AI themselves to launch their own products and build their own companies. The design job of the future will be "founder".

Designers already have so many of the skills needed to be great – strong user empathy, a focus on solving problems, a high bar for quality, and taste. These are a must for every founding team.

That's why it's no accident that some of the biggest YC companies, like Airbnb and Stripe, are known for their exceptional design.  Without it, users wouldn't have trusted staying in a stranger's Airbnb, or trusted securely processing billions in credit card transactions through Stripe. These companies simply wouldn't have worked without first class design.

So we'd love to see more designers take the leap and start companies, and hope to fund teams with strong design and taste embedded in their core from the earliest days.`,author:{firstName:`Aaron`,lastName:`Epstein`,profileUrl:`https://www.ycombinator.com/people/aaron-epstein`},videoId:`DvxPuRbeNwY`,isShorts:!0},{id:`voice-ai`,title:`Voice AI`,description:`Humans interact with businesses in many ways, but one way hasn't changed much in almost 100 years—and that's phone calls. You probably have experienced long wait times, voice trees, the press star or pound. In the end, we always want to talk to a human agent because the alternatives are just not that great. 

But the new voice models and conversational LLMs are now incredibly good. And startups who take advantage of them are are now making voice AI bots that are indistinguishable from humans. It's pretty amazing and the unlock was the quality of these models. 

Today, over a trillion calls exist between a business and a customer. What we like to do at YC is to peek into the future, and talking to a voice AI bot feels like experiencing the future - similar to how it felt to ride an autonomous car for the first time - it just works.`,author:{firstName:`Gustaf`,lastName:`Alströmer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`_NGqEjFjB0U`,isShorts:!0},{id:`ai-scientific-advancement`,title:`AI for Scientific Advancement`,description:`A lot of the software tools used for scientific applications in chemistry, biology, materials science, or operations research haven't changed much in decades. These rely on standard methods along PhDs to solve complex problems in drug discovery, chemical process optimization, metals & mining, or power grid optimization. 

In particular, test-time compute is unlocking new types of startups that can solve these scientific problems. 

We'd love to see more startups get created that use AI to transform how physical things are made faster and more efficiently.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`NNwoLCGgN7o`,isShorts:!0},{id:`ai-personal-assistant`,title:`AI Personal Assistant`,description:`Despite decades of productivity apps, emails still pile up, calendars get full, and tasks remain undone. Even the best organizational tools only help us keep track of what needs to get done—they don't actually do it. With recent advances in LLMs, we now have the potential to go from "to-do" lists to "done" lists"

I'd love to work with startups building the next generation of AI personal assistant: an LLM-powered system that deeply understands your work, routines, communication history, and personal preferences. Imagine an AI that has perfect memory of your personal correspondence, projects, and scheduling preferences— and can take action on your behalf.

Think of an assistant that knows how you typically respond to certain kinds of emails and can draft those responses for you—or even send them with your approval. It understands which meetings you usually accept and which you decline, and that can auto-schedule your week in a way that optimises your productivity and minimises travel. It keeps track of tasks you've completed in the past and how you approach new ones, so it can handle recurring processes without your constant input.

This is more than just filtering messages or auto-filling your calendar. I want to see a system that truly does the tasks a human personal assistant or chief of staff might otherwise do, allowing you to focus on the work that matters most.`,author:{firstName:`Tom`,lastName:`Blomfield`,profileUrl:`https://www.ycombinator.com/people/tom-blomfield`},videoId:`-B3j7NtqU5o`,isShorts:!0},{id:`healthcare-ai`,title:`Healthcare AI`,description:`The US healthcare system is over 17% of GDP or over 4 trillion dollars. There are estimates that one-third of that, or over 1 trillion, is just spent on administrative tasks. We have one of the best healthcare systems in the world, but sadly, a lot of this spending is just unnecessary administration that exists because different health systems are not interoperable, don't have APIs, or simply the only way of doing a workflow or task if a human manually extracts data from one system to another. 

In the last two years, there is an entire set of new startups building infrastructure to extract data from PDF or other systems, organize it, and allow it to be easily entered with an agent into a different system. Many of the tasks that led to high administrative healthcare costs are now fully possible to automate because the arrival of great LLMs happened in just the last 12 months of the companies. You can help make the US healthcare system be more efficient by solving these issues`,author:{firstName:`Gustaf`,lastName:`Alströmer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`hJ4L9SseAuE`,isShorts:!0},{id:`ai-personal-tutor`,title:`AI Personal Tutor for Everyone`,description:`The idea of using computers to help people learn things has been a dream of computer nerds going back to the 1940's with Vannevar Bush's Memex idea, JCR Licklider's "Man-Computer Symbiosis" paper in the 60's, and Alan Kay's Dynabook proposal in the 70's.

The holy grail has been to build a personalized learning experience for everyone but in practice, that's been hard to build. Most online education products deliver the same content to everyone who signs up for a course.

And today, with AI, we think it's finally possible to build a truly personal tutor for everyone. The latest reasoning capabilities let them break down complex topics step by step, in a way that should help explain even the most complicated subjects in a straightforward way.

With the latest foundation models being multimodal, they can now present these concepts by generating animations, manipulating 3D objects, and explaining concepts with voice.

We've already seen the impact that one great teacher, like Grant Sanderson and his 3blue1brown YouTube videos, can have on making it easy to understand complex ideas using beautiful visualizations and animations. Now imagine having that same quality of explanation available for every topic, personalized to each learner's needs, with an interactive AI tutor. This could really change the world.

If you're working on using AI to create personalized learning tools for anything, we'd love to hear from you.`,author:{firstName:`Harj`,lastName:`Taggar`,profileUrl:`https://www.ycombinator.com/people/harj-taggar`},videoId:`c0MJdUVYp3w`,isShorts:!0},{id:`software-tools-for-robots`,title:`Software Tools To Make Robots`,description:`Robotics hasn't had its ChatGPT moment yet, but we think it's almost here.

Everyone has known that robots are the future - But that proved elusive because previous generations of robots were expensive, brittle, and only worked in controlled conditions.

With the rapid improvements in foundation models, it's finally possible to make robots that have human-level perception and judgment. That's been the missing piece.

While consumer use cases feature heavily in science fiction, some of the overlooked and most immediately addressable applications for robots are B2B.

Specifically, we think promising areas are industrial use cases like Gecko Robotics, which builds inspection robots, and farming use cases like Bear Flag Robotics, which builds autonomous tractors and was acquired by John Deere.

We're interested in funding people building software tools to help others make robots. If you're bullish that robots are about to have their ChatGPT moment, we'd love to hear from you!`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`D4yPM52G5_o`,isShorts:!0},{id:`future-of-education`,title:`The Future of Education`,description:`Education is one of the world's largest and most important industries, yet it's also one of the most difficult to disrupt. About 100 million people are employed in education today, and about 1.5bn students are being educated every year. Traditional ways of teaching and learning have remained largely unchanged for decades, but things might be starting to shift.

The rise of AI—particularly large language models—promises to reshape how we teach, learn, and measure outcomes. These technologies have the potential to significantly improve educational access, personalize instruction, and free both teachers and learners from drudgery.

We're just starting to see new personalized study tools for students and grading platforms for teachers, but we're still very early in figuring out what AI can truly achieve here. One big challenge is figuring out the business model - while more than a billion people are engaged in education, budgets are notoriously tight, and purchasing cycles are horrendously slow.

If you fast-forward 10 or 20 years, it's impossible to believe that education is still going to be done in the same way it is today.`,author:{firstName:`Tom`,lastName:`Blomfield`,profileUrl:`https://www.ycombinator.com/people/tom-blomfield`},videoId:`trr8NiH1ZQI`,isShorts:!0},{id:`ai-residential-security`,title:`AI Residential Security`,description:`Consumers spend $20B year on home security. And the biggest players are legacy companies whose features haven't changed in decades.

Meanwhile, AI is taking the world of commercial security by storm. Companies like Verkada, Lumana are showing just how powerful AI can be. In commercial buildings, doors are unlocked with facial recognition. Video cameras detect suspicious behavior and send push notifications to building managers. Virtual AI guards will even come on loudspeakers and scare away criminals – to prevent crime before it happens.

Ring was acquired for $1 billion dollars for making video doorbells and magnetic door sensors.
Imagine how big the opportunity is for the company that uses AI to make people feel actually safe in their homes.`,author:{firstName:`Tyler`,lastName:`Bosmeny`,profileUrl:`https://www.ycombinator.com/people/tyler-bosmeny`},videoId:`AteajI2KG2w`,isShorts:!0},{id:`internal-agent-builder`,title:`Internal Agent Builder`,description:`Soon, all companies will have one thing in common: every employee will build their own agents to automate the repetitive parts of their jobs. 

We'd like to fund founders working on the infrastructure they'll use to do that: internal agent builders.

An internal agent builder is a tool that I can use to create an agent to handle mundane tasks I don't like doing. This infrastructure will need to access every other piece of software I use in my day-to-day. It'll need to manage permissions, and send sensitive data securely to the latest generation of LLMs. 

We've built a version of this at YC and we're already using it to reduce the time we spend on everything from reviewing term sheets to repetitive accounting workflows. It frees us from the mundane so that we can spend more time on the tasks that we humans are uniquely good at. In my case that's working with founders!

If you're interested in building the foundational infrastructure for AI native companies, we'd love to hear from you.`,author:{firstName:`Pete`,lastName:`Koomen`,profileUrl:`https://www.ycombinator.com/people/pete-koomen`},videoId:`op9g4HjxrGQ`,isShorts:!0},{id:`ai-research-labs`,title:`AI Research Labs`,description:`At YC, we want to fund more AI Research Labs. Many people don't realize this, but YC was the first investor in OpenAI. In fact, OpenAI began life as YC Research, our in-house research lab. OpenAI pioneered the concept of independent AI Research labs, and we have had a front-row seat to the entire journey.

OpenAI is doing incredible work, but there are many unsolved problems in AI and still plenty of opportunity for new research labs.

Sometimes people think that to do YC you have to be able to ship a product in 3 months. But actually, we're excited to back deep, open-ended research that may takes years to commercialize just like OpenAI did. We've seen that when top researchers follow their interests, it often leads somewhere interesting.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`Xzu8BuxMHHw`,isShorts:!0},{id:`ai-voice-assistants-email`,title:`AI Voice Assistants for Email`,description:`I want to meet teams who can help me process my inbox – with just my voice.

You see, every day I drive to work for 20 minutes, and every day I wish I could be using that time to triage emails, draft replies, delegate scheduling. What if we could all arrive at work each day already at Inbox Zero?

If you've used things like Vapi, Retell, or even ChatGPT Advanced Voice Mode, you know how good these voice agents are today. The use cases are far bigger than just driving. I know firsthand - It took me experiencing nerve damage in my arms to realize how much we still rely on keyboards for even the most basic tasks.

And email just might be the perfect starting place to build the most useful all-purpose assistant. Anyone with access to my inbox instantly knows my friends, my plans, my writing style, and so much more.

If you're an ambitious team interested in working on this, I'm interested in working with you.`,author:{firstName:`Tyler`,lastName:`Bosmeny`,profileUrl:`https://www.ycombinator.com/people/tyler-bosmeny`},videoId:`JNq9eTCi5Xo`,isShorts:!0},{id:`ai-personal-finance`,title:`AI for Personal Finance`,description:`Most humans are not rational about their finances. But just being alive comes with a set of decisions you need to make about your finances. How much should I save for the future, where should I invest my money to take the right risk, and how should I think about debt and taxes? How you answer these questions today will impact your freedom to do the things you want in the future.

Until today, the answers have generally been asking friends, googling, hiring a financial advisor or maybe even asking your bank.

These options aren't great. They are filled with bias and don't have the full picture of your financial situation and goals. And hiring a great financial advisor is very expensive.

With LLMs, there is a unique opportunity to build software that gives every person access to personalized finance, investment, and tax advice at near-zero cost. They would use API's to access your complete financial situation and give completely personal unbiased advice.

If this is something you are thinking about building, you should consider applying to the YC Summer batch.`,author:{firstName:`Gustaf`,lastName:`Alströmer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`-6YQTNlIzbQ`,isShorts:!0}]},{id:`spring-2025`,title:`Spring 2025`,description:`From the AI breakthroughs of the last few months, a wave of new startup opportunities have been unlocked. We used to publish requests for startups no more than once a year, but we decided to publish this list just 3 months after our last one to help point founders to the idea spaces that have just opened up.`,items:[{id:`ai-app-store`,title:`A Secure AI App Store`,description:`We want a new kind of AI App Store and OS layer that sits on your computer or phone. It should:

1. **Protect User Data**
Users control what info each app can see—like your calendar, files, or browsing—but only if the user says so.

2. **Offer One Shared Memory**
All your personal details (preferences, past actions, context) stay in this layer, not scattered across a dozen apps.

3. **Help users find the best AI apps**
This App Store reviews and vets each AI tool so users can discover and install them safely.

4. **Help Developers Build**
Developers get infrastructure that help them avoid reinventing the wheel provided in simple APIs (like computer use, local LLaMA versioning, and app-level access control).

5. **Handle Payments**
Make it easy to pay for paid apps or services.

Imagine a travel AI that's great at finding flights that knows you usually travel with your nine-year-old who loves staring out the window, or an AI helper that recommends the original text an idea appeared in when you're reading essays or books. Apps built on this app store would have just a sliver of data you, the user, allows.

We need a system like this so AI can be both powerful and private. Some might say the major big tech companies will build this, but there is a time right now where instead, it might be you.

Done right, this will create more opportunity for startups and founders: their apps will be smarter with shared memory, and this will turn into a new marketplace that solves both distribution and monetization. If you're building it, please apply. We'd love to help you do it right.`,author:{firstName:`Garry`,lastName:`Tan`,profileUrl:`https://www.ycombinator.com/people/garry-tan`},videoId:`TFXPfy7sWG8`,isShorts:!0},{id:`datacenters`,title:`Datacenters`,description:`We need more data centers that can be built faster and at a lower cost to support the infrastructure needed for AI progress. Hyperscale datacenter projects take years to complete, and with the current interest and funding, we need new companies and more innovative solutions to accelerate this buildout—whether in power infrastructure, cooling, material procurement, or project management.

We can envision what the future will look like: software will handle every aspect of planning and constructing new datacenters or warehouses, from site selection and construction to setup and ongoing management. These applications will be "lights out," with robots operating autonomously 24/7 without human intervention.

We want to fund new startups to help create this vision.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`B4KsLeOZcqU`,isShorts:!0},{id:`compliance-audit`,title:`Compliance and Audit`,description:`Almost 4 million people in the US and Europe (roughly 1% of the entire workforce) work in compliance and audit. And compliance costs are only rising. From GDPR to Dodd-Frank, from financial AML/KYC to ESG reporting—the regulatory environment keeps expanding.

Traditional compliance tasks require reading dense regulations, cross-checking internal policy and procedure documents, manually sampling front-line work done and producing repetitive reports. Auditors often sift through large amounts of unstructured data to detect issues. These manual, time-consuming workflows beg for automation.

LLMs excel at this. They can parse regulatory documents, corporate policies, or financial statements and highlight issues, saving human review. These tools will automate much of the testing that auditors currently do by hand: spotting anomalies in data, identifying incomplete records, or highlighting contradictory policies.

Instead of sampling a few documents, a well-trained model can look at everything, all at once - "continuously auditing" every company in the world.`,author:{firstName:`Tom`,lastName:`Blomfield`,profileUrl:`https://www.ycombinator.com/people/tom-blomfield`},videoId:`Vi4c51aq-SQ`,isShorts:!0},{id:`browser-automation`,title:`Browser & Computer Automation`,description:`AI agents can now browse the web and use desktop applications. OpenAI's Operator and Anthropic's Computer Use showed this is possible, and there are a number of great open-source options too.

Letting AI agents use the web is like taking a brain in a jar and giving it hands. It can now do things.

It means that every website and every app now effectively has an API. It means that any workflow that people can do on a computer can be automated.

This probably 10x's the addressable use cases for AI agents. We can't wait to see what people build with it.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`v73RSJi8-mY`,isShorts:!0},{id:`ai-personal-staff`,title:`AI Personal Staff for Everyone`,description:`Software is a proven way to bring to everyone what only the rich could afford before. As recently as 2009, only the world's richest people could afford a private driver, but today, Uber, and now Waymo, have brought that to everyone. Another example: when I first started working on what would become Google Photos, I was surprised to learn that rich people hired actual human beings to go through all their photos and edit, label, and organize them. We built AI to automate that for billions of people.

Despite the explosion of software in the last decade, wealthy people still employ lots of human staff to provide personal services. These are things like tax accountants, personal lawyers, and money managers, but also personal trainers, private tutors, and even personal doctors. The list goes on and on. Why can only the rich afford this? Because software hasn't been able to replace these types of personalized knowledge work tasks…until now.

Over the next few years, we expect AI to get good enough to do most of these jobs. So if you are working to bring a part of this "personal AI staff" to every human on the planet, we'd love to hear from you.`,author:{firstName:`David`,lastName:`Lieb`,profileUrl:`https://www.ycombinator.com/people/david-lieb`},videoId:`2S1Z6YEKVoM`,isShorts:!0},{id:`devtools-ai-agents`,title:`Devtools for AI Agents`,description:`In the past 2 years, we have funded many startups using AI to disrupt legacy players.

We are now witnessing the emergence of the next wave: AI agents that go beyond assisting humans and can autonomously make decisions. With the release of o1, and soon o3, these agents are getting significantly better at reasoning, allowing them to fully replicate and even improve upon tasks performed by humans.

AI agents will become ubiquitous across industries and in our daily lives. Imagine a world where every person is empowered by a team of specialized AI agents, working seamlessly in the background to amplify their productivity and creativity.

To accelerate this future, we are looking to fund startups building devtools for AI agents. These can include:

• Agent builders: Companies enabling their customers to easily create and deploy custom agents, like Wordware (YC S24) or Stack AI (YC W23).

• Agent building blocks: Tools, APIs, or platforms that enhance agent capabilities, enabling them to perform more complex actions and achieve greater impact.

If you're building in this space, we'd love to hear from you and help you shape the future of software.`,author:{firstName:`Nicolas`,lastName:`Dessaigne`,profileUrl:`https://www.ycombinator.com/people/nicolas-dessaigne`},videoId:`yFcWSvR6c14`,isShorts:!0},{id:`future-software-engineering`,title:`The Future of Software Engineering`,description:`Language models can already write code better than most humans. This is going to bring the cost of building software down to zero.

So will agents kill the job of software developer? No! We'll need more human software engineers in the future because software is going to run almost everything.

These humans won't write much code directly. Instead, they'll manage teams of agents that build software for them. In addition to writing code, agents will perform most of the other specialized tasks required to build software: QA, deployment, security & compliance audits, translations, operations, etc.

We'd like to fund startups that enable small groups of generalist software developers to manage large teams of agents working together to build and ship lots of software.

If you're interested in building tools for the future of software engineering, we'd love to hear from you.`,author:{firstName:`Pete`,lastName:`Koomen`,profileUrl:`https://www.ycombinator.com/people/pete-koomen`},videoId:`a-O7vv0ZfNg`,isShorts:!0},{id:`ai-coss`,title:`AI Commercial Open Source Software (AICOSS)`,description:`There is a pattern with open source and open source startups. First we had proprietary Unix, then we had Linux, then we had RedHat. First, we had BitKeeper, then we had Git, then we had Github and Gitlab.

There is a huge opportunity to build startups that offer support and services to help people use open source AI.

It's not uncommon for the organization that releases the open source code to not want to focus on providing commercial support. For instance, Google and Facebook have open sourced a number of tools but aren't always in the business of providing commercial support for businesses to use those tools— which has yielded an opportunity for startups.

There are going to be many winners in the space of open source AI, but the launch of DeepSeek should provide ample new ground that a founder might want to cover to help businesses make use of these systems.

If you are interested in building in Open Source AI for the enterprise, we would like to hear from you.`,author:{firstName:`Dalton`,lastName:`Caldwell`,profileUrl:`https://www.ycombinator.com/people/dalton-caldwell`},videoId:`xkweKRfUb5Y`,isShorts:!0},{id:`ai-coding-agents`,title:`AI Coding Agents for Hardware-Optimized Code`,description:`AI hardware is still constrained by software. Nvidia dominates largely because CUDA's hand-optimized code is used in AI models. Competing hardware—AMD, custom silicon—often underperforms not just because of inferior chips but because writing system-level code (kernels, drivers) is very difficult, and not enough software engineers are working on it.

However, now with reasoning models like Deepseek R1 or OpenAI o1 and o3, these could generate hardware-optimized code that rivals—or surpasses—human CUDA code.

We'd love to see more founders work on AI-generated kernels that make more hardware alternatives work for AI.

This isn't just about performance. It's about breaking dependencies. Founders working on this could reshape the hardware ecosystem.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`W3keOVTy2yE`,isShorts:!0},{id:`b2a-software`,title:`B2A: Software Where the Customers Will All Be Agents`,description:`A significant percentage of internet traffic consists of non-humans scraping and looking for information. These programs often end up impersonating humans to fill out forms or look for changes, most people build websites with human users in mind rather than scrapers.

With the advent of AI and agents, it seems like it's a good idea to build software and services where agents as customers are actively supported and documented rather than an edge case.

For example, APIs to help agents pay for hosting credits, or book travel, or engage into contracts with other parties. In the stock market, it's well understood that humans and programs are trading together, and in the future, this will only increase.

If you want to build services specifically aimed at best serving agents, we want to hear from you.`,author:{firstName:`Dalton`,lastName:`Caldwell`,profileUrl:`https://www.ycombinator.com/people/dalton-caldwell`},videoId:`GEcby86ZOVY`,isShorts:!0},{id:`vertical-ai-agents`,title:`Vertical AI Agents`,description:`From 2005-2020, the invention of the interactive web application enabled a massive wave of B2B SaaS companies. Over 100 B2B SaaS unicorns were started, and nearly half of all venture funding went to this category.

It seems likely that for the next decade, we will see a parallel wave of companies building vertical AI agents.

What is a vertical AI agent? It's software that's built on top of LLMs that's been carefully tuned to be able to automate some kind of real, important work. In recent batches, we've had YC companies build an AI tax accountant, an AI medical biller, an AI phone support agent, an AI compliance agent, an AI quality assurance tester.

Some people previously derided ideas like this as "ChatGPT wrappers" but no one who has tried to deploy a system like this to production thinks so. Building systems like this that work in real-world conditions requires real agentic architectures, integrations with legacy systems, and deep domain understanding.

It's hard to get systems like this working right, but once you do, the growth can be phenomenal. The value prop of B2B SaaS was to make human workers incrementally more efficient. The value prop of vertical AI agents is to automate the work entirely. Vertical AI agents that reach human-level performance grow extremely quickly.

It's entirely possible this opportunity is big enough to mint another 100 unicorns. For every category with a successful B2B SaaS company, you could imagine an ever larger vertical AI company being built.

While many founders are already working on these ideas in the most obvious categories, we think it's still relatively undiscovered compared to the size of the opportunity, and there are many large categories still untouched.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`lvmmk85ArWg`,isShorts:!0},{id:`inference-ai-infrastructure`,title:`Inference AI Infrastructure in the World of Test-Time Compute`,description:`Until recently compute spend went into pre-training foundation models. But now with Deepseek R1 and OpenAI o1 and o3, there is a new scaling trend that suggests we'll need far more compute at inference time when AI apps actually use these models.

As AI apps 10x or even 100x the number of API calls to complex reasoning models, the infrastructure costs will become a real problem.

That's where new startups come in. There's room to rebuild the stack here: better software at inference-layer tooling, cheaper ways to handle GPU workloads, and optimizations that let AI apps scale without bleeding money.

It's the kind of unsexy-but-critical problem that often creates big opportunities.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`DwgUlVWs5fk`,isShorts:!0}]},{id:`winter-2025`,title:`Winter 2025`,description:`Now is the best time in history to be a builder. We just watched giant robotic chopsticks pluck a falling skyscraper out of the sky. AI is transforming how we all work — particularly builders — faster than any technology in history. It feels like we are entering a golden age of building and we can use it to build things to make the country better. Below are some of the ideas we think will be especially cool to build in this golden age.`,items:[{id:`government-software`,title:`Government Software`,description:`Selling software to the government is notoriously hard and not something most builders would even think about doing. Still, the prize is huge if you can figure it out. Palantir is one of the only startups that managed to figure it out and their market cap today is $125 billion.

Now might be a uniquely good moment to give it a shot. The deficit is running high and there is hope the government will find ways to reduce spending and operate more efficiently. At the same time, AI is now powerful enough to automate many types of administrative work the government spends billions of dollars per year on.

If you combine those ideas, building AI software to automate work done by the government would both reduce spending and make the government more efficient. In particular, we've seen that LLMs are especially good at automating rote repetitive admin tasks like filling out forms, reviewing applications or summarizing documents. As consumers of government services, we'd all benefit from more efficiency, imagine never having to wait in line at the DMV again.

It's hard to think of something that sounds less appealing as a place to look for startup ideas than the government but if you're up for digging in that space we'd love to hear from you.`,videoId:`kwmaCLAkpwQ`,isShorts:!0,author:{firstName:`Harj`,lastName:`Taggar`,profileUrl:`https://www.ycombinator.com/people/harj-taggar`}},{id:`public-safety-technology`,title:`Public Safety Technology`,description:`We all deserve to be safe in our homes, and while walking around on our streets. This is a basic thing civilization should afford its citizens. Startups are already on the case. License plate cameras built by Flock Safety (YC S17) now help solve 10% of reported crimes in the USA and they're aiming to get to 25% of all crime by next year. Abel Police (YC S24) cuts the amount of time police officers spend filling out paperwork from hours to minutes, giving them up to 25% more hours per day to do real police work.

Public safety tech can and will make a real difference. We are especially interested in hearing from you if you're working on these ideas:

Advanced Computer Vision: Your startup could develop technology that uses computer vision to enhance safety—identifying suspicious activities or people in distress from video feeds, without compromising individual privacy.

Emergency Response Enhancements: Technologies that improve the speed and coordination of emergency responses are lifesavers. If you have an idea that can get help to where it's needed faster, we want to help you make it happen.

Community Safety Tools: We are looking for tools that improve how communities and law enforcement interact. Your solution could make it easier for neighbors to watch out for each other and stay informed about their safety.

Efficient Law Enforcement Technologies: We're interested in technologies that help law enforcement do their jobs more effectively and fairly, from workload management to increasing accuracy in their operations.

If your startup is ready to be part of this movement, we want to hear from you.`,videoId:`tjagGqZ6jjM`,isShorts:!0,author:{firstName:`Garry`,lastName:`Tan`,profileUrl:`https://www.ycombinator.com/people/garry-tan`}},{id:`manufacture-in-usa`,title:`Manufacture in the USA`,description:`The UK became the world's richest country in the 19th century by being the workshop of the world. The US did the same in the 20th century. But in recent decades, we've given up this role. The hollowing out of US manufacturing has led to social and political division and left us in a precarious place geopolitically.

Bringing manufacturing back to America is one of the biggest areas of bipartisan agreement. Elon has shown us it is possible to do it by building Tesla Gigafactories in Austin and Nevada. We think other changes in the world have made it easier for new builders to follow his example.

New ML-based robotics systems will make it possible to automate far more, which will reduce the cost-of-labor arbitrage that pushed manufacturing to other countries in the first place. Companies like SpaceX and Tesla have trained an entire generation of engineers in how to build an American company that makes physical products but operates like a startup.

We know this works because we've had experience working with some of the leading companies in this space. Astranis (W16) is building telecommunications satellites in the heart of San Francisco, in a building that used to build warships for the US Navy during WWII. Gecko Robotics (W16), based in America's old industrial heartland of Pittsburgh, builds robots that do industrial inspections. Solugen (W17) makes industrial chemicals from a large-scale plant in Houston.`,videoId:`PqV28tLnpQo`,isShorts:!0,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`}},{id:`stablecoins-2`,title:`Stablecoins 2.0`,description:`At the start of this year, we posted a request for more stablecoin startups and since then things have only gotten better for stablecoins. The black cloud over stablecoins has always been regulation, with several efforts to pass regulation in the US failing. The regulatory future for stablecoins in the US now looks more promising and we expect sensible legislation is on its way soon.

Stablecoin payment volumes have surged this year and are now over a fifth of Mastercard's volume. Almost 30% of global remittances are now facilitated through stablecoins and traditional finance institutions like Visa are offering platforms for banks to issue their own stablecoins. Also Stripe recently acquired a stablecoin startup, Bridge, for $1 billion, which will only attract more investor interest and capital into the space.

This makes it a better time than ever to start a stablecoin startup. We are especially interested in hearing about ideas that target businesses, helping them to hold and manage stables and also services that make it easy for developers to integrate with them.

If you're working on stablecoin ideas we'd love to hear from you.`,videoId:`woAM_PbnCak`,isShorts:!0,author:{firstName:`Brad`,lastName:`Flora`,profileUrl:`https://www.ycombinator.com/people/brad-flora`},coauthor:{firstName:`Harj`,lastName:`Taggar`,profileUrl:`https://www.ycombinator.com/people/harj-taggar`}},{id:`llms-for-chip-design`,title:`LLMs for Chip Design`,description:`Each breakthrough in AI creates demand for more powerful chips to train larger models. No country wants to fall behind in this arms race. Domestic chip design and manufacture is not just about economics anymore, it's about survival in a post AI world. OpenAI O1 showed us that LLMs with reasoning can power breakthroughs in science and engineering and we're interested in talking to anyone using LLMs to improve chip design.

We are especially interested in anyone focusing on designing ASICs and FPGAs. Design of customized digital systems whether through FPGAs (field programmable gate arrays) or ASICs (application-specific integrated circuits) has typically been costly because of the amount of custom design, development and testing necessary to bring such a system online. With the advent of large language models, these costs are coming down significantly, such that ever more specialized types of computation could be done.

Our normal computing environment assumes Von Neumann architecture using CPUs that we are familiar with: single shared memory for programs and data, arithmetic unit and a program control unit, operating through fetching and execution cycles serially. Most computers and computation use this because it's very easy to reprogram such systems.

We know there is a clear engineering trade-off: it is possible to optimize especially specialized algorithms or calculations such as cryptocurrency mining, data compression, or special-purpose encryption tasks such that the same computation would happen faster (5x to 100x), and using less energy (10x to 100x). This is a diagram (credit: Taner Sadikoglu) showing the differences in how data flows an optimized FPGA system versus a normal CPU.

Given the order of magnitude improvements possible with specialized FPGAs and ASICs, use of LLMs to optimize this process is likely to produce extremely useful results and great opportunities for startups.`,videoId:`ZgQPB0qpk2A`,isShorts:!0,author:{firstName:`Garry`,lastName:`Tan`,profileUrl:`https://www.ycombinator.com/people/garry-tan`}},{id:`fintech-2`,title:`Fintech 2.0`,description:`The last two years have been a rough time for fintech startups. The collapse of Silicon Valley Bank led to regulators clamping down on new startups and investors fled the space. We're optimistic this is about to change and now is a great time to start a fintech startup.

Historically the hardest thing about starting a new financial startup was the difficulty of getting a deal with a bank or other regulated partner. We are now in a new era where this keeps becoming easier with the advent of providers like Stripe and new core technologies like stablecoins.

AI tools will inevitably cause the financial industry to change rapidly and we believe there could be a structural advantage for a small startup without any legacy systems or processes to quickly build global financial products of the future.

We believe this is the perfect time to start a new generation of financial technology companies built on top of the infrastructure now available. We would like to see ideas around insurance, investment banking, wealth management, international payments and more.`,videoId:`jJp13H5a-jE`,isShorts:!0,author:{firstName:`Dalton`,lastName:`Caldwell`,profileUrl:`https://www.ycombinator.com/people/dalton-caldwell`}},{id:`new-space-companies`,title:`New Space Companies`,description:`The cost to reach orbit is falling fast, having fallen over 10x since SpaceX's first launch in 2006. A startup can now build and launch a satellite on just a seed round.

If you think about how many kilograms of payload get launched into space today, imagine how many will be sent up in one year, in five years, in ten years, and so on.

If we are entering a future with access to space being as routine and inexpensive as commercial air travel, shipping or trucking… what new businesses does that unlock?

Building a space company might scare founders by seeming too ambitious, but surprisingly, it is not necessarily harder than building a software company. YC has funded many space companies — Astranis, Relativity Space, Stoke, and many others — and their success rate has been no lower, and maybe higher, than our other companies.`,videoId:`WRcE3IPvLww`,isShorts:!0,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},coauthor:{firstName:`Dalton`,lastName:`Caldwell`,profileUrl:`https://www.ycombinator.com/people/dalton-caldwell`}},{id:`ai-aided-engineering-tools`,title:`AI-Aided Engineering Tools`,description:`Engineering tools for the physical world have barely evolved in decades. The CAD/CAM software that mechanical engineers use, the EDA tools for circuit and chip design that electrical engineers use, and the CFD tools for fluid and thermal analysis that aerospace engineers use — All still rely on complex numerical solvers and physics simulations. These are computationally expensive and also require deep training and at times even a PhD to use effectively.

We believe the next generation of AI-powered tools will change that.

With reasoning capabilities built into the new AI models that solve math and physics, we can unleash engineers to design and build physical systems like —planes, buildings, circuits, chips, satellites—faster and better than ever before.

We're eager to see founders build the AI-aided engineering tools that will drive this transformation as the new generation of Computer-aided Engineering.`,videoId:`1asr6PkU8HQ`,isShorts:!0,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`}},{id:`one-million-jobs-2`,title:`One Million Jobs 2.0`,description:`We would like to fund startups that have a useful need to employ a million workers in a way that uniquely needs humans to do the job and there will be no structural need for the job to be done with AI.

In the past, when massive technological change came about, people have ended up doing different types of work than they did in the past. For example, a lot of people used to be farmers, and then because of machinery a lot fewer people were farmers. The same goes for careers like elevator operators and typists.

Often the types of new careers that are created have better working conditions and are more helpful to humanity. In this new AI driven world, these might be tools for more people to run their own local businesses, or be able to earn a living by providing services to other humans either online or offline.

Many AI futurists are unsure what the careers of the future are, and we want to fund founders with an answer to that question.`,videoId:`BAeBkS2gBpo`,isShorts:!0,author:{firstName:`Dalton`,lastName:`Caldwell`,profileUrl:`https://www.ycombinator.com/people/dalton-caldwell`}}]},{id:`summer-2024`,title:`Summer 2024`,description:`These are the requests for startups we published in the summer of 2024, our first big list since the start of the new AI wave.

The incredible explosion of AI capability has made this the best time to start a company in two decades. These are just some of the ideas we think are especially promising.`,items:[{id:`ml-simulation`,title:`Using Machine Learning to Simulate the Physical World`,description:`Many essential software tools work by simulating the world using known principles of physics and chemistry. Weather prediction, computational fluid dynamics for designing rockets and airplanes, and tools for drug discovery that predict the interactions of molecules — today many of these are based on running a full physics simulation of the world. These are very computationally heavy since they are solving complex multivariate mathematical equations.

It turns out that AI models are general functional approximators that can also solve and predict problems like these without needing to explicitly know about physics. This results in predictions that are much less computationally expensive and can be completed in minutes or seconds on much smaller computers rather than taking days/weeks and super computers.

We're interested in companies replacing existing simulations with ML-based ones, along with companies using ML-based simulations to open new markets currently unaddressable.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},coauthor:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},videoId:`uzyvVFwLD68`,isShorts:!0},{id:`defense-tech`,title:`New Defense Technology`,description:`The US is now engaged in large-scale conflicts in several regions that threaten to change our world. While the US has historically led the world in defense technology, the defense contractors it depends on have grown slow and inefficient, bloated by decades of cost-plus contracts.

SpaceX showed the world that a private space company could be vastly more effective than the publicly-funded United Launch Alliance. New companies that sell to the DoD like Palantir and Anduril are showing that the same thing is true for defense tech.

Silicon Valley was born in the early 20th century as an R&D area for the US military. Early Silicon Valley companies were largely funded by the DoD and played a key role in WWII by building military radar, code-breaking equipment, and components for the atomic bomb.

This decade is the time to return Silicon Valley to these roots.`,author:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`},coauthor:{firstName:`Gustaf`,lastName:`Alströmer`,profileUrl:`https://www.ycombinator.com/people/gustaf-alstromer`},videoId:`e2mmfE1juFs`,isShorts:!0},{id:`open-source`,title:`Commercial Open Source Companies`,description:`Open source companies move more quickly than closed source companies. For developer tools, being open source is a powerful way to gain developer adoption. But it's also a great way for startups to become mature and sell to enterprises a lot sooner. Ultimately, open source companies succeed when they become the standard choice for software engineers.

Very technical founders are at a strong advantage here, as the sales motion relies more on the technical merits of the project rather than strong sales tactics. It's more natural for technical founders to talk to users who are engineers just like them, and they can iterate faster since they'll get feedback from the open source community.

YC has funded over 150 open source companies including Gitlab (W15), Docker (S10), Apollo (S11), Supabase (S20) to name a few, and we want to fund more.`,author:{firstName:`Nicolas`,lastName:`Dessaigne`,profileUrl:`https://www.ycombinator.com/people/nicolas-dessaigne`},coauthor:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`Q2X2kAJajs4`,isShorts:!0},{id:`spatial-computing`,title:`Spatial Computing`,description:`Spatial computing is the use of technology to create experiences that merge the physical and digital worlds. It's a broad term that encompasses augmented reality (AR), virtual reality (VR), and mixed reality (MR).

We're interested in startups that are building applications, tools, and infrastructure for spatial computing. This includes applications for consumers and enterprises, as well as tools for developers to build spatial applications.

We believe that spatial computing will be the next major computing platform after mobile, and we want to fund the companies that will define this new era.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},videoId:`_rq3utSccQk`,isShorts:!0},{id:`erp-software`,title:`New Enterprise Resource Planning Software`,description:`As companies get larger they end up adopting some software suite to help run their business. This piece of software is widely known as an "ERP", or Enterprise Resource Planning software. You can think of this software as the operating system that a business runs on.

ERPs are usually known to be expensive, painful to implement, and disliked by users, yet are absolutely necessary and the very definition of business critical to its customers.

We would like to see new startups that build software that helps businesses run. Ideally that software would be loved by its customers for its flexibility and ease of use. This type of software is so valuable and important that we can imagine that there is the opportunity for dozens of new massively successful vendors.`,author:{firstName:`Dalton`,lastName:`Caldwell`,profileUrl:`https://www.ycombinator.com/people/dalton-caldwell`},videoId:`z5kGw1Cy0tY`,isShorts:!0},{id:`internal-dev-tools`,title:`Developer Tools Inspired by Existing Internal Tools`,description:`If a developer has worked at a company with some amount of success, they have likely encountered tools or frameworks that were built by programmers at the company to help solve their own particularly painful or repetitive problems. These tools tend to have funny internal nicknames and for the most part never see the light of day.

When aspiring founders try to come up with new startup ideas they often don't realize that the internal tools they had at prior jobs are a great place to get inspiration from.

We would like to see more startups created that are inspired by these types of homegrown tools, because it's likely that if it's very useful at one company, it's very useful at others. The lineage of all software tools can often be traced back to something a programmer built to get their job done, and there is no reason to doubt this won't continue to be true.`,author:{firstName:`Dalton`,lastName:`Caldwell`,profileUrl:`https://www.ycombinator.com/people/dalton-caldwell`},videoId:`0UycVzrZm7E`,isShorts:!0},{id:`llms-back-office`,title:`LLMs for Manual Back Office Processes in Legacy Enterprises`,description:`Legacy enterprises have many manual back office processes that are ripe for automation with LLMs. These processes are often repetitive, rule-based, and involve unstructured data. Examples include processing invoices, reviewing contracts, and handling customer service requests.

LLMs are particularly well-suited for these tasks because they can understand and generate natural language, which is the format of much of the data in these processes. They can also be trained on specific domains and company data to improve their performance.

We're interested in startups that are applying LLMs to automate these processes in legacy enterprises. We believe there is a massive opportunity to improve efficiency and reduce costs in these organizations.`,author:{firstName:`Tom`,lastName:`Blomfield`,profileUrl:`https://www.ycombinator.com/people/tom-blomfield`},videoId:`1CrcTQ2fiEU`,isShorts:!0},{id:`ai-enterprise-software`,title:`AI to Build Enterprise Software`,description:`Enterprise software has a reputation among smart programmers as being boring to work on. You have to do sales and because each potential customer wants something slightly different, you end up writing bloated software to try and please them all.

But what if AI could change how enterprise software gets built and sold? The core of what every customer wants is the same — they just want it customized around the edges.

AI is good at writing code — especially when you give it an existing codebase to learn from. So what if instead of long enterprise sales cycles you just give customers a simple starter product and have them tell your AI how they want it customized? In the future, every enterprise could have their own custom ERP, CRM or HRIS that is continually updating itself as the company itself is changing.

A product based on this premise would be highly disruptive to large incumbents, because now they can't win by just copying you and adding another feature to their bloated software. Now they would have to completely change their whole conceptual approach to building software.

Maybe the AI will get so good at this that it can think up new types of enterprise software that don't even exist yet. Building this AI would be an interesting technical challenge and if you're excited about building AI that can code, enterprise software is the most profitable software to build.`,author:{firstName:`Harj`,lastName:`Taggar`,profileUrl:`https://www.ycombinator.com/people/harj-taggar`},videoId:`fx3mqS_faOQ`,isShorts:!0},{id:`stablecoin-finance`,title:`Stablecoin Finance`,description:`Stablecoins are digital currencies that peg their value to some external reference. This is typically the U.S. dollar, but it can be other fiat currencies, assets, or even other digital currencies. Their transactions are recorded on a digital ledger, usually a blockchain. This means they can be traded at any time of day between any two wallets on the same network, transactions settle in seconds, and fees are a fraction of what you see in traditional finance.

There's been much debate about the utility of blockchain technology, but it seems clear that stablecoins will be a big part of the future of money. We know this because YC companies have been effectively incorporating stablecoins into their operations for years now – for cross-border payments, to reduce transaction fees and fraud, to help users protect savings from hyperinflation. This utility is so straightforward it seems inevitable traditional finance will follow suit.

In fact we're seeing signs of this. PayPal recently issued its own stablecoin. Major banks have started offering custody services and making noise about issuing their own.

It all looks a bit like digital music's transition from the realm of outlaw file sharing in the early 2000s to becoming the norm as players like Apple entered the market. Importantly, those major players were all outmatched in the end by Spotify, a startup founded during that same transition moment.

$136b worth of stablecoins have been issued to date but the opportunity seems much more immense still. Only about seven million people have transacted with stablecoins to date, while more than half a billion live in countries with 30%+ inflation. U.S. banks hold $17T in customer deposits which are all up for grabs as well.  And yet the major stablecoin issuers can be counted on one hand and the major liquidity providers with just a few fingers.

We would like to fund great teams building B2B and consumer products on top of stablecoins, tools and platforms that enable stablecoin finance and more stablecoin protocols themselves.`,author:{firstName:`Brad`,lastName:`Flora`,profileUrl:`https://www.ycombinator.com/people/brad-flora`}},{id:`end-cancer`,title:`A Way to End Cancer`,description:`The technology to diagnose cancer at an early stage already exists. Since most cancers are now treatable if caught early enough, this technology would dramatically reduce cancer deaths if rolled out widely and affordably.

The technology we're talking about is an MRI. Modern MRIs are sensitive enough to detect cancer masses as small as a millimeter.

Some companies are already having success on a small scale offering MRIs to patients for a high cash price. However, there is backlash from the medical community as MRIs also create incidental findings (or false positives), that cost our healthcare system valuable time and money to investigate.

For this to work, the world would need to scale up the number of MRI scans it does by at least 100x. Doing that will require innovations in the MRI hardware, the AI algorithms to interpret scans and reduce false positives, and the business models and consumer marketing to make it a viable business.  We're interested in funding companies looking to tackle this multifaceted problem.

While much exciting progress is being made on cancer therapeutics, finding cancer early enough for our existing therapeutics to be curative might be the opportunity with the greatest potential impact.`,author:{firstName:`Surbhi`,lastName:`Sarna`,profileUrl:`https://www.ycombinator.com/people/surbhi-sarna`}},{id:`foundation-models-biology`,title:`Foundation Models for Biological Systems`,description:`The vast majority of scientific innovation fails – either on the bench during early experimentation or while in clinical trials.

Foundation models built around the vast amount of data we now have will not only enable scientists to know what path to pursue much quicker than before, but have the potential to unlock new scientific approaches to disease. Foundation models built around text and images are enabling the next-generation of consumer products; we believe foundation models built around biological systems will do the same for healthcare.

We are interested in funding highly technical founders building foundational models from scratch in any part of biology or medicine.`,author:{firstName:`Surbhi`,lastName:`Sarna`,profileUrl:`https://www.ycombinator.com/people/surbhi-sarna`}},{id:`mso-healthcare`,title:`The Managed Service Organization Model for Healthcare`,description:`Private equity is consuming small and large private clinics all over the country. By the time more junior healthcare workers are paid, they only make a fraction of what they are billing. This causes them to be overworked but underpaid, as much of the revenue goes to overhead and the private equity owner of the clinic.

A new startup model has emerged as an alternative to PE ownership: the MSO (Managed Service Organizations) model.

The MSO model enables doctors to run their own clinics by (1) providing them software that can handle back office tasks such as billing and scheduling and (2) channeling patients to them.

These functions are largely what PE ownership provides. Doctors who are part of an MSO model can continue to run small, physician-owned practices while competing successfully with large, PE-owned conglomerates.

YC has funded several companies doing this in different verticals: Nourish (nutritionists), LunaJoy (mental health for women), Finni Health (autism care for children), and others.

We are interested in investing in this MSO (Managed Service Organizations) model across every vertical in healthcare.`,author:{firstName:`Surbhi`,lastName:`Sarna`,profileUrl:`https://www.ycombinator.com/people/surbhi-sarna`}},{id:`eliminating-healthcare-middlemen`,title:`Eliminating Middlemen in Healthcare`,description:`The US spends more money per person on healthcare than any other developed nation, yet our patient outcomes are no better.  Much of our spend goes to paying middlemen — which in our view includes everyone not directly providing care to patients.

A recent report on medicare spending on drugs found that 70% of spend went to middlemen (primarily PBMs, wholesalers, and pharmacies) and only 30% to the pharmaceutical companies who make the drugs.  Similar dynamics exist in every other vertical — hospital care, medical equipment, insurance, etc.

There are many ways startups could attack these inefficiencies, from using AI to automate repetitive human jobs to exploring new and better business models for providing care.  In the spirit of Jeff Bezos' "your margin is my opportunity", we believe it's possible to build a highly profitable business and make the system more efficient at the same time.`,author:{firstName:`Surbhi`,lastName:`Sarna`,profileUrl:`https://www.ycombinator.com/people/surbhi-sarna`}},{id:`small-fine-tuned-models`,title:`Small Fine-tuned Models as an Alternative to Giant Generic Ones`,description:`Giant generic models with a lot of parameters are very impressive. But they are also very costly and often come with latency and privacy challenges. Fortunately, smaller open-source models like Llama2 and Mistral have already demonstrated that, when finely tuned with appropriate data, they can yield comparable results at a fraction of the cost.

Moreover, as new hardware continues to be integrated into our phones and laptops, the prospect of running these models at the edge becomes increasingly feasible, unlocking a multitude of new use cases.

We are eager to support companies engaged in developing or fine-tuning such specialized models or creating tools to facilitate their construction.`,author:{firstName:`Nicolas`,lastName:`Dessaigne`,profileUrl:`https://www.ycombinator.com/people/nicolas-dessaigne`}},{id:`explainable-ai`,title:`Explainable AI`,description:`Would you trust an AI to diagnose you? Would you swear that a model is unbiased? Or more simply, how can we be sure that a model doesn't hallucinate an answer?

Understanding model behavior is very challenging, but we believe that in contexts where trust is paramount it is essential for an AI model to be interpretable. Its responses need to be explainable.

For society to reap the full benefits of AI, more work needs to be done on explainable AI. We are interested in funding people building new interpretable models or tools to explain the output of existing models.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},coauthor:{firstName:`Nicolas`,lastName:`Dessaigne`,profileUrl:`https://www.ycombinator.com/people/nicolas-dessaigne`}},{id:`ml-robotics`,title:`Applying Machine Learning to Robotics`,description:`Robotics hasn't yet had its GPT moment, but we think it's close.

YC has followed robotics closely for two decades. In fact, one of YC's founders, Trevor Blackwell, is a pioneering roboticist who built the first dynamically balancing bipedal robot.

For decades, everyone has known that robots are the future, as any science fiction novel will show. But that future proved elusive because previous generations of robots were expensive and brittle, requiring controlled conditions. With the rapid improvements in foundation models, it's finally possible to make robots that have human-level perception and judgment. That's been the missing piece.

While consumer use-cases feature heavily in science fiction, some of the overlooked and most immediately addressable applications for robots are B2B. Specifically, we think promising areas are industrial use-cases like Gecko Robotics (W16), which builds inspection robots, and farm use-cases like Bear Flag Robotics (W18), which builds autonomous tractors and was acquired by John Deere.

We're interested in funding people building software tools to help other people to make robots, along with people building the robots themselves.`,author:{firstName:`Diana`,lastName:`Hu`,profileUrl:`https://www.ycombinator.com/people/diana-hu`},coauthor:{firstName:`Jared`,lastName:`Friedman`,profileUrl:`https://www.ycombinator.com/people/jared-friedman`}}]}],p=(...e)=>e.filter(Boolean).join(` `),m=({items:e})=>{let[t,i]=(0,d.useState)(``),[a,o]=(0,d.useState)(!1),s=(0,d.useRef)(null);(0,d.useEffect)(()=>{let t=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&i(e.target.id)})},{rootMargin:`-20% 0px -80% 0px`}),n=e.map(e=>document.getElementById(e.id));return n.forEach(e=>{e&&t.observe(e)}),()=>{n.forEach(e=>{e&&t.unobserve(e)})}},[e]),(0,d.useEffect)(()=>()=>{s.current&&clearTimeout(s.current)},[]);let c=()=>{s.current&&=(clearTimeout(s.current),null),o(!0)},l=()=>{s.current=setTimeout(()=>{o(!1)},300)};return n(`div`,{id:`toc-container`,className:`fixed left-8 top-1/2 z-50 hidden -translate-y-1/2 transform xl:block`,style:{maxHeight:`calc(100vh - 8rem)`},children:r(`div`,{className:`relative`,onMouseEnter:c,onMouseLeave:l,children:[n(`div`,{className:`space-y-3 rounded-lg px-4 py-4 transition-colors hover:bg-gray-50/50`,children:e.slice(0,8).map(e=>n(`div`,{className:p(`transition-all duration-200`,t===e.id?`w-8 bg-black`:`w-6 bg-gray-300`),style:{height:`2px`}},`toc-line-${e.id}`))}),a&&r(`div`,{className:`scrollbar-hide fixed left-16 top-1/2 z-50 w-72 -translate-y-1/2 transform rounded-2xl border border-gray-200/50 bg-white p-6 shadow-xl backdrop-blur-sm`,style:{maxHeight:`80vh`,overflowY:`auto`,scrollbarWidth:`none`,msOverflowStyle:`none`},onMouseEnter:c,onMouseLeave:l,children:[n(`style`,{children:`.scrollbar-hide::-webkit-scrollbar {
                display: none;
              }`}),n(`div`,{className:`mb-5 flex items-center justify-between`,children:n(`h3`,{className:`font-['Outfit',sans-serif] text-xs font-medium uppercase tracking-wider text-gray-500`,children:`Contents`})}),n(`nav`,{className:`space-y-1`,children:e.map(e=>n(`a`,{href:`#${e.id}`,className:p(`block rounded-lg px-3 py-2.5 font-['Outfit',sans-serif] text-sm transition-all`,t===e.id?`bg-gray-100 font-medium text-[#16140f]`:`font-light text-gray-600 hover:bg-gray-50 hover:text-[#16140f]`),children:e.title},e.id))})]})]})})},h=(0,d.createContext)(null);function g({children:e}){let t=(0,d.useRef)(null),r=(0,d.useCallback)(e=>{let n=t.current;n&&n!==e&&n.pauseVideo(),t.current=e},[]),i=(0,d.useCallback)(e=>{t.current===e&&(t.current=null)},[]),a=(0,d.useMemo)(()=>({registerPlay:r,unregister:i}),[r,i]);return n(h.Provider,{value:a,children:e})}function _(){return(0,d.useContext)(h)}var v=({videoId:e,isShorts:t=!1})=>{let r=_(),i=(0,d.useRef)(null);return(0,d.useEffect)(()=>()=>{i.current&&r?.unregister(i.current)},[r]),n(`div`,{className:t?`mx-auto h-[400px] w-full max-w-[300px] sm:h-[500px] sm:w-[350px] sm:max-w-none`:`mx-auto aspect-video w-full max-w-2xl`,children:n(u,{videoId:e,title:`YouTube video player`,className:`h-full w-full`,iframeClassName:`h-full w-full rounded-xl shadow-md`,onPlay:e=>{i.current=e.target,r?.registerPlay(e.target)},opts:{height:`100%`,width:`100%`,playerVars:t?{loop:1,controls:0,rel:0,modestbranding:1}:{rel:0,modestbranding:1}}})})},y=({batches:e,selectedBatchId:t,onBatchChange:r})=>n(`div`,{className:`-mx-4 mb-6 overflow-x-auto px-4 pb-2 sm:mx-0 sm:mb-10 sm:px-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden`,children:n(`div`,{className:`flex w-max min-w-full flex-nowrap justify-start gap-2 font-['Outfit',sans-serif] sm:justify-center`,role:`group`,"aria-label":`Select a batch`,children:e.map(e=>{let i=e.id===t;return n(`button`,{type:`button`,"aria-pressed":i,onClick:()=>r(e.id),className:l(`shrink-0 rounded-full border px-3 py-1.5 text-sm font-medium leading-5 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#16140f] focus-visible:ring-offset-2`,i?`border-[#16140f] bg-[#16140f] text-white`:`border-[#d5d3ca] bg-white text-[#16140f] hover:border-[#999] hover:bg-[#f4f3ed]`),children:e.title},e.id)})})}),b=({item:e,index:t,showVideo:o=!1})=>n(`div`,{className:l(`border-t border-[#ccc] py-10`,t===0?`border-t-0`:``),children:r(`div`,{className:`w-full`,children:[r(`div`,{className:`mb-6`,children:[r(`h3`,{className:`mb-2 font-['Outfit',sans-serif] text-lg font-medium text-[#16140f] md:text-xl`,children:[e.title,n(a,{id:e.id,title:e.title})]}),e.author&&r(`span`,{className:`font-['Outfit',sans-serif] font-light text-[#16140f]`,children:[`By`,` `,r(`a`,{href:e.author.profileUrl,className:`inline-flex items-center underline decoration-gray-500 underline-offset-2 transition-all hover:decoration-gray-700`,target:`_blank`,rel:`noopener noreferrer`,children:[e.author.firstName,` `,e.author.lastName]}),e.author.title&&r(i,{children:[`, `,e.author.title]}),e.coauthor&&r(i,{children:[` and `,r(`a`,{href:e.coauthor.profileUrl,className:`inline-flex items-center underline decoration-gray-500 underline-offset-2 transition-all hover:decoration-gray-700`,target:`_blank`,rel:`noopener noreferrer`,children:[e.coauthor.firstName,` `,e.coauthor.lastName]}),e.coauthor.title&&r(i,{children:[`, `,e.coauthor.title]})]})]})]}),r(`div`,{className:`grid grid-cols-1 gap-8 md:grid-cols-1 lg:grid-cols-12`,children:[o&&e.videoId&&n(`div`,{className:`order-first mb-6 md:mx-auto md:max-w-2xl lg:sticky lg:top-4 lg:order-last lg:col-span-5 lg:mx-0 lg:mb-0 lg:self-start`,children:n(v,{videoId:e.videoId,isShorts:e.isShorts??!1})}),n(`div`,{className:`prose prose-lg order-last text-justify md:mx-auto md:max-w-2xl lg:order-first lg:col-span-7 lg:mx-0 [&_a:hover]:decoration-gray-700 [&_a]:text-[#16140f] [&_a]:underline [&_a]:decoration-gray-500 [&_a]:underline-offset-2 [&_a]:transition-all`,children:n(`div`,{className:`whitespace-pre-wrap font-['Outfit',sans-serif] font-light text-[18px] leading-[1.7] text-[#16140f]`,children:e.description.split(/\*\*(.+?)\*\*/).map((e,t)=>{if(t%2==0)return e;let r=`bold-${e.replace(/[^a-zA-Z0-9]/g,`-`)}`;return n(`strong`,{children:e},r)})})})]})]})}),x=()=>typeof window<`u`?window.location.hash.replace(`#`,``):``,S=()=>{let e=x();if(e){let t=f.find(t=>t.items.some(t=>t.id===e));if(t)return t.id}return f[0].id};function C(){let[e,t]=(0,d.useState)(f[0].id);(0,d.useEffect)(()=>{let e=S();e!==f[0].id&&t(e)},[]),(0,d.useEffect)(()=>{let e=x();if(!e)return;let t=setTimeout(()=>{let t=document.getElementById(e);t&&t.scrollIntoView({behavior:`smooth`})},300);return()=>clearTimeout(t)},[e]);let i=f.find(t=>t.id===e)||f[0],a=(0,d.useMemo)(()=>i.items.map(e=>({id:e.id,title:e.title})),[i.items]);return r(`div`,{className:`relative`,children:[n(s,{}),n(m,{items:a}),n(c,{title:`Requests for Startups`,subtitle:`RFS is our tradition of sharing ideas we'd like to see founders tackle. These represent just a fraction of what we fund — if one excites you, take it as extra validation to dive in, but you don't need to work on these ideas to apply to YC.`,children:r(`div`,{className:`mx-auto max-w-6xl pb-10 sm:px-2 sm:pb-16 lg:px-4`,children:[n(y,{batches:f,selectedBatchId:e,onBatchChange:t}),n(`div`,{className:`mx-auto mb-8 w-full max-w-4xl border-t border-[#ccc]`}),r(`div`,{className:`mb-12 max-w-5xl`,children:[n(`h2`,{className:`mb-3 font-['Source_Serif_4',serif] text-[1.75rem] font-medium leading-tight text-[#16140f] sm:mb-4 md:text-[1.4rem]`,children:i.title}),n(`p`,{className:`font-['Outfit',sans-serif] font-light text-[18px] leading-[1.7] text-[#16140f]`,children:i.description})]}),n(g,{children:n(`div`,{className:`mb-20`,children:i.items.map((e,t)=>n(`div`,{id:e.id,children:n(b,{item:e,index:t,showVideo:!0})},e.id))})})]})})]})}var w=o(C);export{w as default};
//# debugId=b0642019-3825-548d-84ad-7c3ab54f16be
