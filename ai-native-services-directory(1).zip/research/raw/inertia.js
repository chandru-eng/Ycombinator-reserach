
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ad015b70-dc6e-5109-9181-16c04e747272")}catch(e){}}();
import{spa_init as e}from"./index-BEsvz3i4.js";import{ycdcComponents as t}from"./component_registry-tXOSERg2.js";import{t as n}from"./cspAssetDiagnostics-C8ar043_.js";e(t),n();
//# debugId=ad015b70-dc6e-5109-9181-16c04e747272
