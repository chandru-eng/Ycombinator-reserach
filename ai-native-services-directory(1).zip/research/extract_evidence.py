import json,glob,re,os
AI=r'(AI|artificial intelligence|LLM|GPT|agent|agentic|automat|autonomous|machine learning|model)'
HUM=r'(human|our team|advisors?|experts?|specialists?|licensed|CPA|attorney|lawyer|nurse|physician|accountant|bookkeeper|review by|supervis|in the loop|escalat|our staff|operators)'
PRICE=r'(\$\d|per (claim|return|ticket|policy|file|invoice|month|year|user|seat|call|minute|hour)|pricing|price|subscription|retainer|flat fee|fee|%|commission)'
def sents(t):
    t=re.sub(r'\s+',' ',t)
    return re.split(r'(?<=[.!?])\s+',t)
for f in sorted(glob.glob('research/sites/*.json')):
    d=json.load(open(f))
    alltext=' '.join(p['text'] for p in d['pages'].values() if p['len']>200)
    if len(alltext)<300: 
        print(f"\n### {d['name']}: NO CONTENT"); continue
    print(f"\n{'='*90}\n### {d['name']}  ({d['website']})  chars={len(alltext)}")
    seen=set()
    def emit(pat,label,limit=6):
        n=0
        for s in sents(alltext):
            s=s.strip()
            if len(s)<25 or len(s)>400: continue
            if re.search(pat,s,re.I) and s not in seen:
                seen.add(s); print(f"  [{label}] {s}"); n+=1
                if n>=limit: break
    emit(AI,'AI')
    emit(HUM,'HUMAN',4)
    emit(PRICE,'PRICE',3)
