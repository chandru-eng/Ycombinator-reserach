import json, urllib.request, urllib.error, re, html, os, ssl
from concurrent.futures import ThreadPoolExecutor

ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36"

def clean(h):
    h=re.sub(r'<(script|style|noscript|svg|head)[^>]*>.*?</\1>','',h,flags=re.S|re.I)
    h=re.sub(r'<!--.*?-->','',h,flags=re.S)
    h=re.sub(r'<(br|/p|/div|/h[1-6]|/li|/tr)[^>]*>','\n',h,flags=re.I)
    t=re.sub(r'<[^>]+>',' ',h); t=html.unescape(t)
    t=re.sub(r'[ \t]+',' ',t); t=re.sub(r'\n\s*\n+','\n',t)
    return t.strip()

def fetch(url,timeout=20):
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'text/html,application/xhtml+xml','Accept-Language':'en-US,en;q=0.9'})
    with urllib.request.urlopen(req,timeout=timeout,context=ctx) as r:
        raw=r.read(900000); enc=r.headers.get_content_charset() or 'utf-8'
        return r.status, r.geturl(), raw.decode(enc,errors='replace')

shortlist=json.load(open('research/horiz_shortlist.json'))
os.makedirs('research/sites_horiz',exist_ok=True)

def do(e):
    name=e['name']; slug=re.sub(r'[^a-z0-9]+','-',name.lower()).strip('-')
    site=(e.get('website') or '').strip()
    out={'name':name,'website':site,'pages':{}}
    if not site:
        json.dump(out,open(f'research/sites_horiz/{slug}.json','w')); return f"SKIP {name}"
    urls=[site]+[site.rstrip('/')+'/'+p for p in ['pricing','how-it-works','about','product','solutions','customers']]
    ok=0
    for u in urls:
        try:
            st,fin,body=fetch(u); txt=clean(body)
            out['pages'][u]={'status':st,'final':fin,'len':len(txt),'text':txt[:14000]}
            ok+=1
        except Exception as ex:
            pass
    json.dump(out,open(f'research/sites_horiz/{slug}.json','w'))
    return f"{'OK ' if ok else 'FAIL'} {name:22} pages={ok}"

with ThreadPoolExecutor(max_workers=6) as ex:
    for r in ex.map(do, shortlist): print(r)
print("DONE")
