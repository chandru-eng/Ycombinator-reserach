import json,sys,re
slug=sys.argv[1]
d=json.load(open(f'research/sites/{slug}.json'))
print("="*80); print(d['name'], d['website']); print("="*80)
for u,p in d['pages'].items():
    if p['len']<200: continue
    t=re.sub(r'\n+','\n',p['text'])
    print(f"\n----- {u} ({p['len']}) -----")
    print(t[:3500])
