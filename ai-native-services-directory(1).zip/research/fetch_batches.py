import json, urllib.request, time, re
APP="45BWZJ1SGC"
h=open('research/raw/companies.html',encoding='utf-8').read()
KEY=re.search(r'"key":"([^"]+)"',h).group(1)
URL=f"https://{APP}-dsn.algolia.net/1/indexes/YCCompany_production/query"
HDR={"X-Algolia-Application-Id":APP,"X-Algolia-API-Key":KEY,"Content-Type":"application/json"}
def q(params):
    req=urllib.request.Request(URL,data=json.dumps(params).encode(),headers=HDR)
    for a in range(5):
        try:
            with urllib.request.urlopen(req,timeout=90) as r: return json.load(r)
        except Exception as e:
            print("  retry",a,e); time.sleep(2*(a+1))
    raise RuntimeError("failed")

facets=json.load(open('research/yc_facets.json'))
batches=list(facets['batch'].keys())
ATTR=["name","slug","website","one_liner","long_description","batch","industry","industries","subindustry","tags","all_locations","team_size","status","top_company","launched_at","small_logo_thumb_url","stage","regions","former_names"]
seen={}
for b in batches:
    page=0
    while True:
        r=q({"query":"","hitsPerPage":1000,"page":page,
             "facetFilters":[f"batch:{b}"],"attributesToRetrieve":ATTR})
        for hit in r["hits"]:
            seen[hit["objectID"]]=hit
        if page+1>=r["nbPages"]: break
        page+=1
    print(f"{b}: total so far {len(seen)}")
    time.sleep(0.2)
allc=list(seen.values())
json.dump(allc,open('research/yc_companies_all.json','w'))
print("SAVED",len(allc))
