import json,urllib.request,re,html,ssl,time
from concurrent.futures import ThreadPoolExecutor
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36"
def clean(h):
    h=re.sub(r'<(script|style|noscript|svg|head)[^>]*>.*?</\1>','',h,flags=re.S|re.I)
    h=re.sub(r'<(br|/p|/div|/h[1-6]|/li)[^>]*>','\n',h,flags=re.I)
    t=html.unescape(re.sub(r'<[^>]+>',' ',h))
    return re.sub(r'\n\s*\n+','\n',re.sub(r'[ \t]+',' ',t)).strip()
sl=json.load(open('research/shortlist.json'))
def do(e):
    slug=e.get('slug'); 
    if not slug: return
    url=f"https://www.ycombinator.com/companies/{slug}"
    try:
        req=urllib.request.Request(url,headers={'User-Agent':UA})
        with urllib.request.urlopen(req,timeout=30,context=ctx) as r:
            t=clean(r.read(700000).decode('utf-8','replace'))
        # extract the json props
        open(f"research/ycprofiles/{slug}.txt","w").write(t)
        print(f"OK {e['name'][:24]:26} {len(t)}")
    except Exception as ex:
        print(f"ERR {e['name'][:24]:26} {type(ex).__name__} {ex}")
with ThreadPoolExecutor(max_workers=6) as ex: list(ex.map(do,sl))
