/* ==========================================================================
   AI-Native Service Companies — Notion-style research workspace
   Core: state, navigation, directory (gallery + table), side peek.
   Requires data.js (window.__DATA__) and views.js.
   ========================================================================== */
(function () {
  'use strict';

  var DATA = window.__DATA__ || [];

  /* ---------- vocab ---------- */
  var CLS = {
    ai_native_service: { l: 'AI-native service', t: 'green' },
    hybrid:            { l: 'Hybrid / unclear', t: 'yellow' },
    ai_enabled_service:{ l: 'AI-enabled service', t: 'blue' },
    ai_copilot_or_tool:{ l: 'Copilot or tool', t: 'purple' }
  };
  var EV = { high: 'High', medium: 'Medium', low: 'Low' };
  var EVT = { high: 'green', medium: 'yellow', low: 'red' };

  var BANDS = [
    { k: 'human_led',       t: 'AI-Assisted',                    d: 'Human performs the work; AI raises throughput.',          c: '#cb912f' },
    { k: 'human_supervised',t: 'AI-Executed, Human-Supervised',  d: 'AI does the work; a person reviews or approves.',         c: '#d9730d' },
    { k: 'ai_led',          t: 'AI-Led Service Delivery',        d: 'AI runs the workflow; humans handle exceptions.',          c: '#448361' },
    { k: 'autonomous',      t: 'Predominantly Autonomous',       d: 'Company claims execution with no human hand-offs.',        c: '#2f6f4f' },
    { k: 'unknown',         t: 'Insufficient Evidence',          d: 'Public material does not say who does the work.',          c: '#9b9a97' }
  ];

  /* The delivery band is a function of the delivery model first, the documented
     human involvement second. A tool the customer operates can never sit in an
     AI-led band, however autonomous its internals are. */
  function band(c) {
    if (c.classification === 'ai_copilot_or_tool' || c.classification === 'ai_enabled_service') return 'human_led';
    var s = c.autonomy_score || 0;
    if (s >= 5) return 'autonomous';
    if (s >= 4) return 'ai_led';
    if (s >= 3) return 'human_supervised';
    if (s >= 2) return 'human_led';
    return 'unknown';
  }
  function bandMeta(c) {
    var k = band(c);
    for (var i = 0; i < BANDS.length; i++) if (BANDS[i].k === k) return BANDS[i];
    return BANDS[4];
  }

  /* ---------- helpers ---------- */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }
  function el(id) { return document.getElementById(id); }
  function tag(text, tone, outline) {
    return '<span class="tag ' + (outline ? 'outline' : 't-' + tone) + '">' + esc(text) + '</span>';
  }
  function clsTag(c) { var m = CLS[c.classification] || { l: c.classification, t: 'gray' }; return tag(m.l, m.t); }
  function bandTag(c) { var m = bandMeta(c); return tag(m.t, m.k === 'ai_led' ? 'green' : m.k === 'autonomous' ? 'green' : m.k === 'human_supervised' ? 'orange' : m.k === 'human_led' ? 'yellow' : 'gray'); }
  function evTag(c) { return tag(EV[c.strength_of_evidence] + ' evidence', EVT[c.strength_of_evidence]); }
  function batchKey(b) {
    var m = /([A-Za-z]+)\s+(\d{4})/.exec(b || ''); if (!m) return 0;
    var off = { S: 0, F: 1, W: 2 }[(b[0] || '').toUpperCase()] || 0;
    return (+m[2]) * 10 + off;
  }
  function initials(n) { return (n || '?').slice(0, 1).toUpperCase(); }
  function countBy(arr, fn) {
    var o = {}; arr.forEach(function (x) { var k = fn(x); o[k] = (o[k] || 0) + 1; }); return o;
  }

  /* ---------- state ---------- */
  var state = {
    view: 'overview',
    layout: 'gallery',
    q: '', ind: '', batch: '', cls: '', hum: '', ev: '',
    sort: 'autonomy', sortDir: -1,
    chips: {}
  };

  /* ---------- navigation ---------- */
  var VIEW_LABEL = {
    overview: 'Overview', directory: 'Directory', horizontal: 'Horizontal',
    spectrum: 'Spectrum', compare: 'Compare', insights: 'Insights',
    method: 'Method & coverage'
  };

  function go(v) {
    state.view = v;
    Array.prototype.forEach.call(document.querySelectorAll('.view'), function (s) { s.classList.remove('on'); });
    var sec = el('v-' + v); if (sec) sec.classList.add('on');
    Array.prototype.forEach.call(document.querySelectorAll('.nav-item'), function (b) {
      b.classList.toggle('on', b.dataset.v === v);
    });
    el('crumb').innerHTML = '<b>AI-Native Services</b><span class="sep">/</span>' + esc(VIEW_LABEL[v] || v);
    /* Only prose views get the narrow measure. Spectrum (5 columns) and Compare
       (11-column matrix) need the full width, or their columns end up cramped. */
    var NARROW = { overview: 1, insights: 1, method: 1 };
    el('content').classList.toggle('narrow', !!NARROW[v]);
    el('sidebar').classList.remove('open');
    if (el('sbScrim')) el('sbScrim').classList.remove('on');
    window.scrollTo(0, 0);
    if (v === 'horizontal') window.__renderHorizontal();
    if (v === 'spectrum') window.__renderSpectrum();
    if (v === 'compare') window.__renderCompare();
    if (v === 'insights') window.__renderInsights();
    if (v === 'method') window.__renderMethod();
  }

  /* ---------- filters ---------- */
  function uniq(fn) { var s = {}; DATA.forEach(function (c) { s[fn(c)] = 1; }); return Object.keys(s).sort(); }

  function fillSelects() {
    function opts(list, ph, labelFn) {
      return '<option value="">' + ph + '</option>' + list.map(function (v) {
        return '<option value="' + esc(v) + '">' + esc(labelFn ? labelFn(v) : v) + '</option>';
      }).join('');
    }
    el('fInd').innerHTML = opts(uniq(function (c) { return c.industry; }), 'All industries');
    el('fBatch').innerHTML = opts(
      uniq(function (c) { return c.yc_batch; }).sort(function (a, b) { return batchKey(b) - batchKey(a); }),
      'All batches');
    el('fClass').innerHTML = '<option value="">All classifications</option>' +
      Object.keys(CLS).map(function (k) { return '<option value="' + k + '">' + esc(CLS[k].l) + '</option>'; }).join('');
    el('fHum').innerHTML = opts(uniq(function (c) { return c.human_involvement; }), 'All');
    el('fEv').innerHTML = '<option value="">All evidence</option>' +
      Object.keys(EV).map(function (k) { return '<option value="' + k + '">' + EV[k] + '</option>'; }).join('');
  }

  var CHIP_DEFS = [
    ['AI-led or autonomous', function (c) { return band(c) === 'ai_led' || band(c) === 'autonomous'; }],
    ['AI-native classification', function (c) { return c.classification === 'ai_native_service'; }],
    ['High-confidence evidence', function (c) { return c.strength_of_evidence === 'high'; }],
    ['Priced per outcome or fee', function (c) { return /fee|commission|contingency|per call|per claim|percentage|flat|\$/i.test(c.business_model || ''); }],
    ['Insurance', function (c) { return /insurance/i.test(c.industry); }],
    ['Accounting / tax', function (c) { return /account|tax|invoice|bookkeep/i.test(c.service_category + c.traditional_service_replaced); }],
    ['Healthcare admin', function (c) { return /health|medical|billing|credential|payor|payer|dental/i.test(c.industry + c.service_category); }],
    ['Legal', function (c) { return /legal|law firm/i.test(c.industry + c.service_category); }],
    ['Human review is mandatory', function (c) { return c.autonomy_score === 3; }],
    ['Unknown human involvement', function (c) { return band(c) === 'unknown'; }]
  ];

  function passes(c) {
    if (state.q) {
      var hay = [c.company_name, c.industry, c.service_category, c.customer_purchases,
                 c.traditional_service_replaced, c.target_customer, c.business_model,
                 c.yc_one_liner || ''].join(' ').toLowerCase();
      if (hay.indexOf(state.q.toLowerCase()) === -1) return false;
    }
    if (state.ind && c.industry !== state.ind) return false;
    if (state.batch && c.yc_batch !== state.batch) return false;
    if (state.cls && c.classification !== state.cls) return false;
    if (state.hum && c.human_involvement !== state.hum) return false;
    if (state.ev && c.strength_of_evidence !== state.ev) return false;
    for (var i = 0; i < CHIP_DEFS.length; i++) {
      var name = CHIP_DEFS[i][0];
      if (state.chips[name] && !CHIP_DEFS[i][1](c)) return false;
    }
    return true;
  }

  function activePills() {
    var out = [];
    if (state.q) out.push(['Search', state.q, function () { state.q = ''; el('q').value = ''; }]);
    if (state.ind) out.push(['Industry', state.ind, function () { state.ind = ''; el('fInd').value = ''; }]);
    if (state.batch) out.push(['Batch', state.batch, function () { state.batch = ''; el('fBatch').value = ''; }]);
    if (state.cls) out.push(['Classification', (CLS[state.cls] || {}).l || state.cls, function () { state.cls = ''; el('fClass').value = ''; }]);
    if (state.hum) out.push(['Human involvement', state.hum, function () { state.hum = ''; el('fHum').value = ''; }]);
    if (state.ev) out.push(['Evidence', EV[state.ev], function () { state.ev = ''; el('fEv').value = ''; }]);
    CHIP_DEFS.forEach(function (d) {
      if (state.chips[d[0]]) out.push(['Filter', d[0], function () { delete state.chips[d[0]]; }]);
    });
    return out;
  }

  function renderPills() {
    var pills = activePills();
    el('pills').innerHTML = pills.map(function (p, i) {
      return '<span class="pill"><span class="k">' + esc(p[0]) + '</span><b>' + esc(p[1]) + '</b>' +
             '<button data-p="' + i + '">✕</button></span>';
    }).join('') + (pills.length > 1 ? '<button class="pill-clear" id="pillClear">Clear all</button>' : '');
    el('pills').querySelectorAll('.pill button').forEach(function (b) {
      b.onclick = function () { pills[+b.dataset.p][2](); render(); };
    });
    var pc = el('pillClear');
    if (pc) pc.onclick = function () {
      state.q = ''; state.ind = ''; state.batch = ''; state.cls = ''; state.hum = ''; state.ev = ''; state.chips = {};
      el('q').value = ''; el('fInd').value = ''; el('fBatch').value = ''; el('fClass').value = '';
      el('fHum').value = ''; el('fEv').value = ''; render();
    };
  }

  function renderChips() {
    el('chipRow').innerHTML = CHIP_DEFS.map(function (d) {
      return '<button class="tag ' + (state.chips[d[0]] ? 't-blue' : 'outline') + '" data-chip="' + esc(d[0]) +
             '" style="margin:0 5px 5px 0;cursor:pointer">' + esc(d[0]) + '</button>';
    }).join('');
    el('chipRow').querySelectorAll('[data-chip]').forEach(function (b) {
      b.onclick = function () {
        var n = b.dataset.chip;
        if (state.chips[n]) delete state.chips[n]; else state.chips[n] = true;
        render();
      };
    });
  }

  /* ---------- sorting ---------- */
  var SORTS = [
    ['autonomy', 'Autonomy (high → low)'],
    ['evidence', 'Evidence (high → low)'],
    ['batch', 'Newest batch'],
    ['name', 'Name (A → Z)']
  ];
  function sorted() {
    var rows = DATA.filter(passes);
    var evo = { high: 3, medium: 2, low: 1 };
    rows.sort(function (a, b) {
      var r = 0;
      if (state.sort === 'autonomy') r = (b.autonomy_score || 0) - (a.autonomy_score || 0) || a.company_name.localeCompare(b.company_name);
      else if (state.sort === 'evidence') r = (evo[b.strength_of_evidence] || 0) - (evo[a.strength_of_evidence] || 0) || a.company_name.localeCompare(b.company_name);
      else if (state.sort === 'batch') r = batchKey(b.yc_batch) - batchKey(a.yc_batch);
      else r = a.company_name.localeCompare(b.company_name);
      return r;
    });
    return rows;
  }

  /* ---------- directory ---------- */
  function renderDir() {
    var rows = sorted();
    el('cnt').textContent = rows.length + ' of ' + DATA.length;
    el('navCount').textContent = DATA.length;
    var body = el('dirBody');

    if (!rows.length) {
      body.innerHTML = '<div class="empty">No companies match these filters.</div>';
      return;
    }

    if (state.layout === 'gallery') {
      body.innerHTML = '<div class="gallery">' + rows.map(function (c) {
        var logo = c.logo
          ? '<img src="' + esc(c.logo) + '" alt="" loading="lazy">'
          : '<div class="ph">' + esc(initials(c.company_name)) + '</div>';
        return '<button class="gcard" data-n="' + esc(c.company_name) + '">' +
          '<div class="gcard-top">' + logo +
            '<div><h3>' + esc(c.company_name) + '</h3>' +
            '<div style="font-size:12px;color:var(--ink-3);margin-top:3px">' + esc(c.yc_batch) + ' · ' + esc(c.industry) + '</div></div>' +
          '</div>' +
          '<div class="one">' + esc(c.customer_purchases) + '</div>' +
          '<div class="tags">' + clsTag(c) + bandTag(c) + evTag(c) + '</div>' +
        '</button>';
      }).join('') + '</div>';
    } else {
      body.innerHTML = '<div class="tablewrap"><table class="db"><thead><tr>' +
        ['Company', 'Batch', 'Industry', 'Classification', 'Delivery band', 'Human involvement', 'Evidence', 'What the customer buys']
          .map(function (h) { return '<th>' + h + '</th>'; }).join('') +
        '</tr></thead><tbody>' + rows.map(function (c) {
          return '<tr data-n="' + esc(c.company_name) + '" tabindex="0" role="button">' +
            '<td class="name">' + esc(c.company_name) + '</td>' +
            '<td class="nowrap">' + esc(c.yc_batch) + '</td>' +
            '<td class="nowrap">' + esc(c.industry) + '</td>' +
            '<td>' + clsTag(c) + '</td>' +
            '<td>' + bandTag(c) + '</td>' +
            '<td class="tight">' + esc(c.human_involvement) + '</td>' +
            '<td>' + evTag(c) + '</td>' +
            '<td class="tight">' + esc(c.customer_purchases) + '</td>' +
          '</tr>';
        }).join('') + '</tbody></table></div>';
    }

    body.querySelectorAll('[data-n]').forEach(function (n) {
      n.onclick = function () { openPeek(n.dataset.n); };
      /* Rows are clickable, so they must also be operable from the keyboard. */
      if (n.tagName === 'TR') n.onkeydown = function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPeek(n.dataset.n); }
      };
    });
  }

  /* ---------- sort menu ---------- */
  function renderSortMenu() {
    var m = el('sortMenu');
    m.innerHTML = SORTS.map(function (s) {
      return '<button class="nav-item' + (state.sort === s[0] ? ' on' : '') + '" data-s="' + s[0] +
        '" style="font-size:13px;padding:4px 8px">' + esc(s[1]) +
        (state.sort === s[0] ? '<span class="n">✓</span>' : '') + '</button>';
    }).join('');
    m.querySelectorAll('[data-s]').forEach(function (b) {
      b.onclick = function () { state.sort = b.dataset.s; m.style.display = 'none'; render(); };
    });
  }

  /* ---------- side peek ---------- */
  function openPeek(name) {
    var c = null;
    for (var i = 0; i < DATA.length; i++) if (DATA[i].company_name === name) { c = DATA[i]; break; }
    if (!c) return;

    el('peekCrumb').innerHTML = '<b>Directory</b><span class="sep">/</span>' + esc(c.company_name);

    var steps = (c.ai_workflow || []).map(function (s, i) {
      return '<div class="fstep m-' + esc(s.execution_mode) + '">' +
        '<div class="rail"><div class="num">' + (i + 1) + '</div><div class="line"></div></div>' +
        '<div class="fb"><div class="ft">' + esc(s.step) + '</div>' +
          '<div class="fd">' + esc(s.description) + '</div>' +
          '<div class="fe">' + tag(s.execution_mode, s.execution_mode === 'ai' ? 'green' : s.execution_mode === 'human' ? 'yellow' : 'blue') +
            (s.evidence_url ? '<a href="' + esc(s.evidence_url) + '" target="_blank" rel="noopener">source ↗</a>' : '') +
          '</div></div></div>';
    }).join('');

    var flow = steps ? '<h2 class="h2"><span class="chev">▼</span>Service delivery workflow</h2>' +
      '<p class="sub">Each stage as the company describes it, with the execution mode and the source it came from.</p>' +
      '<div class="flow">' + steps + '</div>' +
      '<div class="legend">' +
        '<span><i class="dot" style="background:#448361"></i>AI</span>' +
        '<span><i class="dot" style="background:#cb912f"></i>Human</span>' +
        '<span><i class="dot" style="background:#2383e2"></i>Hybrid</span>' +
      '</div>' : '';

    var metrics = (c.publicly_reported_metrics || []).length
      ? '<h2 class="h2"><span class="chev">▼</span>Publicly reported metrics</h2><ul class="tight">' +
        c.publicly_reported_metrics.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>' : '';

    var limits = (c.limitations || []).length
      ? '<h2 class="h2"><span class="chev">▼</span>What remains unknown</h2><ul class="tight">' +
        c.limitations.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>' : '';

    /* Some records have no company site, so the YC listing is stored as the
       website placeholder. Showing it twice (Website + Sources) is misleading,
       so the Website row is suppressed and the YC link appears in Sources only. */
    var siteIsYc = /ycombinator\.com/.test(c.website || '');
    var siteRow = siteIsYc
      ? '<dt>Website</dt><dd class="muted">Not published — YC listing only</dd>'
      : '<dt>Website</dt><dd><a href="' + esc(c.website) + '" target="_blank" rel="noopener">' +
        esc((c.website || '').replace(/^https?:\/\//, '').replace(/\/$/, '')) + '</a></dd>';

    /* Dedupe the source list. A company site can appear in both `sources` and
       `website`; a YC link can appear in `sources` under a stale slug (which
       301-redirects) while `yc_url` holds the canonical one. YC links are
       therefore dropped from `sources` and re-added once from `yc_url`. */
    var seen = {};
    var srcItems = [];
    (c.sources || []).concat([c.yc_url]).forEach(function (s) {
      if (!s || seen[s]) return;
      if (s !== c.yc_url && /ycombinator\.com/.test(s)) return;
      seen[s] = 1;
      var label = s.replace(/^https?:\/\//, '').replace(/\/$/, '');
      srcItems.push('<li><a href="' + esc(s) + '" target="_blank" rel="noopener">' + esc(label) + '</a>' +
        (s === c.yc_url ? ' <span class="ext">YC profile</span>' : '') + '</li>');
    });

    el('peekBody').innerHTML =
      '<div class="peek-icon">' + (c.logo ? '<img src="' + esc(c.logo) + '" alt="" style="width:40px;height:40px;border-radius:4px;object-fit:contain;border:1px solid var(--line)">' : '🏢') + '</div>' +
      '<h1 class="peek-title">' + esc(c.company_name) + '</h1>' +
      (c.yc_one_liner ? '<p class="peek-one">' + esc(c.yc_one_liner) + '</p>' : '') +
      '<div class="peek-tags">' + clsTag(c) + bandTag(c) + evTag(c) +
        (c.status && c.status !== 'Active' ? '<span class="tag t-red">' + esc(c.status) + '</span>' : '') + '</div>' +
      '<div class="peek-meta">' + esc(c.yc_batch) + ' · ' + esc(c.industry) +
        (c.locations ? ' · ' + esc(c.locations) : '') + '</div>' +

      '<h2 class="h2"><span class="chev">▼</span>Properties</h2>' +
      '<dl class="props">' +
        '<dt>Service category</dt><dd>' + esc(c.service_category) + '</dd>' +
        '<dt>Traditional service replaced</dt><dd>' + esc(c.traditional_service_replaced) + '</dd>' +
        '<dt>Target customer</dt><dd>' + esc(c.target_customer) + '</dd>' +
        '<dt>What they buy</dt><dd>' + esc(c.customer_purchases) + '</dd>' +
        '<dt>Human involvement</dt><dd>' + esc(c.human_involvement) + '</dd>' +
        '<dt>Business model</dt><dd>' + esc(c.business_model) + '</dd>' +
        '<dt>Team size</dt><dd>' + (c.team_size ? esc(String(c.team_size)) + ' people' : 'Not disclosed') + '</dd>' +
        '<dt>Status</dt><dd>' + esc(c.status || 'Unknown') + '</dd>' +
        siteRow +
      '</dl>' +

      flow + metrics + limits +

      '<h2 class="h2"><span class="chev">▼</span>Sources</h2>' +
      '<ul class="srcs">' + srcItems.join('') + '</ul>' +
      '<p class="muted" style="font-size:12px;margin-top:14px">Last verified ' + esc(c.last_verified) + '. All metrics are company-published claims.</p>';

    el('peek').classList.add('on');
    el('scrim').classList.add('on');
    el('peekBody').scrollTop = 0;
  }

  function closePeek() {
    el('peek').classList.remove('on');
    el('scrim').classList.remove('on');
  }

  /* ---------- render ---------- */
  function render() {
    renderPills();
    renderChips();
    renderDir();
    renderSortMenu();
  }

  /* ---------- overview ---------- */
  function renderOverview() {
    var n = DATA.length;
    var nat = DATA.filter(function (c) { return c.classification === 'ai_native_service'; }).length;
    var aut = DATA.filter(function (c) { return band(c) === 'ai_led' || band(c) === 'autonomous'; }).length;
    var hi = DATA.filter(function (c) { return c.strength_of_evidence === 'high'; }).length;
    var inds = Object.keys(countBy(DATA, function (c) { return c.industry; })).length;

    el('ovStats').innerHTML = [
      [n, 'Companies researched'],
      [nat, 'Classified AI-native'],
      [aut, 'AI-led or autonomous'],
      [hi, 'High-confidence evidence'],
      [inds, 'Industries covered'],
      ['6,349', 'YC companies screened']
    ].map(function (s) {
      return '<div class="stat"><div class="n">' + s[0] + '</div><div class="l">' + s[1] + '</div></div>';
    }).join('');

    el('ovStages').innerHTML = [
      ['Stage 1', 'Traditional Service', 'Humans at a firm perform the work. The customer buys labour — billed hourly, by retainer, or as contingency.', 0],
      ['Stage 2', 'SaaS Software', 'The firm sells a tool. The customer\u2019s staff still perform the work, now inside software.', 0],
      ['Stage 3', 'AI Copilot', 'Software drafts and assists. The customer\u2019s staff still own and complete the work.', 0],
      ['Stage 4', 'AI-Native Service', 'AI performs the work. The customer buys the finished outcome, not a seat.', 1]
    ].map(function (s) {
      return '<div class="stage' + (s[3] ? ' hi' : '') + '"><div class="k">' + s[0] + '</div>' +
        '<div class="t">' + s[1] + '</div><div class="d">' + s[2] + '</div></div>';
    }).join('');
  }

  /* ---------- collapsible headings ----------
     Delegated on the document so headings rendered later (insights, method,
     the side peek) collapse too, not just those present at boot. */
  function wireCollapse() {
    document.addEventListener('click', function (e) {
      var ch = e.target.closest ? e.target.closest('.h2 .chev') : null;
      if (!ch) return;
      var h = ch.closest('.h2');
      if (!h) return;
      var collapsed = h.classList.toggle('collapsed');
      var n = h.nextElementSibling;
      while (n && !(n.classList && (n.classList.contains('h2') || n.classList.contains('phead') || n.tagName === 'SECTION'))) {
        if (n.nodeType === 1) n.style.display = collapsed ? 'none' : '';
        n = n.nextElementSibling;
      }
    });
  }

  /* ---------- wire ---------- */
  function boot() {
    renderOverview();
    fillSelects();
    render();
    wireCollapse();
    go('overview');

    document.querySelectorAll('.nav-item[data-v]').forEach(function (b) {
      b.onclick = function () { go(b.dataset.v); };
    });

    el('q').oninput = function (e) { state.q = e.target.value; render(); };
    [['fInd', 'ind'], ['fBatch', 'batch'], ['fClass', 'cls'], ['fHum', 'hum'], ['fEv', 'ev']].forEach(function (p) {
      el(p[0]).onchange = function (e) { state[p[1]] = e.target.value; render(); };
    });

    el('tGallery').onclick = function () {
      state.layout = 'gallery'; el('tGallery').classList.add('on'); el('tTable').classList.remove('on'); render();
    };
    el('tTable').onclick = function () {
      state.layout = 'table'; el('tTable').classList.add('on'); el('tGallery').classList.remove('on'); render();
    };
    el('tSort').onclick = function (e) {
      e.stopPropagation();
      var m = el('sortMenu'); m.style.display = m.style.display === 'none' ? '' : 'none';
    };
    document.addEventListener('click', function () { el('sortMenu').style.display = 'none'; });
    el('tChips').onclick = function () {
      var r = el('chipRow'); r.style.display = r.style.display === 'none' ? '' : 'none';
      el('tChips').classList.toggle('on', r.style.display !== 'none');
    };

    el('peekClose').onclick = closePeek;
    el('scrim').onclick = closePeek;
    /* Note the two different open-state conventions: the peek uses `.on`,
       the sidebar uses `.open`. Escape closes the peek first, then the sidebar. */
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (el('peek').classList.contains('on')) { closePeek(); return; }
      if (el('sidebar').classList.contains('open')) toggleSidebar();
    });

    var mq = window.matchMedia('(max-width: 900px)');
    function layout() {
      el('btnSidebar').style.display = mq.matches ? '' : 'none';
      if (!mq.matches) { el('sidebar').classList.remove('open'); el('sbScrim').classList.remove('on'); }
    }
    layout(); mq.addEventListener('change', layout);

    function toggleSidebar() {
      var open = el('sidebar').classList.toggle('open');
      el('sbScrim').classList.toggle('on', open);
      el('btnSidebar').setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    el('btnSidebar').onclick = toggleSidebar;
    el('sbScrim').onclick = toggleSidebar;

    el('sbFoot').innerHTML = DATA.length + ' companies · 215 workflow steps<br>Screened from 6,349 YC records<br>Verified 28 Oct 2026';
  }

  window.__go = go;
  window.__band = band;
  window.__BANDS = BANDS;
  window.__CLS = CLS;
  window.__EV = EV;
  window.__EVT = EVT;
  window.__esc = esc;
  window.__tag = tag;
  window.__clsTag = clsTag;
  window.__bandTag = bandTag;
  window.__evTag = evTag;
  window.__batchKey = batchKey;
  window.__countBy = countBy;
  window.__openPeek = openPeek;
  window.__DATA = DATA;

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
