import puppeteer from 'puppeteer-core';
const URL='http://127.0.0.1:12000/index.html';
const browser = await puppeteer.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--hide-scrollbars'],headless:true,defaultViewport:{width:1440,height:1000}});
const page = await browser.newPage();
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await page.goto(URL,{waitUntil:'networkidle2'});
await new Promise(r=>setTimeout(r,600));

const VIEWS=['overview','directory','horizontal','spectrum','compare','insights','method'];
for(const v of VIEWS){
  await page.evaluate(vv=>{document.querySelectorAll('.nav-item[data-v]').forEach(b=>{if(b.dataset.v===vv)b.click()})},v);
  await new Promise(r=>setTimeout(r,350));
}

// contrast helpers
const res = await page.evaluate(() => {
  function lum(c){const [r,g,b]=c;const f=v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)};return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b)}
  function parse(s){const m=s.match(/rgba?\(([^)]+)\)/);if(!m)return null;const p=m[1].split(',').map(x=>parseFloat(x));return {rgb:[p[0],p[1],p[2]],a:p.length>3?p[3]:1}}
  function bgOf(el){let n=el;while(n&&n!==document.documentElement){const s=getComputedStyle(n);const c=parse(s.backgroundColor);if(c&&c.a>0.95)return c.rgb;n=n.parentElement}return [255,255,255]}
  function ratio(a,b){const L1=lum(a),L2=lum(b);const hi=Math.max(L1,L2),lo=Math.min(L1,L2);return (hi+0.05)/(lo+0.05)}
  const out={contrast:[],smallTargets:[],fontSizes:{},spacing:{}};
  const seen=new Set();
  document.querySelectorAll('.view.on *, body>.app *, .sidebar *').forEach(el=>{
    if(!el.textContent||!el.textContent.trim()||el.children.length)return;
    const r=el.getBoundingClientRect(); if(r.width===0||r.height===0)return;
    const s=getComputedStyle(el); const fg=parse(s.color); if(!fg)return;
    const bg=bgOf(el); const cr=ratio(fg.rgb,bg);
    const fs=parseFloat(s.fontSize), fw=parseInt(s.fontWeight)||400;
    const large = fs>=24 || (fs>=18.66 && fw>=700);
    const need = large?3:4.5;
    if(cr<need){
      const k=el.className+'|'+Math.round(cr*100)+'|'+s.color;
      if(!seen.has(k)){seen.add(k);out.contrast.push({cls:String(el.className).slice(0,28),txt:el.textContent.trim().slice(0,32),fs,fw,cr:Math.round(cr*100)/100,need,color:s.color})}
    }
  });
  // click targets
  document.querySelectorAll('.view.on button,.view.on a,.view.on select,.view.on input,.sidebar button').forEach(el=>{
    const r=el.getBoundingClientRect(); if(r.width===0)return;
    if(r.height<24||r.width<24){
      const k=el.tagName+'.'+String(el.className).slice(0,20);
      if(!seen.has('T'+k)){seen.add('T'+k);out.smallTargets.push({el:k,w:Math.round(r.width),h:Math.round(r.height),txt:(el.textContent||el.placeholder||'').trim().slice(0,28)})}
    }
  });
  // font size histogram
  document.querySelectorAll('.view.on *, body>.app *, .sidebar *').forEach(el=>{
    if(!el.textContent||!el.textContent.trim()||el.children.length)return;
    const fs=getComputedStyle(el).fontSize; out.fontSizes[fs]=(out.fontSizes[fs]||0)+1;
  });
  // content width
  const c=document.querySelector('#content');
  out.spacing={contentWidth:Math.round(c.getBoundingClientRect().width),
    sidebarWidth:Math.round(document.querySelector('.sidebar').getBoundingClientRect().width),
    bodyScrollW:document.documentElement.scrollWidth};
  return out;
});
console.log(JSON.stringify({errs,res},null,1));
await browser.close();
