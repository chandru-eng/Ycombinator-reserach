# -*- coding: utf-8 -*-
import json
D=[]
def C(**k): D.append(k)

C(company_name="Balance", yc_batch="Winter 2026", website="https://getbalance.ai",
 industry="Fintech / B2B", service_category="AI-native accounting and bookkeeping service",
 classification="ai_native_service",
 traditional_service_replaced="Outsourced bookkeeping and management accounting: reconciling, categorising, matching documents, month-end close, and signing off the books",
 target_customer="E-commerce, marketplaces, hospitality and other SMEs needing ongoing bookkeeping (150+ companies cited)",
 customer_purchases="Audit-ready books and ongoing accounting delivered as a service at a flat monthly price, with a named accountant who signs off",
 ai_workflow=[
  {"step":"Document ingestion","description":"'Our own agents reconcile, categorise and match documents against your ledger, continuously through the month.'","execution_mode":"ai","evidence_url":"https://getbalance.ai"},
  {"step":"Continuous reconciliation","description":"'Books that never fall behind' - reconciliation runs through the month rather than at period end.","execution_mode":"ai","evidence_url":"https://getbalance.ai"},
  {"step":"Ledger posting","description":"The work is automated; agents categorise and match against the ledger.","execution_mode":"ai","evidence_url":"https://getbalance.ai"},
  {"step":"Accountant review & sign-off","description":"'The AI does the manual work, our accountants review'; 'A real accountant, every month'; 'Signed off by Merlin'.","execution_mode":"human","evidence_url":"https://getbalance.ai"},
  {"step":"Client Q&A","description":"Financial assistant ('Bea') answers questions such as 'How did our income and expenses look in Q1?' in seconds.","execution_mode":"ai","evidence_url":"https://getbalance.ai"},
 ],
 human_involvement="AI-led execution with exception-based human review (accountant signs off monthly)",
 business_model="Flat monthly fee for accounting as a service ('a flat monthly price'); no hourly billing for questions",
 publicly_reported_metrics=["Trusted by 150+ companies","Customer quote: 'about a third less than we paid before'","'Books ... closed in days'"],
 strength_of_evidence="high",
 limitations=["'About a third less' is a single customer's recollection, not audited pricing","No published headcount-to-client ratio","Pricing amount not published on the captured pages"],
 sources=["https://getbalance.ai","https://getbalance.ai/how-it-works","https://getbalance.ai/faq","https://www.ycombinator.com/companies/getbalance"],
 last_verified="2026-10-28")

C(company_name="Bear", yc_batch="Summer 2026", website="https://bear.inc/",
 industry="Fintech / B2B", service_category="AI-native accounting firm",
 classification="ai_native_service",
 traditional_service_replaced="Traditional accounting firm engagement (bookkeeping, tax, compliance work performed by a firm)",
 target_customer="Startups and small businesses that would otherwise hire an accounting firm",
 customer_purchases="An accounting firm's output delivered by an AI-native firm",
 ai_workflow=[
  {"step":"Firm-level delivery","description":"YC one-liner: 'AI-native accounting firm.' The website presents the company as an accounting firm, with a countdown teaser ('Looking for Last Accounting Company?').","execution_mode":"hybrid","evidence_url":"https://bear.inc/"},
 ],
 human_involvement="Unknown or insufficient evidence",
 business_model="Not publicly disclosed",
 publicly_reported_metrics=[],
 strength_of_evidence="low",
 limitations=["Website content is a teaser/countdown; no workflow detail is public","No pricing or delivery detail","Classified AI-native on the strength of the firm framing and YC listing only"],
 sources=["https://bear.inc/","https://www.ycombinator.com/companies/bear-inc"],
 last_verified="2026-10-28")

C(company_name="Billow AI Labs", yc_batch="Summer 2026", website="https://thebillow.ai/",
 industry="B2B / Fintech", service_category="AI accounting close automation as a delegated service",
 classification="ai_native_service",
 traditional_service_replaced="Manual finance-team close work: bank and credit card reconciliations, accruals, prepaids, fixed assets, payroll and expense entries, multi-entity consolidation, reporting and close workpapers",
 target_customer="Finance teams running NetSuite, Dynamics 365 or QuickBooks",
 customer_purchases="The month-end close executed on the customer's own accounting stack, with the team reviewing and approving",
 ai_workflow=[
  {"step":"Learn the close","description":"'Built from 3 closes you ran by hand' then 'We take over. We learn your process and build around it.'","execution_mode":"hybrid","evidence_url":"https://thebillow.ai/"},
  {"step":"Pull trial balance","description":"Close workflow step: 'Pull trial balance' from NetSuite.","execution_mode":"ai","evidence_url":"https://thebillow.ai/"},
  {"step":"Match transactions","description":"Close workflow step: 'Match transactions' performed by an agent.","execution_mode":"ai","evidence_url":"https://thebillow.ai/"},
  {"step":"Send for approval","description":"Close workflow step: 'Send for approval' - human review of the agent's output.","execution_mode":"human","evidence_url":"https://thebillow.ai/"},
  {"step":"Handled work types","description":"'Bank and credit card reconciliations, Accruals, prepaids and fixed assets, Payroll and expense entries, Multi-entity consolidation, Financial reporting and close workpapers.'","execution_mode":"ai","evidence_url":"https://thebillow.ai/"},
 ],
 human_involvement="AI-led execution with exception-based human review ('Your team reviews and approves')",
 business_model="Not publicly disclosed; sold as delegating manual finance work to AI on top of the customer's existing tools",
 publicly_reported_metrics=["Named customer testimonial from a CPA (Corey Pecoraro)"],
 strength_of_evidence="medium",
 limitations=["Pricing not published","No quantified automation rate","The customer's own team still reviews and approves, so the service augments rather than fully replaces the finance team"],
 sources=["https://thebillow.ai/","https://thebillow.ai/case-studies","https://www.ycombinator.com/companies/billow-ai-labs"],
 last_verified="2026-10-28")

C(company_name="Rational", yc_batch="Summer 2026", website="https://rational.to",
 industry="Fintech / B2B", service_category="End-to-end agentic accounting service",
 classification="ai_native_service",
 traditional_service_replaced="Accounting and tax function performed by accountants or an outsourced accounting firm",
 target_customer="Startups and enterprise teams",
 customer_purchases="'End-to-end agentic accounting' - accounting work handed off with instant setup, 24/7 support and experts on demand",
 ai_workflow=[
  {"step":"Automatic onboarding","description":"'Hand off your accounting and tax with instant setup / Automatic onboarding, 24/7 support, experts whenever you need.'","execution_mode":"hybrid","evidence_url":"https://rational.to"},
  {"step":"Agentic execution","description":"'Building AI employees for accounting'; 'End-to-end agentic accounting.'","execution_mode":"ai","evidence_url":"https://rational.to"},
  {"step":"Accountant review of consequential decisions","description":"'Consequential decisions belong with the accountant, with the source material and context close at hand.'","execution_mode":"human","evidence_url":"https://rational.to"},
  {"step":"Team capacity review","description":"'We'll walk through how Rational handles the work, where your team reviews, and what a first workflow could look like.'","execution_mode":"human","evidence_url":"https://rational.to"},
 ],
 human_involvement="AI-led execution with exception-based human review",
 business_model="Subscription: 'From $399/month with an annual agreement' (startup pricing)",
 publicly_reported_metrics=["Startup pricing from $399/month with an annual agreement"],
 strength_of_evidence="medium",
 limitations=["Pricing threshold is public but the full price ladder is not","No published automation rate or client count","'Zero-human accounting firm' appears in the YC one-liner but the site itself keeps accountants on consequential decisions"],
 sources=["https://rational.to","https://rational.to/pricing","https://www.ycombinator.com/companies/rational"],
 last_verified="2026-10-28")

C(company_name="Sintropix", yc_batch="Fall 2026", website="https://sintropix.com/",
 industry="Fintech / B2B", service_category="Autonomous multi-country accounting / finance ERP as a service",
 classification="ai_native_service",
 traditional_service_replaced="Multi-country bookkeeping and financial close performed by an accounting firm or in-house finance team",
 target_customer="Multi-country LATAM startups",
 customer_purchases="Closed books and financial clarity - 'We close your books and give you financial clarity while you run your business'",
 ai_workflow=[
  {"step":"Automated close","description":"YC one-liner: 'Autonomous accounting platform for global companies'; the site describes closing the books while the client runs the business.","execution_mode":"ai","evidence_url":"https://sintropix.com/"},
  {"step":"Consolidated reporting","description":"Live consolidated snapshot across five countries (cash, ARR, burn, runway) with an assistant ('Erwin') answering questions.","execution_mode":"ai","evidence_url":"https://sintropix.com/"},
 ],
 human_involvement="Unknown or insufficient evidence",
 business_model="Not publicly disclosed (ERP/finance service framing)",
 publicly_reported_metrics=["Illustrative dashboard: consolidated cash $1.37M, ARR $4.2M, monthly burn $312K, 14 months runway"],
 strength_of_evidence="low",
 limitations=["Site content captured is largely in Spanish; product detail is thin in the captured pages","No pricing","No published automation rate or customer outcomes","Very early (Fall 2026)"],
 sources=["https://sintropix.com/","https://www.ycombinator.com/companies/sintropix"],
 last_verified="2026-10-28")

C(company_name="Cifrato", yc_batch="Winter 2025", website="https://cifrato.ai",
 industry="Fintech / B2B", service_category="Agentic invoice processing, reconciliation and compliance",
 classification="ai_native_service",
 traditional_service_replaced="Manual accounting data entry: invoice intake, classification, posting, reconciliation",
 target_customer="Companies in Colombia/LATAM ('Live in & Trusted by 3.5k+ companies')",
 customer_purchases="Invoices processed, classified, reconciled and posted into the ERP, with only exceptions surfaced for human review",
 ai_workflow=[
  {"step":"Invoice intake","description":"'Pulls invoices straight from the tax authority and email automatically, as they arrive.'","execution_mode":"ai","evidence_url":"https://cifrato.ai"},
  {"step":"Classification & posting","description":"'Classifies and posts each document against the right accounts, taxes, and cost centers.'","execution_mode":"ai","evidence_url":"https://cifrato.ai"},
  {"step":"Reconciliation","description":"Agents 'process invoices, reconcile, and keep you compliant.'","execution_mode":"ai","evidence_url":"https://cifrato.ai"},
  {"step":"Exception approval","description":"'Only the entries that genuinely need a human decision are surfaced for your review.'","execution_mode":"human","evidence_url":"https://cifrato.ai"},
  {"step":"ERP sync","description":"'Posts the finished entries straight into the ERP your team already runs.'","execution_mode":"ai","evidence_url":"https://cifrato.ai"},
 ],
 human_involvement="AI-led execution with exception-based human review",
 business_model="Not publicly disclosed; sold on processing volume and time per invoice",
 publicly_reported_metrics=["Live in and trusted by 3.5k+ companies","Processed money equal to a stated % of Colombia's GDP","Avg time per invoice processed vs 360 sec without Cifrato"],
 strength_of_evidence="medium",
 limitations=["The published metrics are rendered as animated counters and were not captured as final values","Pricing not published","Regional focus (Colombia) limits generalisation"],
 sources=["https://cifrato.ai","https://www.ycombinator.com/companies/cifrato"],
 last_verified="2026-10-28")

json.dump(D,open('data/part2.json','w'),indent=1)
print("part2:",len(D))
