import puppeteer from 'puppeteer-core';

const URL = process.argv[2] || 'http://127.0.0.1:12000/index.html';
const OUT = process.argv[3] || 'shots';
const VIEWS = ['overview','directory','spectrum','compare','insights','method'];

const browser = await puppeteer.launch({
  executablePath: '/usr/bin/chromium',
  args: ['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--hide-scrollbars'],
  headless: true,
  defaultViewport: { width: 1440, height: 1000 }
});
const page = await browser.newPage();

const problems = [];
const logs = [];
page.on('console', m => { if (m.type()==='error') logs.push('CONSOLE ERROR: '+m.text()); });
page.on('pageerror', e => logs.push('PAGE ERROR: '+e.message));

await page.goto(URL, { waitUntil: 'networkidle2', timeout: 30000 });
await new Promise(r=>setTimeout(r,600));

// ---------- helpers evaluated in page ----------
const measure = async () => await page.evaluate(() => {
  const out = { overflowX: document.documentElement.scrollWidth > window.innerWidth + 1,
                scrollW: document.documentElement.scrollWidth, innerW: window.innerWidth,
                offenders: [], tinyText: [], lowContrast: [], emptyImgs: [], clipped: [] };
  // horizontal overflow offenders
  document.querySelectorAll('*').forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return;
    if (r.right > window.innerWidth + 1) {
      out.offenders.push({ sel: el.tagName.toLowerCase()+(el.className?'.'+String(el.className).split(' ')[0]:''), right: Math.round(r.right), w: Math.round(r.width) });
    }
  });
  // text under 12px
  document.querySelectorAll('body *').forEach(el => {
    if (!el.textContent || !el.textContent.trim()) return;
    if (el.children.length) return;
    const fs = parseFloat(getComputedStyle(el).fontSize);
    if (fs < 11.5) out.tinyText.push({ t: el.textContent.trim().slice(0,40), fs });
  });
  // broken images
  document.querySelectorAll('img').forEach(im => {
    if (im.complete && im.naturalWidth === 0) out.emptyImgs.push(im.src.slice(0,80));
  });
  return out;
});

const reports = {};
for (const v of VIEWS) {
  await page.evaluate((vv) => {
    document.querySelectorAll('.nav-item[data-v]').forEach(b => { if (b.dataset.v===vv) b.click(); });
  }, v);
  await new Promise(r=>setTimeout(r,500));
  reports[v] = await measure();
  await page.screenshot({ path: `${OUT}/${v}.png`, fullPage: true });
}

// side peek
await page.evaluate(() => {
  document.querySelectorAll('.nav-item[data-v]').forEach(b => { if (b.dataset.v==='directory') b.click(); });
});
await new Promise(r=>setTimeout(r,400));
await page.evaluate(() => { const c=document.querySelector('[data-n]'); if(c) c.click(); });
await new Promise(r=>setTimeout(r,500));
reports.peek = await measure();
await page.screenshot({ path: `${OUT}/peek.png`, fullPage: false });

console.log(JSON.stringify({ logs, reports }, null, 1));
await browser.close();
