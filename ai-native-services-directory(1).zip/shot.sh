#!/bin/bash
# Headless screenshot of a URL. Chromium needs --no-sandbox here (no user namespaces).
URL="$1"; OUT="$2"; W="${3:-1440}"; H="${4:-1000}"
chromium --headless --no-sandbox --disable-dev-shm-usage --disable-gpu \
  --hide-scrollbars --force-device-scale-factor=1 \
  --window-size=${W},${H} --screenshot="$OUT" "$URL" 2>/dev/null
