import puppeteer from 'puppeteer-core';
const b=await puppeteer.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--hide-scrollbars'],headless:true});
const p=await b.newPage();
const errs=[];p.on('pageerror',e=>errs.push(e.message));
const VIEWS=['overview','directory','spectrum','compare','insights','method'];

for(const {w,h,n} of [{w:1440,h:900,n:'desktop'},{w:768,h:1000,n:'tablet'},{w:390,h:844,n:'mobile'}]){
  await p.setViewport({width:w,height:h});
  await p.goto('http://127.0.0.1:12000/index.html',{waitUntil:'networkidle2'});
  await new Promise(r=>setTimeout(r,500));
  for(const v of VIEWS){
    await p.evaluate(vv=>{document.querySelectorAll('.nav-item[data-v]').forEach(b=>{if(b.dataset.v===vv)b.click()})},v);
    await new Promise(r=>setTimeout(r,350));
    const r=await p.evaluate(()=>{
      const out={hOver:document.documentElement.scrollWidth-window.innerWidth,tiny:[],overlap:0};
      // interactive elements smaller than 24px in either dimension
      document.querySelectorAll('.view.on button,.view.on a,.view.on th[role=button],.view.on tr[role=button]').forEach(el=>{
        const b=el.getBoundingClientRect();
        if(b.width>0&&(b.width<24||b.height<24)) out.tiny.push({cls:String(el.className).slice(0,20),w:Math.round(b.width),h:Math.round(b.height)});
      });
      // sidebar must not overlap content when closed
      const sb=document.querySelector('.sidebar').getBoundingClientRect();
      out.sbX=Math.round(sb.x);
      return out;
    });
    const flag = r.hOver>0 ? `HOVER+${r.hOver}` : '';
    const tiny = r.tiny.length ? `${r.tiny.length} tiny(${r.tiny.map(t=>t.w+'x'+t.h).join(',')})` : '';
    if(flag||tiny) console.log(`${n}/${v}: ${flag} ${tiny}`);
  }
}

// mobile peek full width
await p.setViewport({width:390,height:844});
await p.goto('http://127.0.0.1:12000/index.html',{waitUntil:'networkidle2'});
await new Promise(r=>setTimeout(r,500));
await p.evaluate(()=>{document.querySelectorAll('.nav-item[data-v]').forEach(x=>{if(x.dataset.v==='directory')x.click()})});
await new Promise(r=>setTimeout(r,500));
await p.evaluate(()=>document.querySelector('.gcard').click());
await new Promise(r=>setTimeout(r,500));
console.log('mobile peek width:',await p.evaluate(()=>Math.round(document.querySelector('#peek').getBoundingClientRect().width)),'vw:',390);
console.log('mobile peek close btn:',await p.evaluate(()=>{const b=document.querySelector('#peekClose').getBoundingClientRect();return Math.round(b.width)+'x'+Math.round(b.height)}));
await p.screenshot({path:'shots/mobile-peek.png'});
console.log('ERRORS:',errs.length?errs:'none');
await b.close();
