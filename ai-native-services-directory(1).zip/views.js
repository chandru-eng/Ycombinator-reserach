/* ==========================================================================
   Views: spectrum board, comparison matrix, insights, method & coverage.
   Depends on app.js (window.__DATA and shared helpers).
   ========================================================================== */
(function () {
  'use strict';

  var DATA = window.__DATA || [];
  var BANDS = window.__BANDS;
  var CLS = window.__CLS;
  var EV = window.__EV;
  var EVT = window.__EVT;
  var esc = window.__esc;
  var tag = window.__tag;
  var clsTag = window.__clsTag;
  var bandTag = window.__bandTag;
  var evTag = window.__evTag;
  var band = window.__band;
  var countBy = window.__countBy;
  var openPeek = window.__openPeek;

  function el(id) { return document.getElementById(id); }

  /* ====================== HORIZONTAL ======================
     Mirrors the Directory view: gallery/table toggle, search, sort,
     quick filters and a side peek. Data comes from window.HORIZONTAL. */
  var HZ = window.HORIZONTAL || [];

  var HZ_TIERS = [
    { k: 'AI transformation', t: 'AI transformation firm',
      d: 'Takes over the strategy and build work itself — the consulting and systems-integration layer, but AI-native.' },
    { k: 'AI coworkers', t: 'AI coworkers you assemble',
      d: 'Gives you AI workers plus the tools to direct them. Service-shaped, but you still configure the work.' },
    { k: 'AI employees', t: 'AI employee for a function',
      d: 'Sells a specific job done for you — sales, accounting, support, design, documentation — in any industry.' }
  ];
  var HZ_TIER_ORDER = { 'AI transformation': 0, 'AI coworkers': 1, 'AI employees': 2 };
  function hzTier(k) { for (var i = 0; i < HZ_TIERS.length; i++) if (HZ_TIERS[i].k === k) return HZ_TIERS[i]; return null; }
  function hzTagClass(k) { return 'hz-t' + (HZ_TIER_ORDER[k] || 0); }

  var hstate = { q: '', layout: 'gallery', sort: 'tier', chips: {}, tier: '' };

  var HZ_CHIPS = [
    ['AI transformation', function (c) { return c.horizontality_tier === 'AI transformation'; }],
    ['AI coworkers', function (c) { return c.horizontality_tier === 'AI coworkers'; }],
    ['AI employees', function (c) { return c.horizontality_tier === 'AI employees'; }],
    ['Sells a role done for you', function (c) { return /employee|workforce|teammate|worker|firm|partner|agency/i.test(c.service_delivered + c.traditional_service_replaced); }],
    ['Says "any industry"', function (c) { return /any |every |across |beyond/i.test(c.why_horizontal + ' ' + c.evidence_quote); }],
    ['Named as agency replacement', function (c) { return /agenc|consult|retainer|McKinsey|outsourc/i.test(c.service_delivered + c.traditional_service_replaced); }],
    ['Sales or marketing function', function (c) { return /sales|SDR|BDR|marketing|growth|creative|design/i.test(c.service_delivered + c.traditional_service_replaced); }],
    ['Finance or accounting function', function (c) { return /financ|account|billing|AP\/AR|bookkeep/i.test(c.service_delivered + c.traditional_service_replaced); }],
    ['Support or CX function', function (c) { return /support|care|CX|customer/i.test(c.service_delivered + c.traditional_service_replaced); }]
  ];

  var HZ_SORTS = [
    ['tier', 'Breadth (transformation → employees)'],
    ['name', 'Company name (A–Z)'],
    ['batch', 'Newest batch first'],
    ['team', 'Team size (largest first)']
  ];

  function hzPasses(c) {
    if (hstate.q) {
      var hay = [c.company_name, c.service_delivered, c.traditional_service_replaced,
                 c.why_horizontal, c.evidence_quote, c.evidence_quote_2 || '',
                 c.yc_one_liner || '', c.horizontality_tier].join(' ').toLowerCase();
      if (hay.indexOf(hstate.q.toLowerCase()) === -1) return false;
    }
    if (hstate.tier && c.horizontality_tier !== hstate.tier) return false;
    for (var i = 0; i < HZ_CHIPS.length; i++) {
      var n = HZ_CHIPS[i][0];
      if (hstate.chips[n] && !HZ_CHIPS[i][1](c)) return false;
    }
    return true;
  }

  function hzBatchKey(b) {
    if (!b) return 0;
    var m = /(\w+)\s+(\d{4})/.exec(b);
    if (!m) return 0;
    var season = { Winter: 0, Spring: 1, Summer: 2, Fall: 3 }[m[1]];
    return (+m[2]) * 10 + (season === undefined ? 0 : season);
  }

  function hzSorted() {
    var rows = HZ.filter(hzPasses);
    rows.sort(function (a, b) {
      if (hstate.sort === 'name') return a.company_name.localeCompare(b.company_name);
      if (hstate.sort === 'batch') return hzBatchKey(b.yc_batch) - hzBatchKey(a.yc_batch);
      if (hstate.sort === 'team') return (b.team_size || 0) - (a.team_size || 0) || a.company_name.localeCompare(b.company_name);
      return (HZ_TIER_ORDER[a.horizontality_tier] - HZ_TIER_ORDER[b.horizontality_tier]) ||
             a.company_name.localeCompare(b.company_name);
    });
    return rows;
  }

  function hzInitials(n) { return (n || '?').slice(0, 1).toUpperCase(); }

  function hzRenderPills() {
    var out = [];
    if (hstate.q) out.push(['Search', hstate.q, function () { hstate.q = ''; el('hq').value = ''; }]);
    if (hstate.tier) out.push(['Type', hstate.tier, function () { hstate.tier = ''; }]);
    HZ_CHIPS.forEach(function (d) {
      if (hstate.chips[d[0]]) out.push(['Filter', d[0], function () { delete hstate.chips[d[0]]; }]);
    });
    var host = el('hpills');
    if (!host) return;
    host.innerHTML = out.map(function (p, i) {
      return '<span class="pill"><span class="k">' + esc(p[0]) + '</span><b>' + esc(p[1]) + '</b>' +
             '<button data-p="' + i + '">✕</button></span>';
    }).join('') + (out.length > 1 ? '<button class="pill-clear" id="hzClear">Clear all</button>' : '');
    host.querySelectorAll('.pill button').forEach(function (b) {
      b.onclick = function () { out[+b.dataset.p][2](); hzRender(); };
    });
    var pc = el('hzClear');
    if (pc) pc.onclick = function () { hstate.q = ''; hstate.tier = ''; hstate.chips = {}; el('hq').value = ''; hzRender(); };
  }

  function hzRenderChips() {
    var row = el('hchipRow');
    if (!row) return;
    row.innerHTML = HZ_CHIPS.map(function (d) {
      return '<button class="tag ' + (hstate.chips[d[0]] ? 't-blue' : 'outline') + '" data-chip="' + esc(d[0]) +
             '" style="margin:0 5px 5px 0;cursor:pointer">' + esc(d[0]) + '</button>';
    }).join('');
    row.querySelectorAll('[data-chip]').forEach(function (b) {
      b.onclick = function () {
        var n = b.dataset.chip;
        if (hstate.chips[n]) delete hstate.chips[n]; else hstate.chips[n] = true;
        hzRender();
      };
    });
  }

  function hzRenderSortMenu() {
    var m = el('hSortMenu');
    if (!m) return;
    m.innerHTML = HZ_SORTS.map(function (s) {
      return '<button class="nav-item' + (hstate.sort === s[0] ? ' on' : '') + '" data-s="' + s[0] +
        '" style="font-size:13px;padding:4px 8px">' + esc(s[1]) +
        (hstate.sort === s[0] ? '<span class="n">✓</span>' : '') + '</button>';
    }).join('');
    m.querySelectorAll('[data-s]').forEach(function (b) {
      b.onclick = function () { hstate.sort = b.dataset.s; m.style.display = 'none'; hzRender(); };
    });
  }

  function hzRenderBody() {
    var rows = hzSorted();
    var body = el('hBody');
    var cnt = el('hcnt');
    if (cnt) cnt.textContent = rows.length + ' of ' + HZ.length;
    if (!body) return;

    if (!rows.length) {
      body.innerHTML = '<div class="empty">No companies match these filters.</div>';
      return;
    }

    if (hstate.layout === 'gallery') {
      body.innerHTML = '<div class="gallery">' + rows.map(function (c) {
        var logo = c.logo
          ? '<img src="' + esc(c.logo) + '" alt="" loading="lazy">'
          : '<div class="ph">' + esc(hzInitials(c.company_name)) + '</div>';
        return '<button class="gcard" data-h="' + esc(c.company_name) + '">' +
          '<div class="gcard-top">' + logo +
            '<div><h3>' + esc(c.company_name) + '</h3>' +
            '<div style="font-size:12px;color:var(--ink-3);margin-top:3px">' + esc(c.yc_batch || '') +
              (c.team_size ? ' · ' + esc(String(c.team_size)) + ' people' : '') + '</div></div>' +
          '</div>' +
          '<div class="one">' + esc(c.service_delivered) + '</div>' +
          '<div class="tags"><span class="tag ' + hzTagClass(c.horizontality_tier) + '">' +
            esc(c.horizontality_tier) + '</span></div>' +
        '</button>';
      }).join('') + '</div>';
    } else {
      body.innerHTML = '<div class="tablewrap"><table class="db"><thead><tr>' +
        ['Company', 'Batch', 'Type', 'Sells', 'Replaces', 'Why it is horizontal']
          .map(function (h) { return '<th>' + h + '</th>'; }).join('') +
        '</tr></thead><tbody>' + rows.map(function (c) {
          return '<tr data-h="' + esc(c.company_name) + '" tabindex="0" role="button">' +
            '<td class="name">' + esc(c.company_name) + '</td>' +
            '<td class="nowrap">' + esc(c.yc_batch || '') + '</td>' +
            '<td class="nowrap"><span class="tag ' + hzTagClass(c.horizontality_tier) + '">' + esc(c.horizontality_tier) + '</span></td>' +
            '<td class="tight">' + esc(c.service_delivered) + '</td>' +
            '<td class="tight">' + esc(c.traditional_service_replaced) + '</td>' +
            '<td class="tight">' + esc(c.why_horizontal) + '</td>' +
          '</tr>';
        }).join('') + '</tbody></table></div>';
    }

    body.querySelectorAll('[data-h]').forEach(function (n) {
      n.onclick = function () { window.__openHPeek(n.dataset.h); };
      if (n.tagName === 'TR') n.onkeydown = function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); window.__openHPeek(n.dataset.h); }
      };
    });
  }

  function hzRender() {
    hzRenderPills();
    hzRenderChips();
    hzRenderBody();
    hzRenderSortMenu();
  }

  /* ---------- horizontal side peek ---------- */
  window.__openHPeek = function (name) {
    var c = null;
    for (var i = 0; i < HZ.length; i++) if (HZ[i].company_name === name) { c = HZ[i]; break; }
    if (!c) return;

    el('peekCrumb').innerHTML = '<b>Horizontal</b><span class="sep">/</span>' + esc(c.company_name);

    var tier = hzTier(c.horizontality_tier);
    var quotes = [c.evidence_quote, c.evidence_quote_2].filter(Boolean).map(function (q) {
      return '<blockquote class="hz-q">' + esc(q) + '</blockquote>';
    }).join('');

    /* source_url and website are the same page for every horizontal company, and
       the YC profile is a third URL. Dedupe so the list never repeats a link. */
    var seen = {};
    var srcItems = [];
    [c.source_url, c.website, c.yc_url].forEach(function (u) {
      if (!u || seen[u]) return;
      if (u !== c.yc_url && /ycombinator\.com/.test(u)) return;
      seen[u] = 1;
      var label = u.replace(/^https?:\/\//, '').replace(/\/$/, '');
      srcItems.push('<li><a href="' + esc(u) + '" target="_blank" rel="noopener">' + esc(label) + '</a>' +
        (u === c.yc_url ? ' <span class="ext">YC profile</span>' : '') + '</li>');
    });

    el('peekBody').innerHTML =
      '<div class="peek-icon">' + (c.logo ? '<img src="' + esc(c.logo) + '" alt="" style="width:40px;height:40px;border-radius:4px;object-fit:contain;border:1px solid var(--line)">' : '🏢') + '</div>' +
      '<h1 class="peek-title">' + esc(c.company_name) + '</h1>' +
      (c.yc_one_liner ? '<p class="peek-one">' + esc(c.yc_one_liner) + '</p>' : '') +
      '<div class="peek-tags"><span class="tag ' + hzTagClass(c.horizontality_tier) + '">' +
        esc(c.horizontality_tier) + '</span>' +
        (c.status && c.status !== 'Active' ? '<span class="tag t-red">' + esc(c.status) + '</span>' : '') + '</div>' +
      /* industry is the same constant string for every horizontal company, so the
         meta line shows batch and location only. */
      '<div class="peek-meta">' + esc(c.yc_batch || '') +
        (c.locations ? ' · ' + esc(c.locations) : '') + '</div>' +

      '<h2 class="h2"><span class="chev">▼</span>Properties</h2>' +
      '<dl class="props">' +
        '<dt>Type</dt><dd>' + esc(c.horizontality_tier) + '</dd>' +
        '<dt>What it sells</dt><dd>' + esc(c.service_delivered) + '</dd>' +
        '<dt>Traditional service replaced</dt><dd>' + esc(c.traditional_service_replaced) + '</dd>' +
        '<dt>Why it is horizontal</dt><dd>' + esc(c.why_horizontal) + '</dd>' +
        '<dt>Team size</dt><dd>' + (c.team_size ? esc(String(c.team_size)) + ' people' : 'Not disclosed') + '</dd>' +
        '<dt>Status</dt><dd>' + esc(c.status || 'Unknown') + '</dd>' +
        '<dt>Website</dt><dd><a href="' + esc(c.website) + '" target="_blank" rel="noopener">' +
          esc(c.website.replace(/^https?:\/\//, '').replace(/\/$/, '')) + '</a></dd>' +
      '</dl>' +

      (tier ? '<h2 class="h2"><span class="chev">▼</span>What this type means</h2>' +
        '<p class="sub">' + esc(tier.d) + '</p>' : '') +

      '<h2 class="h2"><span class="chev">▼</span>Evidence from their own site</h2>' +
      '<p class="sub">Verbatim quotes, captured from the company\u2019s own pages.</p>' +
      quotes +

      '<h2 class="h2"><span class="chev">▼</span>Sources</h2>' +
      '<ul class="srcs">' + srcItems.join('') + '</ul>' +
      '<p class="muted" style="font-size:12px;margin-top:14px">Last verified ' + esc(c.last_verified) +
        '. Quotes are company-published claims.</p>';

    el('peek').classList.add('on');
    el('scrim').classList.add('on');
    el('peekBody').scrollTop = 0;
  };

  window.__renderHorizontal = function () {
    hzRender();
    if (el('hq')) el('hq').oninput = function (e) { hstate.q = e.target.value; hzRender(); };
    if (el('hGallery')) el('hGallery').onclick = function () {
      hstate.layout = 'gallery'; el('hGallery').classList.add('on'); el('hTable').classList.remove('on'); hzRenderBody();
    };
    if (el('hTable')) el('hTable').onclick = function () {
      hstate.layout = 'table'; el('hTable').classList.add('on'); el('hGallery').classList.remove('on'); hzRenderBody();
    };
    if (el('hSort')) el('hSort').onclick = function (e) {
      e.stopPropagation();
      var m = el('hSortMenu');
      m.style.display = m.style.display === 'none' ? '' : 'none';
    };
    if (el('hChips')) el('hChips').onclick = function () {
      var r = el('hchipRow');
      r.style.display = r.style.display === 'none' ? '' : 'none';
      el('hChips').classList.toggle('on', r.style.display !== 'none');
    };
    /* Close the sort menu on any outside click. Registered once, since
       __renderHorizontal runs on every navigation. */
    if (!window.__hzClickWired) {
      window.__hzClickWired = true;
      document.addEventListener('click', function () {
        var m = el('hSortMenu'); if (m) m.style.display = 'none';
      });
    }
  };

  /* ====================== SPECTRUM ====================== */
  window.__renderSpectrum = function () {
    el('board').innerHTML = BANDS.map(function (b) {
      var list = DATA.filter(function (c) { return band(c) === b.k; })
        .sort(function (a, x) { return (x.autonomy_score || 0) - (a.autonomy_score || 0); });
      return '<div class="bcol">' +
        '<div class="bcol-head"><div class="t"><span class="dot" style="background:' + b.c + ';margin-right:6px"></span>' + esc(b.t) + '</div>' +
        '<div class="c">' + esc(b.d) + '</div></div>' +
        (list.length ? list.map(function (c) {
          return '<button class="bcard" data-n="' + esc(c.company_name) + '">' +
            '<div class="n">' + esc(c.company_name) + '</div>' +
            '<div class="b">' + esc(c.yc_batch) + '</div></button>';
        }).join('') : '<div style="font-size:12px;color:var(--ink-3);padding:4px 2px">—</div>') +
      '</div>';
    }).join('');
    el('board').querySelectorAll('[data-n]').forEach(function (n) {
      n.onclick = function () { openPeek(n.dataset.n); };
    });

    var counts = { ai: 0, human: 0, hybrid: 0 };
    DATA.forEach(function (c) {
      (c.ai_workflow || []).forEach(function (s) { if (counts[s.execution_mode] !== undefined) counts[s.execution_mode]++; });
    });
    var tot = counts.ai + counts.human + counts.hybrid || 1;
    var rows = [
      ['AI-executed steps', 'ai', '#448361'],
      ['Human steps', 'human', '#cb912f'],
      ['Hybrid steps', 'hybrid', '#2383e2']
    ];
    el('bars').innerHTML = rows.map(function (r) {
      var pct = Math.round(counts[r[1]] / tot * 100);
      return '<div class="barrow"><div class="barhead"><span>' + r[0] + '</span>' +
        '<span class="v">' + counts[r[1]] + ' · ' + pct + '%</span></div>' +
        '<div class="bartrack"><div class="barfill" style="width:' + pct + '%;background:' + r[2] + '"></div></div></div>';
    }).join('');
  };

  /* ====================== COMPARE ====================== */
  var COLS = [
    ['Company', function (c) { return '<span style="color:var(--ink);font-weight:500">' + esc(c.company_name) + '</span>'; }],
    ['Batch', function (c) { return esc(c.yc_batch); }],
    ['Traditional service replaced', function (c) { return esc(c.traditional_service_replaced); }],
    ['Work automated', function (c) {
      var w = c.ai_workflow || [];
      if (!w.length) return '<span class="muted">Not disclosed</span>';
      var a = w.filter(function (s) { return s.execution_mode === 'ai'; }).length;
      return a + ' / ' + w.length + ' steps';
    }],
    ['Human involvement', function (c) { return bandTag(c); }],
    ['AI execution type', function (c) {
      var w = c.ai_workflow || [], s = {};
      w.forEach(function (x) { s[x.execution_mode] = 1; });
      var k = Object.keys(s);
      return k.length ? k.map(function (x) { return tag(x, x === 'ai' ? 'green' : x === 'human' ? 'yellow' : 'blue'); }).join(' ') : '<span class="muted">—</span>';
    }],
    ['Customer deliverable', function (c) { return esc(c.customer_purchases); }],
    ['Pricing / revenue model', function (c) { return esc(c.business_model); }],
    ['Regulatory oversight', function (c) {
      var t = c.traditional_service_replaced + c.service_category + (c.limitations || []).join(' ');
      return /licens|regulat|FDCPA|TCPA|HIPAA|attorney|physician|payer|compliance|Chambers|SOC 2/i.test(t)
        ? tag('Named', 'orange') : '<span class="muted">Not stated</span>';
    }],
    ['Deployment evidence', function (c) {
      var n = (c.publicly_reported_metrics || []).length;
      return n ? n + ' metric' + (n > 1 ? 's' : '') : '<span class="muted">None</span>';
    }],
    ['Evidence', function (c) { return evTag(c); }]
  ];

  var csort = { i: 0, dir: 1 };
  window.__renderCompare = function () {
    var evo = { high: 3, medium: 2, low: 1 };
    el('cmp').querySelector('thead').innerHTML = '<tr>' + COLS.map(function (col, i) {
      return '<th data-i="' + i + '" tabindex="0" role="button" aria-sort="' +
        (csort.i === i ? (csort.dir > 0 ? 'ascending' : 'descending') : 'none') + '">' + esc(col[0]) +
        (csort.i === i ? '<span class="sort">' + (csort.dir > 0 ? '▲' : '▼') + '</span>' : '') + '</th>';
    }).join('') + '</tr>';

    var rows = DATA.slice().sort(function (a, b) {
      if (csort.i === 4) return csort.dir * ((a.autonomy_score || 0) - (b.autonomy_score || 0));
      if (csort.i === 10) return csort.dir * ((evo[a.strength_of_evidence] || 0) - (evo[b.strength_of_evidence] || 0));
      if (csort.i === 0) return csort.dir * a.company_name.localeCompare(b.company_name);
      if (csort.i === 1) return csort.dir * (window.__batchKey(a.yc_batch) - window.__batchKey(b.yc_batch));
      return 0;
    });

    el('cmp').querySelector('tbody').innerHTML = rows.map(function (c) {
      return '<tr data-n="' + esc(c.company_name) + '" tabindex="0" role="button">' +
        COLS.map(function (col) { return '<td>' + col[1](c) + '</td>'; }).join('') + '</tr>';
    }).join('');

    el('cmp').querySelectorAll('th').forEach(function (th) {
      function sort() {
        var i = +th.dataset.i;
        csort.dir = (csort.i === i) ? -csort.dir : 1;
        csort.i = i;
        window.__renderCompare();
      }
      th.onclick = sort;
      th.onkeydown = function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); sort(); }
      };
    });
    el('cmp').querySelectorAll('tr[data-n]').forEach(function (tr) {
      tr.onclick = function () { openPeek(tr.dataset.n); };
      tr.onkeydown = function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPeek(tr.dataset.n); }
      };
    });
  };

  /* ====================== INSIGHTS ====================== */
  window.__renderInsights = function () {
    var n = DATA.length;
    var indCount = countBy(DATA, function (c) { return c.industry; });
    var topInds = Object.keys(indCount).sort(function (a, b) { return indCount[b] - indCount[a]; });
    var ai = 0, hu = 0, hy = 0;
    DATA.forEach(function (c) {
      (c.ai_workflow || []).forEach(function (s) {
        if (s.execution_mode === 'ai') ai++; else if (s.execution_mode === 'human') hu++; else hy++;
      });
    });
    var tot = ai + hu + hy || 1;
    var pct = function (x) { return Math.round(x / tot * 100); };
    var hi = DATA.filter(function (c) { return c.strength_of_evidence === 'high'; }).length;
    var lo = DATA.filter(function (c) { return c.strength_of_evidence === 'low'; }).length;
    var auto = DATA.filter(function (c) { return band(c) === 'autonomous'; });

    el('insights').innerHTML =
    '<h3>What the evidence shows</h3>' +
    '<p>Findings below are drawn from the researched companies\u2019 own published material (' + n + ' companies). They describe this sample, not the ecosystem as a whole.</p>' +
    '<ul>' +
      '<li><strong>Insurance back office is the most mature vertical.</strong> Strada, Velos and Veltha all describe agents executing work previously sent to a BPO or done by adjusters, and they publish measured numbers — Strada reports a 70% handle-time reduction and 98% data accuracy; Velos reports 98% accuracy, 6 days faster reporting and 0 added headcount. This matches YC\u2019s named interest in insurance brokerage.</li>' +
      '<li><strong>Accounting has the clearest outcome-priced model.</strong> Balance states flat monthly pricing with a named accountant signing off; Rational publishes a $399/month entry point. The recurring shape is <em>agents do the work, a licensed human signs it</em>.</li>' +
      '<li><strong>Legal splits in two.</strong> One group runs the firm\u2019s operations (Praxis, Erinys, Relaw); another <em>is</em> the firm (General Legal, Vector Legal, Moritz, Wingman Law). Only the first group publishes a workflow; the second publishes attorney credentials and turnaround claims.</li>' +
      '<li><strong>Healthcare administration is the largest cluster and the most supervised.</strong> Taiga requires physician approval of generated codes; Arctic Health reviews every application with a specialist. Autonomy here is bounded by licensure rather than capability.</li>' +
      '<li><strong>Per step, humans are still heavy.</strong> Across ' + n + ' companies, ' + ai + ' of ' + tot + ' documented workflow steps (' + pct(ai) + '%) are AI-executed, ' + hu + ' (' + pct(hu) + '%) are human and ' + hy + ' (' + pct(hy) + '%) are hybrid. Even in companies that call themselves AI-native, human steps are documented at the approval, sign-off and escalation points.</li>' +
    '</ul>' +

    '<h3>What distinguishes an AI-native service from a copilot</h3>' +
    '<ul>' +
      '<li><strong>Pricing is per outcome, not per seat.</strong> AgentCollect sells recovered receivables; LinkLane sells booked freight; Atlia charges a flat 10% of rental revenue; Health Harbor charges per call by complexity. By contrast Dock publishes $20–$100 <em>per person per month</em> — a software model, and the reason it is classified as a tool.</li>' +
      '<li><strong>The deliverable is a finished artefact.</strong> A reviewed claim file (Veltha), a signed-off set of books (Balance), a submitted payer application (Arctic Health), a booked load (LinkLane).</li>' +
      '<li><strong>Humans move to the boundary.</strong> The recurring human step is approval, sign-off, escalation or dispute routing — not production. Strada is explicit: escalation thresholds the team defines, and handover passes the whole transcript.</li>' +
      '<li><strong>Exception handling is a designed feature.</strong> Health Harbor offers two modes; Humoniq lets the airline choose a service model; Zomma\u2019s agents "only recommend". The interface between AI and human is part of the product, not a gap in it.</li>' +
    '</ul>' +

    '<h3>Operational, regulatory and trust constraints</h3>' +
    '<ul>' +
      '<li><strong>Licensure is the binding constraint in insurance, law and healthcare.</strong> RiskCube pairs AI agents with licensed brokers; Veltha drafts a decision "for your adjuster to approve"; Taiga routes codes to physicians. The AI does not sign.</li>' +
      '<li><strong>Metrics are self-reported.</strong> Of ' + n + ' companies, ' + hi + ' have high-confidence evidence and ' + lo + ' have low. No company publishes an audited automation rate, and several headline figures ("10x more candidates", "12x ROI") have no published methodology.</li>' +
      '<li><strong>Autonomy claims are rare and thin.</strong> Only ' + auto.length + ' companies make an explicit no-human-handoff claim (' + auto.map(function (c) { return c.company_name; }).join(', ') + '), and both are early-stage without published deployment metrics.</li>' +
      '<li><strong>Data access is the hidden dependency.</strong> These companies succeed by reaching where humans already work — EHRs (Beacon, Taiga), carrier portals (Strada, Velos), the customer\u2019s AMS (Covera), tax-authority feeds (Cifrato). The integration, not the model, is the moat.</li>' +
    '</ul>' +

    '<h3>Clearest evidence of genuine AI-native delivery</h3>' +
    '<p>Ranked on documented workflow plus published outcome metrics, the strongest cases are <strong>Strada</strong>, <strong>Velos</strong>, <strong>Balance</strong>, <strong>Health Harbor</strong>, <strong>Atlia</strong> and <strong>AgentCollect</strong>. Each describes the steps, names the execution mode, and publishes numbers tied to a live deployment.</p>' +
    '<p>Weakest, and labelled as such throughout: <strong>Bear</strong>, <strong>Sintropix</strong>, <strong>Rex</strong>, <strong>Autotab</strong>, <strong>Moritz</strong> and <strong>Erinys</strong>. These carry an AI-native label but publish no workflow, no pricing and no outcome evidence.</p>' +

    '<h3>Underserved areas visible in this sample</h3>' +
    '<ul>' +
      '<li><strong>Tax preparation at consumer scale.</strong> YC names accounting, tax and audit; the workspace has strong accounting coverage, but only ClaimKit, Magnetic, Cifrato and Keeper sit near tax filing, and none documents an end-to-end autonomous return.</li>' +
      '<li><strong>Audit.</strong> Named by YC, effectively absent from this sample as an AI-native service.</li>' +
      '<li><strong>Compliance for non-tech regulated industries.</strong> Agency and SafetyKit serve tech and platforms; there is little evidence of AI-native compliance operations for, say, healthcare providers or financial advisers.</li>' +
      '<li><strong>Outcome-priced legal work.</strong> Vector Legal mentions outcome-based pricing "where it fits"; no company in the sample publishes a fully outcome-priced legal service.</li>' +
    '</ul>' +
    '<p class="muted" style="font-size:13px"><strong>Hypotheses, clearly labelled:</strong> the clustering above reflects a ' + n + '-company researched sample drawn from a 6,349-company directory, not a census. Absence here is a signal for further research, not proof of absence in the ecosystem.</p>';
  };

  /* ====================== METHOD ====================== */
  window.__renderMethod = function () {
    var n = DATA.length;
    var nat = DATA.filter(function (c) { return c.classification === 'ai_native_service'; }).length;
    el('method').innerHTML =
    '<h3>How the directory was explored</h3>' +
    '<p>The YC company directory at <code>ycombinator.com/companies</code> is a client-rendered React page backed by a public Algolia search index. The page ships the application ID and its public search-only key in its own HTML, so the directory can be queried exactly as the page queries it — no authentication bypass and no circumvention of any anti-bot control. The index reports <strong>6,349</strong> companies.</p>' +
    '<p>Algolia caps a single query at 1,000 hits, so the full directory was retrieved by partitioning on the <code>batch</code> facet (52 values) and paging within each slice. Every company record was stored with name, batch, website, one-liner, long description, industries, tags, location, team size and status.</p>' +

    '<h3>Counts</h3>' +
    '<div class="stats">' +
      '<div class="stat"><div class="n">6,349</div><div class="l">Screened — all public records</div></div>' +
      '<div class="stat"><div class="n">1,589</div><div class="l">Keyword candidates</div></div>' +
      '<div class="stat"><div class="n">77</div><div class="l">Shortlisted</div></div>' +
      '<div class="stat"><div class="n">' + n + '</div><div class="l">Fully investigated</div></div>' +
    '</div>' +
    '<p class="sub">Of the ' + n + ' fully investigated, ' + nat + ' are classified AI-native service providers. The remainder are AI-enabled services, copilots or tools, and hybrid cases, retained as comparison points.</p>' +

    '<h3>Method per company</h3>' +
    '<ul>' +
      '<li>Fetched the company\u2019s own website plus common sub-pages: pricing, how-it-works, about, product, FAQ, security, customers and case studies.</li>' +
      '<li>Fetched the YC company profile for batch, industry tags, team size and location.</li>' +
      '<li>Extracted the sentences that mention AI, human involvement and pricing, then read them in context.</li>' +
      '<li>Recorded each workflow step with an explicit execution mode (<code>ai</code>, <code>human</code>, <code>hybrid</code>) and the URL that supports it.</li>' +
      '<li>Assigned an evidence grade: <strong>high</strong> where the company describes its workflow <em>and</em> publishes deployment metrics; <strong>medium</strong> where only one of the two is present; <strong>low</strong> where the classification rests on positioning alone.</li>' +
    '</ul>' +

    '<h3>Classification rules</h3>' +
    '<ul>' +
      '<li><strong>AI-native service</strong> — the company performs substantial parts of the service and the customer buys a completed outcome or managed service.</li>' +
      '<li><strong>AI-enabled service</strong> — the company sells a service, but humans still deliver it with AI as productivity leverage.</li>' +
      '<li><strong>Copilot or tool</strong> — the customer operates the software and remains responsible for the work.</li>' +
      '<li><strong>Hybrid / unclear</strong> — the evidence does not establish a primary model.</li>' +
    '</ul>' +
    '<p>A company was <em>not</em> classified AI-native merely for mentioning agents, LLMs or automation. Where a company adopts the label but publishes no workflow, it stays in the dataset with a low evidence grade and an explicit note of what is missing, rather than being dropped.</p>' +

    '<h3>Deduplication</h3>' +
    '<p>Companies appear in multiple batches, industries and tags. Records were deduplicated on the Algolia <code>objectID</code> during discovery, and on company name when merging the researched dataset. YC <code>former_names</code> were checked for the researched companies.</p>' +

    '<h3>Known gaps and access limitations</h3>' +
    '<ul>' +
      '<li>Algolia returns at most 1,000 hits per query, so partitioning by batch was required. Companies whose batch facet is <code>Unspecified</code> or <code>other</code> are still covered, because those facets were queried too.</li>' +
      '<li>Several sites are JavaScript-only or block automated fetching. Bear, Sage Care, Magnetic and Derya returned no usable body text; they are included with low evidence where a YC listing exists, and flagged accordingly.</li>' +
      '<li>Some companies returned HTTP 404 for sub-pages, so pricing could not always be captured even where a pricing page is known to exist. Those cases are noted in <em>limitations</em> rather than filled with a guess.</li>' +
      '<li>Pricing is under-reported across the ecosystem: most companies do not publish amounts, so business-model entries describe structure (fee, commission, subscription) rather than figures.</li>' +
      '<li>No third-party verification was performed. All metrics are the company\u2019s own published claims and are labelled as such.</li>' +
    '</ul>' +

    '<h3>Sources and date of verification</h3>' +
    '<p>Primary sources are the YC company directory and each company\u2019s own website. Every company record lists its source URLs and verification date. All records were last verified <strong>28 October 2026</strong>.</p>' +
    '<p class="muted" style="font-size:13px">Coverage is not claimed to be exhaustive. The ' + n + ' researched companies are those where the public evidence was sufficient to classify the delivery model. The broader candidate pool is documented above so the screening can be re-run and extended.</p>';
  };
})();
