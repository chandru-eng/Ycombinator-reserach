# AI-Native Service Companies in the Y Combinator Ecosystem

Research dataset and analysis. Generated 2026-10-28. All metrics are company-published claims.

**Framework (from the YC RFS essay by Gustaf Alströmer):** Traditional Service → SaaS Software → AI Copilot → **AI-Native Service**.

## Coverage

| Metric | Count |
|---|---|
| YC companies screened | 6,349 |
| Keyword candidates | 1,589 |
| Shortlisted for review | 77 |
| Fully investigated and classified | 53 |
| — ai_native_service | 43 |
| — hybrid | 4 |
| — ai_enabled_service | 3 |
| — ai_copilot_or_tool | 3 |

## Deliverable A — Company directory

| Company | Batch | Industry | Classification | Delivery band | Evidence | Website |
|---|---|---|---|---|---|---|
| Beacon Health | Winter 2026 | Healthcare | ai_native_service | Predominantly Autonomous | medium | https://www.beaconhealth.ai/ |
| Callbook AI | Summer 2026 | Fintech / B2B | ai_native_service | Predominantly Autonomous | medium | https://callbook.ai |
| AgentCollect | Summer 2023 | B2B / Fintech | ai_native_service | AI-Led Service Delivery | high | https://www.agentcollect.com |
| Alder | Fall 2025 | B2B / Fintech | ai_native_service | AI-Led Service Delivery | medium | https://meetalder.com/ |
| Asendia AI | Spring 2026 | B2B / HR | ai_native_service | AI-Led Service Delivery | medium | https://asendia.ai/ |
| Balance | Winter 2026 | Fintech / B2B | ai_native_service | AI-Led Service Delivery | high | https://getbalance.ai |
| Billow AI Labs | Summer 2026 | B2B / Fintech | ai_native_service | AI-Led Service Delivery | medium | https://thebillow.ai/ |
| Cifrato | Winter 2025 | Fintech / B2B | ai_native_service | AI-Led Service Delivery | medium | https://cifrato.ai |
| Covera | Fall 2026 | Insurance | hybrid | AI-Led Service Delivery | medium | https://www.covera-agents.com/ |
| Health Harbor | Summer 2023 | Healthcare | ai_native_service | AI-Led Service Delivery | high | https://healthharbor.co/ |
| Humoniq | Summer 2025 | B2B / Travel | ai_native_service | AI-Led Service Delivery | high | https://humoniq.ai |
| Jarmin | Fall 2025 | B2B | ai_native_service | AI-Led Service Delivery | medium | https://jarmin.ai/ |
| LinkLane | Winter 2027 | Industrials / Logistics | ai_native_service | AI-Led Service Delivery | medium | https://linklane.ai/ |
| MochaCare | Winter 2026 | Healthcare | ai_native_service | AI-Led Service Delivery | medium | https://www.mochacare.com/ |
| Pollen | Winter 2026 | B2B / Fintech | ai_native_service | AI-Led Service Delivery | medium | https://www.pollen.cx/ |
| Praxis | Fall 2026 | Legal | ai_native_service | AI-Led Service Delivery | medium | https://runpraxis.ai |
| RamAIn | Winter 2026 | B2B | ai_native_service | AI-Led Service Delivery | medium | https://ramain.ai |
| Rational | Summer 2026 | Fintech / B2B | ai_native_service | AI-Led Service Delivery | medium | https://rational.to |
| Riviera | Winter 2025 | B2B / Hospitality | ai_native_service | AI-Led Service Delivery | medium | https://www.withriviera.com |
| SafetyKit | Summer 2023 | B2B / Compliance | ai_copilot_or_tool | AI-Assisted | medium | https://www.safetykit.com/ |
| Strada | Summer 2023 | Insurance / B2B | ai_native_service | AI-Led Service Delivery | high | https://www.getstrada.com/ |
| Taiga | Spring 2026 | Healthcare | ai_native_service | AI-Led Service Delivery | high | https://taigabilling.com |
| Velos | Winter 2023 | Insurance / B2B | ai_native_service | AI-Led Service Delivery | high | https://www.tryvelos.com |
| Veltha | Fall 2026 | Insurance | ai_native_service | AI-Led Service Delivery | medium | https://veltha.ai/ |
| Adside.ai | Fall 2026 | B2B / Marketing | hybrid | AI-Executed, Human-Supervised | high | https://adside.ai |
| Agency | Winter 2022 | B2B / Compliance | ai_native_service | AI-Executed, Human-Supervised | medium | https://GetAgency.com |
| Arctic Health | Spring 2026 | Healthcare | ai_native_service | AI-Executed, Human-Supervised | medium | https://arctic.health |
| Atlia | Summer 2026 | Real Estate | ai_native_service | AI-Executed, Human-Supervised | high | https://www.atlia.com |
| Overdrive Health | Winter 2026 | Healthcare | ai_native_service | AI-Executed, Human-Supervised | high | https://overdrive.health |
| Patientdesk.ai | Winter 2026 | Healthcare | hybrid | AI-Executed, Human-Supervised | medium | https://patientdesk.ai/ |
| RiskCube | Fall 2024 | Insurance / Fintech | ai_native_service | AI-Executed, Human-Supervised | medium | https://riskcube.com |
| The Vibe Company | Winter 2024 | B2B | ai_native_service | AI-Executed, Human-Supervised | high | https://thevibecompany.co |
| TrueMile | Fall 2026 | Industrials / Logistics | ai_native_service | AI-Executed, Human-Supervised | low | https://TrueMile.AI/ |
| Zomma | Summer 2026 | B2B / Fintech | ai_native_service | AI-Executed, Human-Supervised | medium | https://zommalabs.com |
| throxy | Spring 2025 | B2B | ai_native_service | AI-Executed, Human-Supervised | medium | https://throxy.com/ |
| Assembly HOA | Summer 2024 | Real Estate | ai_enabled_service | AI-Assisted | medium | https://assemblyhoa.com |
| Dock | Summer 2026 | B2B | ai_copilot_or_tool | AI-Assisted | high | https://trydock.ai |
| Erinys | Summer 2026 | Legal | ai_native_service | AI-Assisted | low | https://erinys.ai |
| Fernstone | Fall 2025 | Insurance | ai_enabled_service | AI-Assisted | medium | https://www.fernstone.com |
| General Legal | Winter 2026 | Legal | ai_native_service | AI-Assisted | medium | https://general.legal |
| Moritz | Winter 2026 | Legal | ai_native_service | AI-Assisted | low | http://moritzlegal.com/ |
| Openroll | Fall 2025 | B2B / HR | ai_native_service | AI-Assisted | medium | https://www.openroll.com |
| Relaw | Fall 2025 | Legal | ai_copilot_or_tool | AI-Assisted | medium | https://www.relaw.ai |
| Superside | Winter 2016 | B2B / Creative | ai_enabled_service | AI-Assisted | high | http://www.superside.com |
| Vector Legal | Winter 2026 | Legal | ai_native_service | AI-Assisted | medium | https://vectorlegal.com |
| Wingman Law | Fall 2026 | Legal | ai_native_service | AI-Assisted | medium | https://www.wingmanlaw.com |
| Allia Health | Summer 2026 | Healthcare | ai_native_service | Insufficient Evidence | medium | https://allia.health/ |
| Altair Health | Fall 2026 | Healthcare | ai_native_service | Insufficient Evidence | low | https://www.altair-health.com |
| Autotab | Summer 2023 | B2B | hybrid | Insufficient Evidence | low | https://autotab.com |
| Bear | Summer 2026 | Fintech / B2B | ai_native_service | Insufficient Evidence | low | https://bear.inc/ |
| PARES AI | Summer 2025 | Real Estate | ai_native_service | Insufficient Evidence | medium | https://www.pares.ai/ |
| Rex | Summer 2026 | B2B | ai_native_service | Insufficient Evidence | low | https://www.ycombinator.com/companies/rex |
| Sintropix | Fall 2026 | Fintech / B2B | ai_native_service | Insufficient Evidence | low | https://sintropix.com/ |

## Deliverable B & C — Deep dives and service delivery workflow maps

### Adside.ai

- **YC batch:** Fall 2026  |  **Industry:** B2B / Marketing  |  **Website:** https://adside.ai
- **Classification:** hybrid  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** high

**1. What the company does.** AI agency for paid ads (self-serve and managed tiers)

**2. Traditional service replaced.** Paid media agency work: market research, strategy, creative production, campaign monitoring, creative rotation

**3. Target customer and what they buy.** Startups and brands running paid ads on Meta, Google, LinkedIn, Reddit and Twitter. Either the agent team operated by the customer, or a fully managed service with a human expert from Adside's network

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Research and strategy** — 'An AI team that researches your market, drafts a strategy'. | `ai` | https://adside.ai |
| 2 | **Creative production** — 'creates static and video ads'; activity feed shows refreshed, resized and bulk-imported creatives. | `ai` | https://adside.ai |
| 3 | **Campaign monitoring and rotation** — 'monitors your accounts, rotates creatives, and much more'. | `ai` | https://adside.ai |
| 4 | **Managed service layer** — 'Managed service - Your AI agency, plus an expert human from our network to manage it'; 'A dedicated expert from our network manages your accounts and agents for you'. | `human` | https://adside.ai/pricing |

**5. Where humans remain involved.** Human-supervised AI execution (managed tier) or human-led with AI assistance (self-serve tier)

**6. How the company makes money.** Two published tiers: AI Agency at $590/month per brand billed annually ($990 monthly), unlimited users, no per-seat pricing; Managed service starting at $3,500/month, or 10% of ad spend with a $3,500 monthly minimum

**7. Evidence — publicly reported metrics.**

- AI Agency: $990/month or $590/month billed annually (40% saving)
- Managed service: from $3,500/month, or 10% of ad spend with a $3,500 minimum
- Unlimited users, no per-seat pricing

**8. What remains unknown.**

- The self-serve tier is software the customer operates, so only the managed tier is a true service
- No published performance outcomes for managed clients
- Very early (Fall 2026)

**Sources.** https://adside.ai, https://adside.ai/pricing, https://www.ycombinator.com/companies/adside-ai  (last verified 2026-10-28)

---

### Agency

- **YC batch:** Winter 2022  |  **Industry:** B2B / Compliance  |  **Website:** https://GetAgency.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** medium

**1. What the company does.** Managed compliance execution service (virtual CISO plus AI products)

**2. Traditional service replaced.** Outsourced security and compliance work: virtual CISO services, compliance management, security engineering, vendor risk, pen testing and audit coordination

**3. Target customer and what they buy.** Companies needing SOC 2, ISO 27001, HIPAA, GDPR, CMMC and similar compliance. 'End-to-end compliance execution' delivered by forward-deployed engineers with AI products, including a virtual CISO and compliance manager

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Control implementation** — Engineers 'operate a proprietary orchestration layer and AI agents to execute control implementation, evidence, monitoring, vendor risk, pen testing, and audit coordination'. | `hybrid` | https://GetAgency.com |
| 2 | **AI product layer** — '13 purpose-built AI products that operate your security and compliance program - from command-and-control orchestration to audit-ready evidence.' | `ai` | https://GetAgency.com |
| 3 | **Forward-deployed engineers** — 'Run end-to-end by U.S.-based forward-deployed compliance engineers, supercharged by proprietary AI that plugs into the tools you already trust.' | `human` | https://GetAgency.com |
| 4 | **Multi-party scope** — Executes across 'BYOD, contractor fleets, and multi-party environments'. | `hybrid` | https://GetAgency.com |

**5. Where humans remain involved.** Human-supervised AI execution (engineers run the program; AI products do the execution work)

**6. How the company makes money.** Managed service with published pricing tiers ('Express Comply Pricing', 'Managed Comply Pricing'); the virtual CISO, compliance manager and security engineering are included in the service

**7. Evidence — publicly reported metrics.**

- 13 purpose-built AI products
- Frameworks operated: SOC 2, ISO 27001, HIPAA, GDPR, CMMC and more
- Virtual CISO, compliance manager and security engineering included in the service

**8. What remains unknown.**

- Pricing amounts were not captured (pricing pages exist)
- 'We do what automation can't' is explicitly a human-value claim
- No published client or audit-outcome metrics

**Sources.** https://GetAgency.com, https://www.ycombinator.com/companies/agency  (last verified 2026-10-28)

---

### AgentCollect

- **YC batch:** Summer 2023  |  **Industry:** B2B / Fintech  |  **Website:** https://www.agentcollect.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** high

**1. What the company does.** AI collections agency (B2B debt collection)

**2. Traditional service replaced.** Third-party B2B debt collection agency or outsourced BPO collections team; and manual in-house AR chasing

**3. Target customer and what they buy.** B2B companies with overdue receivables. Recovered receivables - an AI billing concierge on every customer account that contacts, negotiates and collects

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Account ingestion** — 'Upload a spreadsheet or connect your billing/ERP' - accounts enter the system from the customer's billing stack. | `ai` | https://www.agentcollect.com |
| 2 | **Contact discovery** — 'We find who to contact' - locating the right person at the debtor. | `ai` | https://www.agentcollect.com |
| 3 | **Multichannel outreach** — Voice + email + SMS outreach, with an AI agent answering customers 'the moment they ask'. | `ai` | https://www.agentcollect.com |
| 4 | **Negotiation** — Agents negotiate payment plans ('I can pay, but I need a smaller first installment' - agent presents payment options). | `ai` | https://www.agentcollect.com |
| 5 | **Dispute routing** — 'When a customer disputes, calls on that account stop and the dispute can be routed to your team.' | `human` | https://www.agentcollect.com |
| 6 | **Compliance guardrails** — State-by-state compliance guides for Reg F, FDCPA and TCPA govern the outreach. | `hybrid` | https://www.agentcollect.com |

**5. Where humans remain involved.** AI-led execution with exception-based human review (disputes routed to the client's team)

**6. How the company makes money.** Collections economics - a contingency/commission share of what is recovered, plus a comparison against 'your outsourced agency or BPO'

**7. Evidence — publicly reported metrics.**

- 23M+ borrowers managed
- 2M+ payments recovered
- USD $11M+ recovered
- '15 minutes to finalize the last 10%' of agent setup

**8. What remains unknown.**

- The exact fee/commission percentage is not published
- Whether all negotiation is autonomous or some is agent-assisted is not stated
- Regulatory licensing per state is implied by the compliance content but not enumerated

**Sources.** https://www.agentcollect.com, https://www.agentcollect.com/how-it-works, https://www.agentcollect.com/customers, https://www.ycombinator.com/companies/agentcollect  (last verified 2026-10-28)

---

### Alder

- **YC batch:** Fall 2025  |  **Industry:** B2B / Fintech  |  **Website:** https://meetalder.com/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI employee for accounts receivable

**2. Traditional service replaced.** Accounts receivable work: chasing unpaid invoices, resolving short-pays and missing POs, confirming cash receipt

**3. Target customer and what they buy.** Finance and receivables teams. 'Alder is the AI employee for your receivables team' - the AR chasing and resolution work performed on the customer's behalf

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Invoice chasing** — 'Alder follows up on every overdue invoice with the person who can pay it, remembers when they promised to pay, and checks that the money arrived.' | `ai` | https://meetalder.com/ |
| 2 | **Issue diagnosis** — Example: invoice missing a PO leads to a Monday 9:12 AM email to the payer; 'It was short-paid' triggers the next action. | `ai` | https://meetalder.com/ |
| 3 | **Evidence assembly for humans** — 'Alder pulls the PO, receipt, and rate, and hands your analyst a decision with the supporting evidence.' | `hybrid` | https://meetalder.com/ |
| 4 | **Analyst decision** — The analyst makes the final call with Alder's assembled evidence. | `human` | https://meetalder.com/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review (analyst decides on flagged items)

**6. How the company makes money.** Not captured (pricing page exists); sold as an 'AI employee' for the receivables team

**7. Evidence — publicly reported metrics.**

- Example workflow: PO retrieval, receipt and rate assembled for analyst decision

**8. What remains unknown.**

- Pricing not captured
- No published recovery-rate or volume metrics
- The analyst remains the decision-maker for exceptions

**Sources.** https://meetalder.com/, https://meetalder.com/product, https://www.ycombinator.com/companies/alder  (last verified 2026-10-28)

---

### Allia Health

- **YC batch:** Summer 2026  |  **Industry:** Healthcare  |  **Website:** https://allia.health/
- **Classification:** ai_native_service  |  **Delivery band:** Insufficient Evidence  |  **Evidence:** medium

**1. What the company does.** AI-native medical group for mental health

**2. Traditional service replaced.** Behavioral health practice operations: documentation, billing/claims, payer rules compliance

**3. Target customer and what they buy.** Behavioral health practices (solo, group, multi-site) - therapy, psychiatry, TMS, medication management. A practice platform that runs documentation and billing, plus access to a medical group structure

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **AI documentation** — 'AI documentation and automation handling the busywork'. | `ai` | https://allia.health/ |
| 2 | **Claims processing** — '98%+ first-time claims acceptance - practices get paid faster, with far fewer denials.' | `ai` | https://allia.health/ |
| 3 | **Multi-state and payer rule handling** — 'A flexible platform that handles multi-state rules, varied payer mixes, different credentials, and hybrid care models'. | `ai` | https://allia.health/ |

**5. Where humans remain involved.** Unknown or insufficient evidence

**6. How the company makes money.** Not publicly disclosed on the captured pages

**7. Evidence — publicly reported metrics.**

- 6 hours saved per clinician each week on average
- 98%+ first-time claims acceptance

**8. What remains unknown.**

- 'Medical group' framing suggests a clinical service entity, but clinician delivery sits outside the AI-native service thesis
- Pricing not captured
- Human involvement not described

**Sources.** https://allia.health/, https://allia.health/about, https://www.ycombinator.com/companies/allia-health  (last verified 2026-10-28)

---

### Altair Health

- **YC batch:** Fall 2026  |  **Industry:** Healthcare  |  **Website:** https://www.altair-health.com
- **Classification:** ai_native_service  |  **Delivery band:** Insufficient Evidence  |  **Evidence:** low

**1. What the company does.** AI medical billing with a free EHR (behavioral health)

**2. Traditional service replaced.** Behavioral health billing: eligibility verification, claim submission, prior authorisation, patient billing, denial appeals

**3. Target customer and what they buy.** Behavioral health providers. A free EHR plus AI billing that 'gets you paid': coverage confirmation, claim submission, prior auths, patient bills, appeals

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Coverage confirmation** — Live counter shows 'Confirmed coverage on 38 visits'. | `ai` | https://www.altair-health.com |
| 2 | **Claim submission** — Live counter: 'Submitted 187 claims'. | `ai` | https://www.altair-health.com |
| 3 | **Payment posting** — Live counter: 'Posted $18,412 in payments'. | `ai` | https://www.altair-health.com |
| 4 | **Prior authorisations** — Live counter: 'Filed 12 prior authorizations'. | `ai` | https://www.altair-health.com |
| 5 | **Patient billing and appeals** — Live counters: 'Sent 96 patient bills', 'Appealed 34 denials'. | `ai` | https://www.altair-health.com |

**5. Where humans remain involved.** Unknown or insufficient evidence

**6. How the company makes money.** Free EHR with AI billing built in (billing monetisation implied; not published)

**7. Evidence — publicly reported metrics.**

- Illustrative live counters: 38 visits coverage-confirmed, 187 claims submitted, $18,412 payments posted, 12 prior auths filed, 96 patient bills sent, 34 denials appealed

**8. What remains unknown.**

- The counters appear to be a product demo, not audited customer results
- No pricing model published
- Human involvement not described
- Very early (Fall 2026)

**Sources.** https://www.altair-health.com, https://www.ycombinator.com/companies/altair-health  (last verified 2026-10-28)

---

### Arctic Health

- **YC batch:** Spring 2026  |  **Industry:** Healthcare  |  **Website:** https://arctic.health
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** medium

**1. What the company does.** AI-native provider credentialing, enrollment and contracting

**2. Traditional service replaced.** Provider credentialing and payer enrollment work: documentation gathering, application completion, CAQH maintenance, re-credentialing, payer contracting

**3. Target customer and what they buy.** Medical practices; also telehealth platforms, RCM companies and CVOs (via API/white-label). Completed credentialing and enrollment: 'We partner with your practice to manage the entire credentialing process'

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Documentation gathering** — 'Complete documentation gathering and verification'. | `hybrid` | https://arctic.health |
| 2 | **AI document extraction** — 'AI-powered document extraction and error detection' in the API/white-label offering. | `ai` | https://arctic.health |
| 3 | **Payer application submission** — 'Payer application submission within 2 days'; 'Automated onboarding, submissions, and payer status tracking'. | `hybrid` | https://arctic.health |
| 4 | **Specialist review** — 'Specialist review on every application before submission'; 'our team gathers documentation, completes applications, and submits to payers within 2 days'. | `human` | https://arctic.health |
| 5 | **Re-credentialing and monitoring** — 'Ongoing re-credentialing and monitoring'; 'Appeals and revalidation management'. | `hybrid` | https://arctic.health |

**5. Where humans remain involved.** Human-supervised AI execution (specialist reviews every application)

**6. How the company makes money.** Managed service (no setup fees advertised); white-label/API tier for platforms

**7. Evidence — publicly reported metrics.**

- 2-day payer submission
- 300+ insurance networks
- All 50 states + DC
- 'No setup fees, no onboarding delays'

**8. What remains unknown.**

- 'Specialist review on every application' means human review is mandatory, not exception-based
- Pricing not published
- No published error-rate or volume metrics

**Sources.** https://arctic.health, https://arctic.health/case-studies, https://www.ycombinator.com/companies/arctic-health  (last verified 2026-10-28)

---

### Asendia AI

- **YC batch:** Spring 2026  |  **Industry:** B2B / HR  |  **Website:** https://asendia.ai/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** Agentic recruiting - AI interviews and candidate screening for staffing firms

**2. Traditional service replaced.** Top-of-funnel recruiting work: candidate phone screening, scheduling and qualification

**3. Target customer and what they buy.** Staffing agencies and enterprise recruiting organisations. Screened candidates: AI interviews that screen far more candidates, with the AI handling the entire top of funnel

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **AI phone screen** — 'Day 1: Sarah, the AI agent, calls the candidate to conduct a preliminary phone screen' - a scripted AI voice interview. | `ai` | https://asendia.ai/ |
| 2 | **Candidate matching** — Agent scores and matches candidates (e.g. 'Alen 72% Match Sales Manager, New York'). | `ai` | https://asendia.ai/ |
| 3 | **Funnel ownership** — 'The AI handles the entire top-of-funnel so our team can focus on closing the best candidates.' | `ai` | https://asendia.ai/ |
| 4 | **Recruiter closes** — Human recruiters handle the close; the service is positioned as cloning a firm's best recruiters rather than replacing them. | `human` | https://asendia.ai/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review (AI owns the top of funnel; recruiters close)

**6. How the company makes money.** Not publicly disclosed; sold to staffing firms and enterprises as an agentic recruiting platform

**7. Evidence — publicly reported metrics.**

- 'AI interviews that screen 10x more candidates'
- 'The #1 agentic recruiting platform for staffing and enterprise'

**8. What remains unknown.**

- '10x more candidates' has no published methodology
- Pricing not published
- Explicitly designed not to replace recruiters ('Don't replace your recruiters, Clone your best ones')

**Sources.** https://asendia.ai/, https://www.ycombinator.com/companies/asendia-ai  (last verified 2026-10-28)

---

### Assembly HOA

- **YC batch:** Summer 2024  |  **Industry:** Real Estate  |  **Website:** https://assemblyhoa.com
- **Classification:** ai_enabled_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** AI-native HOA management company

**2. Traditional service replaced.** Homeowners association management: budgeting, reserve planning, assessment collection, maintenance coordination, vendor management and board reporting

**3. Target customer and what they buy.** HOA boards and communities. HOA management delivered by expert managers with modern software - budgeting, reserve planning, collections, maintenance and reporting

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Financial management** — 'Budgeting that reflects actual needs ... Reserve planning ... Assessment collection and delinquency enforcement ... Real-time reporting with board-ready insights.' | `hybrid` | https://assemblyhoa.com |
| 2 | **Maintenance coordination** — 'Tracking service requests from submission to completion'; 'Matching vendors to the right scope and budget'; 'Set and enforce a recurring maintenance schedule'. | `hybrid` | https://assemblyhoa.com |
| 3 | **Automated invoicing** — 'Invoices are automatically processed and sent for one-click board approval, ensuring vendors are paid instantly and accurately.' | `ai` | https://assemblyhoa.com |
| 4 | **Expert manager delivery** — 'Expert-led HOA management, backed by modern tech'; 'We combine the best managers with modern transparent software'. | `human` | https://assemblyhoa.com |

**5. Where humans remain involved.** Human-led with AI assistance (expert managers deliver; software automates invoicing and tracking)

**6. How the company makes money.** HOA management fees (not published); 'Request a proposal' intake

**7. Evidence — publicly reported metrics.**

- 4.5 on Google
- Customer quote about saving money by finding better vendors

**8. What remains unknown.**

- Explicitly 'expert-led', i.e. human delivery with tech support
- Pricing not published
- No published portfolio or automation metrics
- The site describes 'modern transparent software' rather than AI agents doing the work

**Sources.** https://assemblyhoa.com, https://www.ycombinator.com/companies/assembly-hoa  (last verified 2026-10-28)

---

### Atlia

- **YC batch:** Summer 2026  |  **Industry:** Real Estate  |  **Website:** https://www.atlia.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** high

**1. What the company does.** AI-native short-term rental property management

**2. Traditional service replaced.** Short-term rental property management companies charging 20-35% of revenue for guest communication, pricing, turnovers, maintenance coordination and owner reporting

**3. Target customer and what they buy.** Short-term rental owners. Full-service property management at a flat 10% fee: guests handled, pricing set, turnovers and maintenance coordinated, owner reporting

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Guest communication** — 'Atlia coordinates guest communication, pricing, turnovers, maintenance, supplies, and property-specific decisions'. | `ai` | https://www.atlia.com |
| 2 | **Dynamic pricing** — Operators supervise pricing; the system handles day-to-day pricing decisions. | `hybrid` | https://www.atlia.com |
| 3 | **Property memory** — 'House rules, vendors, calendars, pricing, and operating details stay in context for every booking.' | `ai` | https://www.atlia.com |
| 4 | **Local operator oversight** — 'A real operator stays close to your home and coordinates guests, vendors, and urgent property issues'; 'Experienced operators supervising the system.' | `human` | https://www.atlia.com |
| 5 | **Owner reporting** — 'Clear approvals, transparent reporting, and a flat fee keep the model simple.' | `hybrid` | https://www.atlia.com |

**5. Where humans remain involved.** Human-supervised AI execution (experienced operators supervise the system)

**6. How the company makes money.** Flat 10% management fee (explicitly contrasted with the traditional 20-35% STR management fee)

**7. Evidence — publicly reported metrics.**

- 10% flat management fee vs traditional 20-35%
- Local staffed operations in Fort Lauderdale and San Diego

**8. What remains unknown.**

- Operators remain central ('experienced operators supervising the system'), so this is supervised rather than autonomous
- No published portfolio size or owner outcomes
- Limited to two metro areas

**Sources.** https://www.atlia.com, https://www.atlia.com/about, https://www.ycombinator.com/companies/atlia  (last verified 2026-10-28)

---

### Autotab

- **YC batch:** Summer 2023  |  **Industry:** B2B  |  **Website:** https://autotab.com
- **Classification:** hybrid  |  **Delivery band:** Insufficient Evidence  |  **Evidence:** low

**1. What the company does.** General AI agent for knowledge work (BPO replacement positioning)

**2. Traditional service replaced.** Business process outsourcing - the site explicitly addresses 'replacing your BPO with something better'

**3. Target customer and what they buy.** Enterprises with repetitive back-office processes. A general AI agent that 'learns and works like a human' - the agent, which the customer deploys

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Agent learning** — 'Autotab is a general AI agent that both learns and works like a human.' | `ai` | https://autotab.com |
| 2 | **BPO replacement conversation** — 'If you are interested in replacing your BPO with something better, please email us.' | `hybrid` | https://autotab.com |

**5. Where humans remain involved.** Unknown or insufficient evidence

**6. How the company makes money.** Not publicly disclosed on the captured page

**7. Evidence.** No deployment metrics published.

**8. What remains unknown.**

- The captured site content is a single-page enterprise teaser
- The agent appears to be software the enterprise runs, though the site frames it as a BPO replacement
- No pricing, workflow or outcome detail

**Sources.** https://autotab.com, https://www.ycombinator.com/companies/autotab  (last verified 2026-10-28)

---

### Balance

- **YC batch:** Winter 2026  |  **Industry:** Fintech / B2B  |  **Website:** https://getbalance.ai
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** high

**1. What the company does.** AI-native accounting and bookkeeping service

**2. Traditional service replaced.** Outsourced bookkeeping and management accounting: reconciling, categorising, matching documents, month-end close, and signing off the books

**3. Target customer and what they buy.** E-commerce, marketplaces, hospitality and other SMEs needing ongoing bookkeeping (150+ companies cited). Audit-ready books and ongoing accounting delivered as a service at a flat monthly price, with a named accountant who signs off

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Document ingestion** — 'Our own agents reconcile, categorise and match documents against your ledger, continuously through the month.' | `ai` | https://getbalance.ai |
| 2 | **Continuous reconciliation** — 'Books that never fall behind' - reconciliation runs through the month rather than at period end. | `ai` | https://getbalance.ai |
| 3 | **Ledger posting** — The work is automated; agents categorise and match against the ledger. | `ai` | https://getbalance.ai |
| 4 | **Accountant review & sign-off** — 'The AI does the manual work, our accountants review'; 'A real accountant, every month'; 'Signed off by Merlin'. | `human` | https://getbalance.ai |
| 5 | **Client Q&A** — Financial assistant ('Bea') answers questions such as 'How did our income and expenses look in Q1?' in seconds. | `ai` | https://getbalance.ai |

**5. Where humans remain involved.** AI-led execution with exception-based human review (accountant signs off monthly)

**6. How the company makes money.** Flat monthly fee for accounting as a service ('a flat monthly price'); no hourly billing for questions

**7. Evidence — publicly reported metrics.**

- Trusted by 150+ companies
- Customer quote: 'about a third less than we paid before'
- 'Books ... closed in days'

**8. What remains unknown.**

- 'About a third less' is a single customer's recollection, not audited pricing
- No published headcount-to-client ratio
- Pricing amount not published on the captured pages

**Sources.** https://getbalance.ai, https://getbalance.ai/how-it-works, https://getbalance.ai/faq, https://www.ycombinator.com/companies/getbalance  (last verified 2026-10-28)

---

### Beacon Health

- **YC batch:** Winter 2026  |  **Industry:** Healthcare  |  **Website:** https://www.beaconhealth.ai/
- **Classification:** ai_native_service  |  **Delivery band:** Predominantly Autonomous  |  **Evidence:** medium

**1. What the company does.** AI workforce for healthcare operations (EHR-native agents)

**2. Traditional service replaced.** Healthcare administrative labour performed in the EHR: patient chart navigation, care-gap outreach, documentation

**3. Target customer and what they buy.** Physician practices and health systems. AI agents deployed into the customer's EHR that execute multi-step administrative workflows

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Workflow capture** — 'Record any workflow in your EHR and turn it into an AI Agent'; 'Beacon captures every step - navigation, clicks, data entry - and converts it into a reusable, deployable agent.' | `human` | https://www.beaconhealth.ai/ |
| 2 | **EHR execution** — 'Beacon navigates and operates real EHR systems, just like a human, to automate complex tasks from end to end.' | `ai` | https://www.beaconhealth.ai/ |
| 3 | **Multi-step chaining** — 'agents can perform complex, multi-step workflows over long horizons on any EHR - chaining tasks across patient charts, care gaps, outreach, and documentation without any human hand-offs.' | `ai` | https://www.beaconhealth.ai/ |
| 4 | **Human monitoring and intervention** — 'Full visibility into every agent's status, with controls to pause, review, or intervene at any time.' | `human` | https://www.beaconhealth.ai/ |

**5. Where humans remain involved.** Predominantly autonomous delivery (agents run without human hand-offs, with pause/review controls)

**6. How the company makes money.** Not publicly disclosed; deployed as an AI workforce into existing EHRs

**7. Evidence — publicly reported metrics.**

- 'Trusted by physicians across the country'
- HIPAA compliant
- Works with any EHR

**8. What remains unknown.**

- 'Without any human hand-offs' is a strong autonomy claim without published deployment metrics
- Pricing not disclosed
- No published accuracy or volume figures

**Sources.** https://www.beaconhealth.ai/, https://www.ycombinator.com/companies/beacon-health  (last verified 2026-10-28)

---

### Bear

- **YC batch:** Summer 2026  |  **Industry:** Fintech / B2B  |  **Website:** https://bear.inc/
- **Classification:** ai_native_service  |  **Delivery band:** Insufficient Evidence  |  **Evidence:** low

**1. What the company does.** AI-native accounting firm

**2. Traditional service replaced.** Traditional accounting firm engagement (bookkeeping, tax, compliance work performed by a firm)

**3. Target customer and what they buy.** Startups and small businesses that would otherwise hire an accounting firm. An accounting firm's output delivered by an AI-native firm

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Firm-level delivery** — YC one-liner: 'AI-native accounting firm.' The website presents the company as an accounting firm, with a countdown teaser ('Looking for Last Accounting Company?'). | `hybrid` | https://bear.inc/ |

**5. Where humans remain involved.** Unknown or insufficient evidence

**6. How the company makes money.** Not publicly disclosed

**7. Evidence.** No deployment metrics published.

**8. What remains unknown.**

- Website content is a teaser/countdown; no workflow detail is public
- No pricing or delivery detail
- Classified AI-native on the strength of the firm framing and YC listing only

**Sources.** https://bear.inc/, https://www.ycombinator.com/companies/bear-inc  (last verified 2026-10-28)

---

### Billow AI Labs

- **YC batch:** Summer 2026  |  **Industry:** B2B / Fintech  |  **Website:** https://thebillow.ai/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI accounting close automation as a delegated service

**2. Traditional service replaced.** Manual finance-team close work: bank and credit card reconciliations, accruals, prepaids, fixed assets, payroll and expense entries, multi-entity consolidation, reporting and close workpapers

**3. Target customer and what they buy.** Finance teams running NetSuite, Dynamics 365 or QuickBooks. The month-end close executed on the customer's own accounting stack, with the team reviewing and approving

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Learn the close** — 'Built from 3 closes you ran by hand' then 'We take over. We learn your process and build around it.' | `hybrid` | https://thebillow.ai/ |
| 2 | **Pull trial balance** — Close workflow step: 'Pull trial balance' from NetSuite. | `ai` | https://thebillow.ai/ |
| 3 | **Match transactions** — Close workflow step: 'Match transactions' performed by an agent. | `ai` | https://thebillow.ai/ |
| 4 | **Send for approval** — Close workflow step: 'Send for approval' - human review of the agent's output. | `human` | https://thebillow.ai/ |
| 5 | **Handled work types** — 'Bank and credit card reconciliations, Accruals, prepaids and fixed assets, Payroll and expense entries, Multi-entity consolidation, Financial reporting and close workpapers.' | `ai` | https://thebillow.ai/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review ('Your team reviews and approves')

**6. How the company makes money.** Not publicly disclosed; sold as delegating manual finance work to AI on top of the customer's existing tools

**7. Evidence — publicly reported metrics.**

- Named customer testimonial from a CPA (Corey Pecoraro)

**8. What remains unknown.**

- Pricing not published
- No quantified automation rate
- The customer's own team still reviews and approves, so the service augments rather than fully replaces the finance team

**Sources.** https://thebillow.ai/, https://thebillow.ai/case-studies, https://www.ycombinator.com/companies/billow-ai-labs  (last verified 2026-10-28)

---

### Callbook AI

- **YC batch:** Summer 2026  |  **Industry:** Fintech / B2B  |  **Website:** https://callbook.ai
- **Classification:** ai_native_service  |  **Delivery band:** Predominantly Autonomous  |  **Evidence:** medium

**1. What the company does.** AI collections agency for late-stage portfolios

**2. Traditional service replaced.** Debt collection agency / collections call centre work on late-stage portfolios

**3. Target customer and what they buy.** Lenders and debt owners with late-stage portfolios. Collections outcomes - AI agents that locate, contact and negotiate with each borrower

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Borrower location** — 'Our AI agents locate, contact, and negotiate with each borrower, adapted to your strategy and measured against your current results.' | `ai` | https://callbook.ai |
| 2 | **Multichannel conversation** — 'Calls, SMS, and email in one continuous conversation'; 'Every channel contributes to the customer history.' | `ai` | https://callbook.ai |
| 3 | **Negotiation and payment plans** — Agent conversation example ends with 'A new payment plan is ready.' | `ai` | https://callbook.ai |
| 4 | **Continuous improvement loop** — 'Incidents, tests, customer requirements, and system changes feed back into the control environment.' | `hybrid` | https://callbook.ai |

**5. Where humans remain involved.** Predominantly autonomous delivery (agents locate, contact and negotiate; the site advertises no human agents in the loop)

**6. How the company makes money.** Collections contingency economics (not published); measured 'against your current results'

**7. Evidence — publicly reported metrics.**

- 23M+ borrowers managed
- 2M+ payments recovered
- USD $11M+ recovered
- 'Enterprise-grade security and controls'

**8. What remains unknown.**

- Metrics mirror AgentCollect's figures and no methodology is published
- No pricing or commission rate disclosed
- Whether human collectors supervise calls is not stated
- Very early (Summer 2026)

**Sources.** https://callbook.ai, https://callbook.ai/security, https://www.ycombinator.com/companies/callbook-ai  (last verified 2026-10-28)

---

### Cifrato

- **YC batch:** Winter 2025  |  **Industry:** Fintech / B2B  |  **Website:** https://cifrato.ai
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** Agentic invoice processing, reconciliation and compliance

**2. Traditional service replaced.** Manual accounting data entry: invoice intake, classification, posting, reconciliation

**3. Target customer and what they buy.** Companies in Colombia/LATAM ('Live in & Trusted by 3.5k+ companies'). Invoices processed, classified, reconciled and posted into the ERP, with only exceptions surfaced for human review

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Invoice intake** — 'Pulls invoices straight from the tax authority and email automatically, as they arrive.' | `ai` | https://cifrato.ai |
| 2 | **Classification & posting** — 'Classifies and posts each document against the right accounts, taxes, and cost centers.' | `ai` | https://cifrato.ai |
| 3 | **Reconciliation** — Agents 'process invoices, reconcile, and keep you compliant.' | `ai` | https://cifrato.ai |
| 4 | **Exception approval** — 'Only the entries that genuinely need a human decision are surfaced for your review.' | `human` | https://cifrato.ai |
| 5 | **ERP sync** — 'Posts the finished entries straight into the ERP your team already runs.' | `ai` | https://cifrato.ai |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Not publicly disclosed; sold on processing volume and time per invoice

**7. Evidence — publicly reported metrics.**

- Live in and trusted by 3.5k+ companies
- Processed money equal to a stated % of Colombia's GDP
- Avg time per invoice processed vs 360 sec without Cifrato

**8. What remains unknown.**

- The published metrics are rendered as animated counters and were not captured as final values
- Pricing not published
- Regional focus (Colombia) limits generalisation

**Sources.** https://cifrato.ai, https://www.ycombinator.com/companies/cifrato  (last verified 2026-10-28)

---

### Covera

- **YC batch:** Fall 2026  |  **Industry:** Insurance  |  **Website:** https://www.covera-agents.com/
- **Classification:** hybrid  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI workspace / service layer for independent insurance agencies

**2. Traditional service replaced.** Manual agency work: data entry, submission prep, carrier quoting follow-up, file follow-up, COI handling, renewal remarketing

**3. Target customer and what they buy.** Independent insurance agencies (producers, CSRs, account managers). Work done inside the agency's own AMS: submissions prepared, quotes gathered, files synced, and account questions answered

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Submission intake** — 'New submission Restaurant, BOP' - Covera starts from the first email and prepares the submission. | `ai` | https://www.covera-agents.com/ |
| 2 | **Carrier quoting** — Carrier 1/2/3 quotes gathered and compared, 'Best value: Carrier 2', in ~30 sec in the demo. | `ai` | https://www.covera-agents.com/ |
| 3 | **Bind & sync** — 'The client signs, your AMS updates, the summary goes out, servicing takes over.' | `hybrid` | https://www.covera-agents.com/ |
| 4 | **Day-to-day account assistant** — 'Your team asks, Covera answers from your AMS, emails and policies, with the source.' | `ai` | https://www.covera-agents.com/ |
| 5 | **Human review of binding and advice** — 'Binding, pricing, and advice stay under human review'; 'your team approves every action'. | `human` | https://www.covera-agents.com/ |
| 6 | **Renewal remarketing** — X-date tracking with remarketing quotes at 90/60/30 days. | `ai` | https://www.covera-agents.com/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review (agency approves every action)

**6. How the company makes money.** Not publicly disclosed on the captured pages; marketed on ROI ('12x ROI after 4 weeks', '10 hrs saved per user per week')

**7. Evidence — publicly reported metrics.**

- 5 min from request to first quote
- +20% more new business won
- 10 hrs saved per user every week
- 12x ROI after 4 weeks

**8. What remains unknown.**

- Company describes itself as an 'AI workspace for independent agencies' - the customer remains the agency, so the end client is still served by the agency
- Pricing not published
- Metrics appear to be product claims without published methodology

**Sources.** https://www.covera-agents.com/, https://www.ycombinator.com/companies/covera  (last verified 2026-10-28)

---

### Dock

- **YC batch:** Summer 2026  |  **Industry:** B2B  |  **Website:** https://trydock.ai
- **Classification:** ai_copilot_or_tool  |  **Delivery band:** AI-Assisted  |  **Evidence:** high

**1. What the company does.** Hire agents for business work (agent marketplace with included agents)

**2. Traditional service replaced.** Hiring additional staff for business work; individual point-solution SaaS tools

**3. Target customer and what they buy.** Business teams. Access to specialised agents with skills, tools and a computer; priced per person on the team

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Agent marketplace** — 'Hire agents for business work - Specialized agents with skills, tools, and a computer.' | `ai` | https://trydock.ai |
| 2 | **Agents included** — 'The agents come included'; 'Agents that take on the work you never get to.' | `ai` | https://trydock.ai |
| 3 | **Customer operates the agents** — 'You pay for the people on your team' - the pricing model is per-seat for humans, and the customer directs the agents. | `human` | https://trydock.ai/pricing |

**5. Where humans remain involved.** Human-led with AI assistance (the customer's team directs and operates the agents)

**6. How the company makes money.** Published per-person subscription: Starter $20/person/month (one agent), Standard $100/person/month (a small team of agents, always on, 10,000 business credits, base model usage, 5 GB storage)

**7. Evidence — publicly reported metrics.**

- Starter $20 per person/month
- Standard $100 per person/month with 5 agents always on and 10,000 business credits

**8. What remains unknown.**

- Per-seat pricing on the customer's own people is a software model - the customer remains responsible for directing the work
- Included as a comparison case to contrast with AI-native service pricing
- No published outcome metrics

**Sources.** https://trydock.ai, https://trydock.ai/pricing, https://www.ycombinator.com/companies/dock  (last verified 2026-10-28)

---

### Erinys

- **YC batch:** Summer 2026  |  **Industry:** Legal  |  **Website:** https://erinys.ai
- **Classification:** ai_native_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** low

**1. What the company does.** Launching and operating AI-native law firms (firm-in-a-box)

**2. Traditional service replaced.** The overhead of standing up and running an independent law practice (entity, operations, back office)

**3. Target customer and what they buy.** Lawyers who want to start their own firm. A launched and operated law firm: 'Erinys launches and operates AI-native law firms for lawyers ready to build something of their own'

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Firm launch** — 'Erinys launches and operates AI-native law firms'; 'Welcome to the firm you almost started.' | `hybrid` | https://erinys.ai |
| 2 | **Operating loop** — 'You practice law.' plus 'Automatable with Erinys - the full operating loop', i.e. Erinys automates the operating loop around the lawyer's practice. | `ai` | https://erinys.ai |

**5. Where humans remain involved.** Human-led with AI assistance (the lawyer practises law; Erinys runs the firm's operations)

**6. How the company makes money.** Not publicly disclosed (waitlist stage)

**7. Evidence.** No deployment metrics published.

**8. What remains unknown.**

- Very thin public detail - the captured page is a waitlist landing page
- Pricing, structure and legal/regulatory model not published
- The captured page mentions 'For NPOs' with a contact address, which is not explained

**Sources.** https://erinys.ai, https://www.ycombinator.com/companies/erinys  (last verified 2026-10-28)

---

### Fernstone

- **YC batch:** Fall 2025  |  **Industry:** Insurance  |  **Website:** https://www.fernstone.com
- **Classification:** ai_enabled_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** Commercial insurance brokerage (specialty: security guard / staffing)

**2. Traditional service replaced.** Commercial insurance brokerage and risk-management service for security guard and staffing businesses

**3. Target customer and what they buy.** Small and mid-size security guard companies and staffing firms in the US. A managed brokerage relationship: carrier placement, policy issuance, certificates of insurance, renewals, claims handling, and a risk advisor

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Platform intake & quoting** — Clients request quotes through the Fernstone platform; the site advertises a single platform to issue COIs, track claims, manage policies and stay compliant. | `hybrid` | https://www.fernstone.com |
| 2 | **Automated alerts** — 'Get notified before renewals, expirations, or coverage gaps.' Automated monitoring of policy dates. | `ai` | https://www.fernstone.com |
| 3 | **COI issuance** — 'Create and share certificates instantly.' Self-service certificate generation. | `hybrid` | https://www.fernstone.com |
| 4 | **Risk advisory** — 'Every client gets a dedicated risk advisor who learns your operations and grows with you.' | `human` | https://www.fernstone.com |
| 5 | **Claims handling** — 'File and track claims in one place with real people who follow through fast.' | `human` | https://www.fernstone.com |

**5. Where humans remain involved.** Human-led with AI assistance

**6. How the company makes money.** Traditional brokerage economics: carrier commissions plus a managed service relationship; pricing not publicly itemised ('clear pricing, no hidden fees')

**7. Evidence — publicly reported metrics.**

- Under 48 hours typical quote turnaround when submission is ready
- Under 24 hours customer response time
- 100+ security guard customers
- Licensed in all 50 states
- $2,500 to $100,000+ premium range

**8. What remains unknown.**

- No public claim that AI performs underwriting or quoting autonomously
- Marketing emphasises 'dedicated team' and 'TALK TO HUMANS', i.e. human delivery is central
- Commission economics not disclosed

**Sources.** https://www.fernstone.com, https://www.fernstone.com/security, https://www.ycombinator.com/companies/fernstone  (last verified 2026-10-28)

---

### General Legal

- **YC batch:** Winter 2026  |  **Industry:** Legal  |  **Website:** https://general.legal
- **Classification:** ai_native_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** AI law firm for high-growth companies

**2. Traditional service replaced.** Outside counsel and in-house legal work for startups and scaleups: NDAs, commercial contracts, employment, fintech/payments terms

**3. Target customer and what they buy.** Startups, scaleups and enterprises (500+ companies cited). Legal work product delivered by a law firm: contracts, redlines, memos, advisory

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Legal intake** — 'Start a matter' intake on the firm's site. | `hybrid` | https://general.legal |
| 2 | **Drafting and review** — Client quote: 'No matter what I hand General Legal - partnership agreements, user terms, an FCRA memo - it comes back fast and done right.' | `hybrid` | https://general.legal |
| 3 | **Attorney delivery** — The work is delivered as legal work product, with the firm recognised by Chambers Spotlight Artificial Intelligence (New York, 2027). | `human` | https://general.legal |
| 4 | **Responsiveness** — Client quote referencing 'After hours redlines, same-day NDA reviews'. | `hybrid` | https://general.legal |

**5. Where humans remain involved.** Human-led with AI assistance (attorneys deliver; AI accelerates first-pass work)

**6. How the company makes money.** Legal fees; the firm is a law firm rather than a software vendor. Specific pricing not published on the captured pages.

**7. Evidence — publicly reported metrics.**

- 500+ startups, scaleups and enterprises as clients
- Chambers Spotlight Artificial Intelligence recognition (New York, 2027)

**8. What remains unknown.**

- The AI stack is not described publicly; the 'AI law firm' positioning rests on firm branding and client testimony
- Pricing not published
- Independent verification of the 500+ client figure is not available

**Sources.** https://general.legal, https://general.legal/about, https://www.ycombinator.com/companies/general-legal  (last verified 2026-10-28)

---

### Health Harbor

- **YC batch:** Summer 2023  |  **Industry:** Healthcare  |  **Website:** https://healthharbor.co/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** high

**1. What the company does.** AI payor calls - benefit verification and claim follow-up

**2. Traditional service replaced.** Clinic staff calling insurance companies: benefit verification, claim status follow-up, denial reason calls

**3. Target customer and what they buy.** Healthcare clinics and billing teams. Completed payor calls: benefit verifications and claim status results returned to the practice

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Call initiation** — 'Our AI talks to health insurance reps on your behalf, enabling your staff to focus on more complex issues.' | `ai` | https://healthharbor.co/ |
| 2 | **IVR navigation and hold** — 'Our AI will navigate IVR, wait on hold and then transfer to your staff to complete the call' (Copilot mode). | `ai` | https://healthharbor.co/ |
| 3 | **Benefit verification** — 'We check if a patient's plan is active, deductibles/maximums, and coverage for specific procedure codes - details often unavailable on the insurer's website.' | `ai` | https://healthharbor.co/ |
| 4 | **Claim follow-up** — 'We ask for the current status (not found, pending, paid, or denied), and can follow up on why the claim was denied.' | `ai` | https://healthharbor.co/ |
| 5 | **Staff action on results** — 'Your team can then focus on fixing or adjusting the claim to recover payments left on the table.' | `human` | https://healthharbor.co/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review (two modes: fully automated, and Copilot which transfers to staff)

**6. How the company makes money.** 'Pay per call based on complexity'; custom volume pricing with a dedicated account manager for larger customers

**7. Evidence — publicly reported metrics.**

- 99% accuracy of fully automated results
- 'More affordable than outsourcing to call centers'

**8. What remains unknown.**

- '99% accuracy' has no published methodology
- Pricing is per-call but rates are not published
- The Copilot mode deliberately leaves the human on the call

**Sources.** https://healthharbor.co/, https://healthharbor.co/pricing, https://healthharbor.co/product, https://www.ycombinator.com/companies/health-harbor  (last verified 2026-10-28)

---

### Humoniq

- **YC batch:** Summer 2025  |  **Industry:** B2B / Travel  |  **Website:** https://humoniq.ai
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** high

**1. What the company does.** Fully automated airline customer service (managed service)

**2. Traditional service replaced.** Airline customer service and contact-centre operations: resolving passenger requests over email, chat and phone

**3. Target customer and what they buy.** Airlines. Resolved passenger requests end to end, delivered as a managed service, with optional in-house support mode

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Request intake** — 'We resolve passenger requests across email, chat and phone.' | `ai` | https://humoniq.ai |
| 2 | **Rules-grounded resolution** — 'Resolving requests end-to-end' using 'Passenger, booking and airline rules.' | `ai` | https://humoniq.ai |
| 3 | **Service-model choice** — 'Choose the service model that fits your airline' - including 'In-house support / Your team' where 'Your experts step in when needed.' | `hybrid` | https://humoniq.ai |
| 4 | **Managed service layer** — 'AI and experienced travel specialists, together in one managed service.' | `human` | https://humoniq.ai |
| 5 | **Approval points** — 'Your scope and approval points'; 'Every case and action in view'. | `human` | https://humoniq.ai |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Managed service for airlines; a pricing page exists but rates were not captured

**7. Evidence — publicly reported metrics.**

- 60% reduction in human labour hours
- 75% of complex cases automated
- Built exclusively for airlines

**8. What remains unknown.**

- The metrics have no published methodology
- Pricing not captured
- The 'in-house support' mode keeps the airline's own team in the loop

**Sources.** https://humoniq.ai, https://humoniq.ai/pricing, https://www.ycombinator.com/companies/humoniq  (last verified 2026-10-28)

---

### Jarmin

- **YC batch:** Fall 2025  |  **Industry:** B2B  |  **Website:** https://jarmin.ai/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI employees for human-level roles (managed AI workforce)

**2. Traditional service replaced.** Hiring and managing staff in defined roles: ML engineer, financial analyst, account executive, compliance analyst, data analyst, project manager, paralegal

**3. Target customer and what they buy.** Companies wanting capacity in specific roles without hiring. A managed AI employee that 'learns the job and your standards, works in the tools you already use'

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Role setup** — 'We set up your AI employee, and it gets to work.' The customer selects a role or builds a custom one. | `hybrid` | https://jarmin.ai/ |
| 2 | **Scoped execution** — 'Owns the work inside an agreed scope, produces reviewable output, and escalates the decisions that require you.' | `ai` | https://jarmin.ai/ |
| 3 | **Tool operation** — The AI employee 'works in the tools you already use'. | `ai` | https://jarmin.ai/ |
| 4 | **Escalation** — 'escalates the decisions that require you' - human decisions retained for consequential calls. | `human` | https://jarmin.ai/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Not captured (pricing page exists); sold as AI employees replacing role-based headcount

**7. Evidence — publicly reported metrics.**

- Role catalogue: ML Engineer, Financial Analyst, Account Executive, Compliance Analyst, Data Analyst, Project Manager, Paralegal
- ML engineering offering covers models, evals and RL environments

**8. What remains unknown.**

- Pricing not captured
- No published client outcomes or accuracy figures
- Role scope and quality control are described in marketing terms only

**Sources.** https://jarmin.ai/, https://jarmin.ai/pricing, https://www.ycombinator.com/companies/jarmin  (last verified 2026-10-28)

---

### LinkLane

- **YC batch:** Winter 2027  |  **Industry:** Industrials / Logistics  |  **Website:** https://linklane.ai/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI-powered freight brokerage

**2. Traditional service replaced.** Freight brokerage service: quoting, carrier sourcing, rate negotiation, tracking and carrier payment

**3. Target customer and what they buy.** Shippers. Booked and tracked freight: 'Your Freight Partner', with instant quotes, vetted carriers and live tracking

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Instant quoting** — 'LinkLane quotes every load against real-time market rates'; 'Shippers get a price in under a minute'; quotes accepted by email 'in any format'. | `ai` | https://linklane.ai/ |
| 2 | **Carrier sourcing and vetting** — 'Capacity is secured instantly through our trusted network of carriers ... every load is fully covered, automatically.' | `ai` | https://linklane.ai/ |
| 3 | **Rate negotiation** — 'our human specialists and AI agents find a qualified carrier, negotiate the rate and manage the shipment from pickup to delivery'. | `hybrid` | https://linklane.ai/about |
| 4 | **Tracking and payment** — 'Real-time tracking door to door, with the carrier paid the instant delivery is confirmed.' | `ai` | https://linklane.ai/ |
| 5 | **Exception handling** — 'Our team handles the exceptions'; 'Every load has a LinkLane specialist watching it, and you can reach us by phone or email whenever you need a person.' | `human` | https://linklane.ai/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review (specialists watch every load and handle exceptions)

**6. How the company makes money.** Freight brokerage: the price booked is the price paid; brokerage margin on loads (rates not published)

**7. Evidence — publicly reported metrics.**

- Price in under a minute
- Quote in under a minute for full truckload or LTL
- Real team behind every load around the clock

**8. What remains unknown.**

- No published load volumes, margins or automation rate
- Brokerage margin structure not disclosed
- Very early (Winter 2027)

**Sources.** https://linklane.ai/, https://linklane.ai/about, https://www.ycombinator.com/companies/linklane  (last verified 2026-10-28)

---

### MochaCare

- **YC batch:** Winter 2026  |  **Industry:** Healthcare  |  **Website:** https://www.mochacare.com/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** Agentic management service for home care organisations

**2. Traditional service replaced.** Home-care agency back-office administration: caregiver recruiting, interviews, offer letters, document collection, scheduling and follow-up

**3. Target customer and what they buy.** Home care agencies. 'AI tools and hands-on services for home care agencies' - the admin work executed on their behalf

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **AI interview scheduling** — 'One ATS for AI and human interviews, offer letters, document collection, and automated caregiver support.' | `ai` | https://www.mochacare.com/ |
| 2 | **Routine follow-up** — 'AI handles routine follow-ups and keeps your team in the loop'; 'Calls, texts, emails, and tasks together.' | `ai` | https://www.mochacare.com/ |
| 3 | **Automated caregiver support** — 'AI automations move work forward' across recruiting and support workflows. | `ai` | https://www.mochacare.com/ |
| 4 | **Human escalation** — 'A human steps in where it matters.' | `human` | https://www.mochacare.com/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Not publicly disclosed ('Products / Working with us / Plans' pages exist but pricing was not captured)

**7. Evidence — publicly reported metrics.**

- $2.4M raised
- Named customer testimonials (Senior Helpers, Assisting Hands)

**8. What remains unknown.**

- Pricing plans not captured
- No quantified automation rate
- Named customers are testimonials rather than published case-study metrics

**Sources.** https://www.mochacare.com/, https://www.mochacare.com/about, https://www.ycombinator.com/companies/mochacare  (last verified 2026-10-28)

---

### Moritz

- **YC batch:** Winter 2026  |  **Industry:** Legal  |  **Website:** http://moritzlegal.com/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** low

**1. What the company does.** Global AI-native law firm with same-day turnaround

**2. Traditional service replaced.** Big Law and cross-border outside counsel for corporate, commercial and debt finance work

**3. Target customer and what they buy.** Startups, tech companies and cross-border businesses. Legal work product from a named attorney bench, positioned on same-day turnaround

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Attorney-led delivery** — The firm publishes a named attorney bench (Harvard, Oxford, Georgetown; ex-Orrick, Gunderson, Latham & Watkins, Kirkland & Ellis, Weil) across corporate, commercial, tech, fintech and EU e-commerce law. | `human` | http://moritzlegal.com/ |
| 2 | **AI acceleration** — The firm is listed by YC as an 'AI-native law firm handling legal work with same-day turnaround'; the operational AI detail is not published. | `hybrid` | https://www.ycombinator.com/companies/moritz |

**5. Where humans remain involved.** Human-led with AI assistance

**6. How the company makes money.** Legal fees (not published on the captured pages)

**7. Evidence — publicly reported metrics.**

- Named attorney bench with stated credentials
- Positioned on same-day turnaround

**8. What remains unknown.**

- The captured site content is almost entirely attorney biographies - no description of the AI stack
- 'AI-native' rests on the YC listing and positioning
- Pricing and client outcomes not published

**Sources.** http://moritzlegal.com/, https://www.ycombinator.com/companies/moritz  (last verified 2026-10-28)

---

### Openroll

- **YC batch:** Fall 2025  |  **Industry:** B2B / HR  |  **Website:** https://www.openroll.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** AI workforce for People and Finance teams

**2. Traditional service replaced.** People/HR and finance operations work: headcount planning, actuals vs budget tracking, compensation and workforce reporting

**3. Target customer and what they buy.** People and Finance teams (Notion, Wallenstam cited). An AI workforce that connects to the customer's people systems and runs planning and reporting work

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **System connection** — 'Openroll connects to your pe[ople systems]' - integration into existing HR/finance data. | `ai` | https://www.openroll.com |
| 2 | **Headcount planning** — 'See your headcount live, track it against your plan, forecast hiring costs, and understand what's driving variance down to the team, manager, or individual level.' | `ai` | https://www.openroll.com |
| 3 | **Actuals vs budget** — 'Track actuals against budget in real time and instantly understand what's driving variance down to the underlying data.' | `ai` | https://www.openroll.com |
| 4 | **Human use of output** — Customer quote: 'They ship fast, automate the busy work, and free our lean team to focus on high-impact work.' | `human` | https://www.openroll.com |

**5. Where humans remain involved.** Human-led with AI assistance (the team uses the outputs; automation removes busywork)

**6. How the company makes money.** Not captured (pricing page exists); 'Try Openroll' with an application to join

**7. Evidence — publicly reported metrics.**

- Named customers: Notion (Head of Total Rewards), Wallenstam (Head of HR)
- Customer quote: 'What used to take hours of modeling now takes seconds'

**8. What remains unknown.**

- The offering reads as an AI-powered platform the team operates, closer to a tool than a delivered service
- Pricing not captured
- No published accuracy or automation-rate metrics

**Sources.** https://www.openroll.com, https://www.ycombinator.com/companies/openroll  (last verified 2026-10-28)

---

### Overdrive Health

- **YC batch:** Winter 2026  |  **Industry:** Healthcare  |  **Website:** https://overdrive.health
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** high

**1. What the company does.** AI-powered medical billing / revenue cycle service

**2. Traditional service replaced.** Outsourced medical billing (RCM) service: coding, claim submission, eligibility checks, denials management

**3. Target customer and what they buy.** Medical providers and EMS billing companies. A revenue-cycle service: claims submitted and followed up so providers get paid more, faster

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Claim intake and submission** — Overdrive Health offers AI powered medical billing services, helping providers get paid more money in less time. | `ai` | https://overdrive.health |
| 2 | **Eligibility checks** — Company reports running hundreds of thousands of eligibility checks. | `ai` | https://overdrive.health |
| 3 | **Automated QA** — Customer quote: 'I'm totally nerding out over the automated QA.' QA is automated as part of the billing pipeline. | `ai` | https://overdrive.health |
| 4 | **Expert biller oversight** — 'Medical billing combining expert billers and advanced technology'; 'cutting-edge AI technology with expert human oversight'; 'we've built an exceptional team of software engineers and expert billers'. | `human` | https://overdrive.health/about |

**5. Where humans remain involved.** Human-supervised AI execution (AI billing with expert biller oversight)

**6. How the company makes money.** Medical billing service economics - typically a percentage of collections (not published)

**7. Evidence — publicly reported metrics.**

- Processes over $100 million in claims annually
- Hundreds of thousands of eligibility checks
- 24/7 support

**8. What remains unknown.**

- The human:AI split is not quantified
- Pricing/percentage not published
- 'Automated QA' is a customer's phrase, not a documented specification

**Sources.** https://overdrive.health, https://overdrive.health/about, https://www.ycombinator.com/companies/overdrive-health  (last verified 2026-10-28)

---

### PARES AI

- **YC batch:** Summer 2025  |  **Industry:** Real Estate  |  **Website:** https://www.pares.ai/
- **Classification:** ai_native_service  |  **Delivery band:** Insufficient Evidence  |  **Evidence:** medium

**1. What the company does.** AI-native real estate services firm (underwriting, BOVs, property management)

**2. Traditional service replaced.** Real estate analyst and property-management work: valuation, underwriting, broker opinion of value (BOV), decks, deal distribution

**3. Target customer and what they buy.** Real estate investors and operators. Completed real estate work product: underwritten deals, BOVs, decks and property management

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Underwriting** — '$2B+ Underwritten' with '10 min Underwriting' advertised; the firm performs valuation and underwriting as a service. | `ai` | https://www.pares.ai/ |
| 2 | **Comps and analysis** — Customer quote: 'PARES help provided me sales comps I haven't seen before. It suggested ways to increase additional income and items to renovate to save repair costs while achieving higher rents.' | `ai` | https://www.pares.ai/ |
| 3 | **Deal materials** — 'Valuation / Underwriting', 'OMs / BOVs / Decks', 'Deal Distribution'. | `ai` | https://www.pares.ai/ |
| 4 | **Property management** — 'Tenant portal & communication, Applications & leasing, Accounting & reporting, Automated notifications & reminders'. | `hybrid` | https://www.pares.ai/ |

**5. Where humans remain involved.** Unknown or insufficient evidence

**6. How the company makes money.** Not publicly disclosed; sold as an end-to-end workflow across underwriting, deals and property management

**7. Evidence — publicly reported metrics.**

- $2B+ underwritten
- 10 min underwriting
- Nationwide market coverage

**8. What remains unknown.**

- '$2B+ underwritten' has no published methodology or time frame
- Pricing not published
- Human involvement is not described on the captured pages

**Sources.** https://www.pares.ai/, https://www.ycombinator.com/companies/pares-ai  (last verified 2026-10-28)

---

### Patientdesk.ai

- **YC batch:** Winter 2026  |  **Industry:** Healthcare  |  **Website:** https://patientdesk.ai/
- **Classification:** hybrid  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** medium

**1. What the company does.** AI receptionist, scheduling and AI-native practice management for dental

**2. Traditional service replaced.** Dental front-desk work: answering calls, booking appointments, patient follow-up, plus practice-management software

**3. Target customer and what they buy.** Dental practices. A bundle: AI receptionist, online booking, patient follow-ups, marketing, and an AI-native PMS - 'all under one roof'

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Call answering and booking** — 'Incoming patient call Answered - "I'd like to book a check-up." - Booked into your PMS'. | `ai` | https://patientdesk.ai/ |
| 2 | **Online booking** — 'Patients book from your website, straight into your schedule.' | `ai` | https://patientdesk.ai/ |
| 3 | **Proactive PMS recommendations** — 'Tomorrow has 3.5 h of open chair time' with Approve/Edit - the PMS 'proposes the next action'. | `hybrid` | https://patientdesk.ai/ |
| 4 | **Patient follow-up** — 'Call answering and patient follow-up' handled by the AI receptionist. | `ai` | https://patientdesk.ai/ |

**5. Where humans remain involved.** Human-supervised AI execution (staff approve the PMS's proposed actions)

**6. How the company makes money.** Published pricing page (practice-level subscription); bundles scheduling, AI receptionist, follow-ups, booking, PMS, marketing, review automation and SEO

**7. Evidence — publicly reported metrics.**

- Named dental practice testimonials

**8. What remains unknown.**

- Sold as software (PMS plus AI receptionist) rather than a pure service - the practice still operates it
- Published price amounts were not captured
- No published automation rate

**Sources.** https://patientdesk.ai/, https://patientdesk.ai/pricing, https://www.ycombinator.com/companies/patientdeskai  (last verified 2026-10-28)

---

### Pollen

- **YC batch:** Winter 2026  |  **Industry:** B2B / Fintech  |  **Website:** https://www.pollen.cx/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI employees trained on a firm's workflows

**2. Traditional service replaced.** Repetitive knowledge work in wealth management, accounting/tax, private equity, insurance and family offices

**3. Target customer and what they buy.** Wealth management, accounting and tax, private equity, insurance, family offices. An AI employee ('Pollenator') trained on the firm's exact workflows that accepts work by email or chat

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Workflow training** — 'Give Paul examples of your workflows. Get them automated perfectly.' | `hybrid` | https://www.pollen.cx/ |
| 2 | **Document intake** — Inputs include Client_Statements.pdf, Risk_Profile.docx feeding a household master record (e.g. 'Client Walker Household, Assets $8.4M, Risk band B'). | `ai` | https://www.pollen.cx/ |
| 3 | **Delegation by email or chat** — 'Delegate like a teammate - Send work by email or chat, no special interface or prompting required.' | `ai` | https://www.pollen.cx/ |
| 4 | **Quality positioning** — 'Other AI leaves your team to check, correct, and finish the output' - Pollen positions its output as needing less rework. | `ai` | https://www.pollen.cx/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Not captured (pricing page exists); sold as hiring an AI employee

**7. Evidence — publicly reported metrics.**

- Documented workflow example producing a household master record

**8. What remains unknown.**

- Pricing not captured
- No published client outcomes or accuracy metrics
- The 'less rework than other AI' claim is a competitive assertion, not measured evidence

**Sources.** https://www.pollen.cx/, https://www.ycombinator.com/companies/pollen  (last verified 2026-10-28)

---

### Praxis

- **YC batch:** Fall 2026  |  **Industry:** Legal  |  **Website:** https://runpraxis.ai
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI agents running law firm operations (intake to collections)

**2. Traditional service replaced.** Law firm administrative operations: lead intake and qualification, client data and document collection, matter tracking, invoicing and collections

**3. Target customer and what they buy.** Law firms (founders and managing attorneys). 'Praxis is the AI that runs your law firm, from first inquiry to paid invoice' - the admin operation executed end to end

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Lead intake and qualification** — 'Every inquiry is answered in minutes and qualified against your rules'; 'Every lead answered, qualified and signed'. | `ai` | https://runpraxis.ai |
| 2 | **Client data and document collection** — 'Client data and documents, collected and verified'. | `ai` | https://runpraxis.ai |
| 3 | **Matter tracking** — 'Every matter moving, and your client sees it live'. | `ai` | https://runpraxis.ai |
| 4 | **Invoicing and collections** — 'Invoices sent and chased, revenue collected'. | `ai` | https://runpraxis.ai |
| 5 | **Lawyer supervision** — 'Agents do the admin end to end, and the lawyer supervises and approves every step'; 'Praxis does the work around the client, so your team can stay on the law.' | `human` | https://runpraxis.ai |

**5. Where humans remain involved.** AI-led execution with exception-based human review (lawyer supervises and approves every step)

**6. How the company makes money.** Not publicly disclosed ('Get early access'); sold as replacing law-firm admin headcount

**7. Evidence — publicly reported metrics.**

- Named testimonials from law firm founders (transactional law firm, New York)

**8. What remains unknown.**

- 'Approves every step' means human review is pervasive, not exception-based in practice
- Pricing not published
- Very early (Fall 2026)
- Does not perform legal work itself - it runs the firm's operations

**Sources.** https://runpraxis.ai, https://runpraxis.ai/security, https://www.ycombinator.com/companies/praxis  (last verified 2026-10-28)

---

### RamAIn

- **YC batch:** Winter 2026  |  **Industry:** B2B  |  **Website:** https://ramain.ai
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** Digital workers that operate portals and legacy systems (AI employees)

**2. Traditional service replaced.** Human back-office operators working inside portals, legacy systems and spreadsheets

**3. Target customer and what they buy.** Enterprises (mortgage lender, marketplace, industrial materials, B2B sourcing, healthcare billing, used-car marketplace cited). 'AI Employees with a computer to perform business tasks' - work performed inside the customer's systems

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Digital worker sign-in** — 'Digital workers sign in to your portals and legacy systems and do the manual work your team does today.' | `ai` | https://ramain.ai |
| 2 | **Task execution** — 'If your team does it on a computer, Ramain can do it.' | `ai` | https://ramain.ai |
| 3 | **Benchmarked performance** — Company benchmark: RamAIn completed 89% of 85 enterprise tasks at 1x cost, vs Claude Code 87% at 1.7x and Codex 86% at 3.3x. | `ai` | https://ramain.ai |
| 4 | **Human oversight** — The product is deployed as an AI employee alongside the customer's team; supervision detail is not published on the captured pages. | `human` | https://ramain.ai |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Not captured (pricing page exists); sold as AI employees replacing manual computer work

**7. Evidence — publicly reported metrics.**

- 89% of 85 enterprise tasks completed (RamAIn) vs 87% (Claude Code) and 86% (Codex)
- Cost per task: RamAIn 1x vs Claude Code 1.7x and Codex 3.3x
- Running daily work for a national mortgage lender and other named enterprise types

**8. What remains unknown.**

- The benchmark is self-run and compares agent harnesses rather than business outcomes
- Pricing not captured
- Named customers are described by category rather than company
- Human oversight model not documented

**Sources.** https://ramain.ai, https://ramain.ai/customers, https://www.ycombinator.com/companies/ramain  (last verified 2026-10-28)

---

### Rational

- **YC batch:** Summer 2026  |  **Industry:** Fintech / B2B  |  **Website:** https://rational.to
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** End-to-end agentic accounting service

**2. Traditional service replaced.** Accounting and tax function performed by accountants or an outsourced accounting firm

**3. Target customer and what they buy.** Startups and enterprise teams. 'End-to-end agentic accounting' - accounting work handed off with instant setup, 24/7 support and experts on demand

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Automatic onboarding** — 'Hand off your accounting and tax with instant setup / Automatic onboarding, 24/7 support, experts whenever you need.' | `hybrid` | https://rational.to |
| 2 | **Agentic execution** — 'Building AI employees for accounting'; 'End-to-end agentic accounting.' | `ai` | https://rational.to |
| 3 | **Accountant review of consequential decisions** — 'Consequential decisions belong with the accountant, with the source material and context close at hand.' | `human` | https://rational.to |
| 4 | **Team capacity review** — 'We'll walk through how Rational handles the work, where your team reviews, and what a first workflow could look like.' | `human` | https://rational.to |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Subscription: 'From $399/month with an annual agreement' (startup pricing)

**7. Evidence — publicly reported metrics.**

- Startup pricing from $399/month with an annual agreement

**8. What remains unknown.**

- Pricing threshold is public but the full price ladder is not
- No published automation rate or client count
- 'Zero-human accounting firm' appears in the YC one-liner but the site itself keeps accountants on consequential decisions

**Sources.** https://rational.to, https://rational.to/pricing, https://www.ycombinator.com/companies/rational  (last verified 2026-10-28)

---

### Relaw

- **YC batch:** Fall 2025  |  **Industry:** Legal  |  **Website:** https://www.relaw.ai
- **Classification:** ai_copilot_or_tool  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** Legal operating system / AI layer for law practices

**2. Traditional service replaced.** Fragmented law-practice software and manual matter administration (intake, documents, email, billing, trust accounting, follow-up)

**3. Target customer and what they buy.** Law practices. A legal operating system: intake, matter management, documents, email/calendar, time/billing/trust accounting, marketing and follow-up, with an agent that prepares the day

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Intake** — 'Intake - The story, captured'. | `ai` | https://www.relaw.ai |
| 2 | **Relationship context** — 'Messages - The relationship, connected'; 'Documents - Your expertise, applied'; 'Follow-through - The next step, ready'. | `ai` | https://www.relaw.ai |
| 3 | **Daily preparation agent** — 'An agent watches your email, matters, and client status, then prepares your day so the work keeps moving' - 'Email priorities with replies drafted' and 'Next steps grounded in your records'. | `ai` | https://www.relaw.ai |
| 4 | **White-glove setup** — 'White-glove setup / Complimentary training / Your templates, configured for you'. | `human` | https://www.relaw.ai |

**5. Where humans remain involved.** Human-led with AI assistance (the lawyer still does the legal work; the system prepares it)

**6. How the company makes money.** Software subscription (pricing page exists; amounts not captured)

**7. Evidence — publicly reported metrics.**

- Agent prepares a daily dashboard with drafted replies and next steps

**8. What remains unknown.**

- Explicitly a 'Legal Operating System' - a platform the firm operates, so this is a copilot/tool rather than a service that performs the legal work
- Pricing amounts not captured
- No published adoption metrics

**Sources.** https://www.relaw.ai, https://www.relaw.ai/pricing, https://www.ycombinator.com/companies/relaw  (last verified 2026-10-28)

---

### Rex

- **YC batch:** Summer 2026  |  **Industry:** B2B  |  **Website:** https://www.ycombinator.com/companies/rex
- **Classification:** ai_native_service  |  **Delivery band:** Insufficient Evidence  |  **Evidence:** low

**1. What the company does.** AI operations partner for enterprise order-to-cash

**2. Traditional service replaced.** Enterprise order-to-cash operations: order processing, invoicing, collections and cash application, often outsourced to shared-service centres or BPOs

**3. Target customer and what they buy.** Enterprises with complex order-to-cash operations. An operations partner that runs order-to-cash - an operations outcome rather than software

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Order-to-cash execution** — YC one-liner: 'AI operations partner for enterprise order-to-cash.' Detailed workflow not published on the captured pages. | `hybrid` | https://www.ycombinator.com/companies/rex |

**5. Where humans remain involved.** Unknown or insufficient evidence

**6. How the company makes money.** Not publicly disclosed

**7. Evidence.** No deployment metrics published.

**8. What remains unknown.**

- No company website content captured - the entry rests on the YC one-liner only
- No pricing, workflow or outcome detail available
- Flagged as a candidate requiring further research

**Sources.** https://www.ycombinator.com/companies/rex  (last verified 2026-10-28)

---

### RiskCube

- **YC batch:** Fall 2024  |  **Industry:** Insurance / Fintech  |  **Website:** https://riskcube.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** medium

**1. What the company does.** Commercial insurance brokerage for startups

**2. Traditional service replaced.** Startup commercial insurance brokerage and policy review work (D&O, cyber, E&O, GL etc.)

**3. Target customer and what they buy.** Startups closing enterprise deals, raising capital, or passing compliance reviews. Compared quotes from multiple carriers, purchased coverage, Certificates of Insurance, and managed policies/renewals

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Coverage requirement intake** — Founders describe contract/enterprise insurance requirements; RiskCube reviews contract requirements for vendor and client insurance terms. | `hybrid` | https://riskcube.com |
| 2 | **Market scan & quote comparison** — 'Our AI agents and licensed brokers scan the market's top-rated carriers to find the best quotes for your business.' | `hybrid` | https://riskcube.com |
| 3 | **Policy/exclusion review** — 'Without expert review, you won't know what's not covered until it's too late.' Expert review of exclusions is offered as a service. | `human` | https://riskcube.com |
| 4 | **Bind & issue COI** — 'purchase coverage digitally, generate Certificates of Insurance, and manage policies and renewals, all in one place' - often in about a day. | `hybrid` | https://riskcube.com |
| 5 | **Licensed broker sign-off** — 'Speak with a licensed broker'; licensed expertise is presented alongside the agentic platform. | `human` | https://riskcube.com |

**5. Where humans remain involved.** Human-supervised AI execution (AI agents + licensed brokers working together)

**6. How the company makes money.** Brokerage commission on placed premium; digital self-serve purchasing plus expert review

**7. Evidence — publicly reported metrics.**

- COIs often in about a day
- Case study: Series A fintech, 60% D&O savings with more coverage limit
- Example comparison shown: best-fit saves $2,400/yr

**8. What remains unknown.**

- 'AI-native' is the company's own label; the split of AI vs broker work is not quantified
- The precise automation rate of quoting/binding is undisclosed
- Commission structure not published

**Sources.** https://riskcube.com, https://riskcube.com/faq, https://www.ycombinator.com/companies/riskcube  (last verified 2026-10-28)

---

### Riviera

- **YC batch:** Winter 2025  |  **Industry:** B2B / Hospitality  |  **Website:** https://www.withriviera.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI hotel employee - calls, dining orders and reservations

**2. Traditional service replaced.** Hotel front-desk and reservations phone handling: guest calls, dining orders, reservations, multilingual guest questions

**3. Target customer and what they buy.** Hotels. 'AI Agents for Hospitality' that handle guest calls, dining orders and reservations around the clock

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Guest call answering** — 'AI agents that handle calls, dining orders, and reservations in any language, around the clock.' | `ai` | https://www.withriviera.com |
| 2 | **Language detection and switching** — 'Riviera detects the guest's language in real time and switches fluently'; 'If a guest switches languages, the agent follows seamlessly.' | `ai` | https://www.withriviera.com |
| 3 | **Guest intelligence** — Imports guest guides (e.g. 'Grand Palais Guest Guide.pdf') to ground answers. | `ai` | https://www.withriviera.com |
| 4 | **Human handoff** — 'When a guest needs a human, Riviera transfers with the full conversation and context already loaded' - 'Your staff picks up with the full story.' | `human` | https://www.withriviera.com |

**5. Where humans remain involved.** AI-led execution with exception-based human review (smart transfer to staff)

**6. How the company makes money.** Not captured (pricing page exists on the site); sold as an 'AI hotel employee'

**7. Evidence — publicly reported metrics.**

- Multilingual with mid-call language switching
- Always-on coverage

**8. What remains unknown.**

- Pricing not captured
- No published call-volume, containment or accuracy metrics
- The handoff design means humans remain a first-class path

**Sources.** https://www.withriviera.com, https://www.ycombinator.com/companies/riviera  (last verified 2026-10-28)

---

### SafetyKit

- **YC batch:** Summer 2023  |  **Industry:** B2B / Compliance  |  **Website:** https://www.safetykit.com/
- **Classification:** ai_copilot_or_tool  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** Trust and safety decisioning (API plus expert labelling)

**2. Traditional service replaced.** Manual trust-and-safety review and generic abuse-detection models

**3. Target customer and what they buy.** Trust and Safety teams at marketplaces and platforms. Decision models via API and/or labelled datasets to train the customer's own models; the customer operates the enforcement

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Content and entity evaluation** — Identifies hazardous materials, harmful websites and domains, transaction laundering, evaluating 'site content, ownership, and payment flows'. | `ai` | https://www.safetykit.com/ |
| 2 | **Model delivery** — 'Leverage our decision models out-of-the-box via API. Or train your own models on our labeled datasets.' | `ai` | https://www.safetykit.com/ |
| 3 | **Expert labelling** — 'Labeled by experts and specialists to ensure the accuracy needed for Trust & Safety policies and enforcement.' | `human` | https://www.safetykit.com/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review (human experts label data; the customer's team enforces)

**6. How the company makes money.** API/usage-based and dataset licensing; the customer still performs enforcement

**7. Evidence — publicly reported metrics.**

- Expert-labelled datasets
- 'The best data builds the best models'

**8. What remains unknown.**

- Sold as data/models via API, so the customer performs the work - included here as a comparison case, not as an AI-native service
- Pricing not published

**Sources.** https://www.safetykit.com/, https://www.safetykit.com/product, https://www.ycombinator.com/companies/safetykit  (last verified 2026-10-28)

---

### Sintropix

- **YC batch:** Fall 2026  |  **Industry:** Fintech / B2B  |  **Website:** https://sintropix.com/
- **Classification:** ai_native_service  |  **Delivery band:** Insufficient Evidence  |  **Evidence:** low

**1. What the company does.** Autonomous multi-country accounting / finance ERP as a service

**2. Traditional service replaced.** Multi-country bookkeeping and financial close performed by an accounting firm or in-house finance team

**3. Target customer and what they buy.** Multi-country LATAM startups. Closed books and financial clarity - 'We close your books and give you financial clarity while you run your business'

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Automated close** — YC one-liner: 'Autonomous accounting platform for global companies'; the site describes closing the books while the client runs the business. | `ai` | https://sintropix.com/ |
| 2 | **Consolidated reporting** — Live consolidated snapshot across five countries (cash, ARR, burn, runway) with an assistant ('Erwin') answering questions. | `ai` | https://sintropix.com/ |

**5. Where humans remain involved.** Unknown or insufficient evidence

**6. How the company makes money.** Not publicly disclosed (ERP/finance service framing)

**7. Evidence — publicly reported metrics.**

- Illustrative dashboard: consolidated cash $1.37M, ARR $4.2M, monthly burn $312K, 14 months runway

**8. What remains unknown.**

- Site content captured is largely in Spanish; product detail is thin in the captured pages
- No pricing
- No published automation rate or customer outcomes
- Very early (Fall 2026)

**Sources.** https://sintropix.com/, https://www.ycombinator.com/companies/sintropix  (last verified 2026-10-28)

---

### Strada

- **YC batch:** Summer 2023  |  **Industry:** Insurance / B2B  |  **Website:** https://www.getstrada.com/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** high

**1. What the company does.** AI agents for insurance operations (carrier / TPA / MGA back office)

**2. Traditional service replaced.** Outsourced insurance back-office operations: endorsement processing, document processing, carrier portal navigation, COI issuance, claims processing support, billing inquiries

**3. Target customer and what they buy.** Insurance carriers, TPAs and MGAs. A running operation - agents that execute insurance back-office workflows end to end inside the customer's own systems

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Workflow ingestion** — Agents handle endorsement processing, browser automation, document processing and carrier portal navigation. | `ai` | https://www.getstrada.com/ |
| 2 | **Carrier portal navigation** — 'Carrier portal navigation' listed as an agent capability, i.e. agents operate external insurer portals. | `ai` | https://www.getstrada.com/ |
| 3 | **COI issuance & claims support** — 'COI issuance', 'Claims processing support' executed by agents. | `ai` | https://www.getstrada.com/ |
| 4 | **Governance & audit trail** — 'Every agent runs inside the permissions your team already uses, and leaves a record a person can read'; access scoped per role, every action logged. | `hybrid` | https://www.getstrada.com/ |
| 5 | **Escalation & handover** — 'Escalation thresholds your team defines'; 'Handover passes the whole transcript to a person'. | `human` | https://www.getstrada.com/ |
| 6 | **Testing & QA** — 'Run a change against real scenarios before a customer ever hears it'. | `hybrid` | https://www.getstrada.com/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** Managed service / operations outsourcing replacement (commercial terms not published)

**7. Evidence — publicly reported metrics.**

- 70% handle time reduction on every submission that comes in
- 98% data accuracy across policy and document processing
- Metrics measured across live deployments with carriers, TPAs and MGAs

**8. What remains unknown.**

- Pricing model not disclosed
- Which lines of business are live vs planned is not fully enumerated
- '70% handle time reduction' has no published methodology

**Sources.** https://www.getstrada.com/, https://www.getstrada.com/customers, https://www.ycombinator.com/companies/strada  (last verified 2026-10-28)

---

### Superside

- **YC batch:** Winter 2016  |  **Industry:** B2B / Creative  |  **Website:** http://www.superside.com
- **Classification:** ai_enabled_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** high

**1. What the company does.** AI-amplified creative-as-a-service (design and video subscription)

**2. Traditional service replaced.** Creative and design agencies, in-house creative teams, and freelance design marketplaces

**3. Target customer and what they buy.** Enterprise marketing and creative teams (400+ top global brands cited). A subscription to a senior creative team that delivers design and video work, with AI built into the workflow

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Team configuration** — 'The same AI-native team every month, configured around your use case and live in about three weeks.' | `human` | http://www.superside.com |
| 2 | **Brand modelling** — 'Brand Brain, custom brand models and AI workflows are built into the setup'. | `ai` | http://www.superside.com |
| 3 | **Creative production** — Design, video and motion production delivered by 'Every path is a real senior team with AI built in'. | `human` | http://www.superside.com |
| 4 | **AI-assisted throughput** — The site reports '12K+ AI-powered projects' and a '90%+ AI-certified creative team', i.e. AI raises human throughput rather than replacing the human. | `hybrid` | http://www.superside.com |

**5. Where humans remain involved.** Human-led with AI assistance (senior creative teams deliver; AI amplifies them)

**6. How the company makes money.** Creative-as-a-service subscription: flexible subscription, dedicated team, or fixed-scope projects; 'far better value than holding an agency on retainer'

**7. Evidence — publicly reported metrics.**

- 200K+ projects delivered
- 12K+ AI-powered projects
- 90%+ AI-certified creative team
- 95%+ projects rated 4+ stars in the past year
- 400+ top global brands

**8. What remains unknown.**

- Delivery remains fundamentally human - included here as an AI-enabled service comparison, not an AI-native service
- The 'AI-certified creative team' metric describes training, not autonomous delivery
- Subscription prices are not published

**Sources.** http://www.superside.com, http://www.superside.com/case-studies, https://www.ycombinator.com/companies/superside  (last verified 2026-10-28)

---

### Taiga

- **YC batch:** Spring 2026  |  **Industry:** Healthcare  |  **Website:** https://taigabilling.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** high

**1. What the company does.** End-to-end medical billing partner (coding, claims, appeals)

**2. Traditional service replaced.** Medical billing done in-house or by an external billing company: coding, claim scrubbing, submission, denial appeals

**3. Target customer and what they buy.** Medical practices (EMR-integrated). 'Taiga handles coding, claims, and appeals end-to-end' - the complete billing loop, with a portal for visibility

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **EHR access** — 'From EHR access to reconciliation, each step feeds the next so payer rules are caught earlier over time.' | `hybrid` | https://taigabilling.com |
| 2 | **Coding and claim checks** — Agent analysis checks claim fields, adds a missing middle initial, checks the NPPES registry, and applies payer-specific rules ('Required for Aetna 99214-25'). | `ai` | https://taigabilling.com |
| 3 | **Claim submission** — 'Ready to submit' after rules analysis; claims move to submission. | `ai` | https://taigabilling.com |
| 4 | **Physician code approval** — 'Every generated code is reviewed and approved by your physicians before submission.' | `human` | https://taigabilling.com |
| 5 | **Denial appeals and reconciliation** — 'They've successfully secured payments on several previously rejected claims by resolving complex issues that had persisted for months.' | `hybrid` | https://taigabilling.com |

**5. Where humans remain involved.** AI-led execution with exception-based human review (physician approves codes)

**6. How the company makes money.** Medical billing service (typical RCM percentage-of-collections economics; not published)

**7. Evidence — publicly reported metrics.**

- Case study: payments secured on previously rejected claims outstanding for months
- Named customer testimonials

**8. What remains unknown.**

- Pricing not published
- Physician approval of generated codes is a hard human step
- No aggregate accuracy or collection-rate statistics published

**Sources.** https://taigabilling.com, https://taigabilling.com/case-studies, https://www.ycombinator.com/companies/taiga  (last verified 2026-10-28)

---

### The Vibe Company

- **YC batch:** Winter 2024  |  **Industry:** B2B  |  **Website:** https://thevibecompany.co
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** high

**1. What the company does.** AI-native product studio and agent operator

**2. Traditional service replaced.** Software development agencies and internal engineering/ops teams; also manual customer-support handling

**3. Target customer and what they buy.** Companies needing products built, agents operated, or teams trained. Delivered work: shipped products, agents run inside the client's company, and advisory/training

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Build** — 'Build AI products and internal tools, end-to-end.' | `hybrid` | https://thevibecompany.co |
| 2 | **Operate** — 'Operate Agents inside your company.' | `ai` | https://thevibecompany.co |
| 3 | **Advise** — 'Strategy, training, and the AI playbook for your team.' | `human` | https://thevibecompany.co |
| 4 | **Case study - support drafting** — For LocService: 'Hundreds of tickets a day, our drafts used on 87% of them', with 'a support agent reviews the draft, fixes it if needed, then sends it.' | `hybrid` | https://thevibecompany.co/case-studies |
| 5 | **Case study - product build** — For a healthcare client: shipped a caregiver app, a nurse CRM (Lifeline) and the API tying them together in two months. | `hybrid` | https://thevibecompany.co/case-studies |

**5. Where humans remain involved.** Human-supervised AI execution (agents produce drafts; human staff review and send)

**6. How the company makes money.** Agency/studio engagement model ('we build, we run, we train'); the company states it runs on AI itself 'so you ship faster and for far less than a traditional team'

**7. Evidence — publicly reported metrics.**

- 87% of LocService support tickets answered with AI drafts
- Two-month build of caregiver app, nurse CRM and API for a healthcare client
- 165-question caregiver assessment converted into an action plan

**8. What remains unknown.**

- Agency model - the human team is the delivery mechanism, with AI as leverage
- Pricing not published
- Case studies are self-published

**Sources.** https://thevibecompany.co, https://thevibecompany.co/case-studies, https://www.ycombinator.com/companies/the-vibe-company  (last verified 2026-10-28)

---

### TrueMile

- **YC batch:** Fall 2026  |  **Industry:** Industrials / Logistics  |  **Website:** https://TrueMile.AI/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** low

**1. What the company does.** AI-native trucking company

**2. Traditional service replaced.** Trucking carrier operations: sourcing freight, dispatching, driver management and customer updates

**3. Target customer and what they buy.** Shippers needing freight moved. Freight moved - a trucking service, not software

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Freight sourcing** — 'From finding freight to keeping customers updated, our AI agents connect the work across the fleet.' | `ai` | https://TrueMile.AI/ |
| 2 | **Operations coordination** — 'Our AI agents put it into motion' - agents connect work across the fleet. | `ai` | https://TrueMile.AI/ |
| 3 | **Driving** — The site explicitly states 'Human drivers', i.e. the physical work is human. | `human` | https://TrueMile.AI/ |

**5. Where humans remain involved.** Human-supervised AI execution (AI runs coordination; human drivers do the physical work)

**6. How the company makes money.** Freight/trucking revenue (per-load economics); the company operates as a carrier rather than selling software

**7. Evidence.** No deployment metrics published.

**8. What remains unknown.**

- Thin public detail beyond positioning
- No pricing, volume or fleet metrics published
- Very early (Fall 2026)
- The physical work (driving) remains human

**Sources.** https://TrueMile.AI/, https://www.ycombinator.com/companies/truemile  (last verified 2026-10-28)

---

### Vector Legal

- **YC batch:** Winter 2026  |  **Industry:** Legal  |  **Website:** https://vectorlegal.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** AI-native law firm for tech companies

**2. Traditional service replaced.** Big Law outside counsel for tech companies and their investors

**3. Target customer and what they buy.** Tech companies and their investors. Legal services: 'Experienced attorneys and proprietary AI for tech companies and their investors'; fractional general counsel retainers; outcome-based pricing where it fits

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **First pass by software** — 'Most work is billed hourly, at about half the cost of Big Law, because the firm's software takes the first pass and attorneys spend their time on judgment.' | `ai` | https://vectorlegal.com |
| 2 | **Attorney judgment** — Attorneys apply judgment on the reviewed work; engagements run as fractional GC retainers or matter-based. | `human` | https://vectorlegal.com |
| 3 | **Intake** — 'start an engagement through the intake form at /contact'. | `hybrid` | https://vectorlegal.com |

**5. Where humans remain involved.** Human-led with AI assistance (software takes the first pass; attorneys deliver judgment)

**6. How the company makes money.** Hourly billing 'at about half the cost of Big Law', plus fractional GC retainers and outcome-based pricing where it fits

**7. Evidence — publicly reported metrics.**

- Billed hourly at about half the cost of Big Law
- Outcome-based pricing available where it fits

**8. What remains unknown.**

- 'About half the cost' has no published benchmark or methodology
- The proprietary AI is not described in operational detail
- Client count and matter volume not published

**Sources.** https://vectorlegal.com, https://vectorlegal.com/about, https://www.ycombinator.com/companies/vector-legal  (last verified 2026-10-28)

---

### Velos

- **YC batch:** Winter 2023  |  **Industry:** Insurance / B2B  |  **Website:** https://www.tryvelos.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** high

**1. What the company does.** AI BPO for specialty insurance MGAs and program managers

**2. Traditional service replaced.** Offshore/captive BPO back-office: servicing, bordereaux reporting, data entry, reconciliation, document review, exception handling

**3. Target customer and what they buy.** Specialty insurance MGAs and program managers. A managed back-office operation delivered as auditable software-driven workflows

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Process discovery** — 'Velos learns the nuances of your process and turns them into auditable workflows using AI + code'. | `hybrid` | https://www.tryvelos.com |
| 2 | **Validation against real data** — 'Velos tests against your real data, learns your edge cases, and follows your business rules.' | `hybrid` | https://www.tryvelos.com |
| 3 | **Back-office execution** — Data entry, reconciliation, document review and exception handling run as automated workflows. | `ai` | https://www.tryvelos.com |
| 4 | **Bordereaux reporting** — Monthly bordereaux built from 200+ trucking dealership submissions in many formats. | `ai` | https://www.tryvelos.com/customers |
| 5 | **Managed end-to-end delivery** — 'We design, deploy, and manage the automation end to end'. | `hybrid` | https://www.tryvelos.com |

**5. Where humans remain involved.** AI-led execution with exception-based human review

**6. How the company makes money.** AI BPO - sold as managed capacity that reduces the expense ratio vs outsourced headcount (per-unit pricing not published)

**7. Evidence — publicly reported metrics.**

- 98% accuracy achieved
- 6 days faster reporting time
- 0 added headcount
- Bordereaux built from 200+ dealerships' data

**8. What remains unknown.**

- Customer metrics are from a single published case study
- Pricing model not disclosed
- Human escalation volume not quantified

**Sources.** https://www.tryvelos.com, https://www.tryvelos.com/customers, https://www.ycombinator.com/companies/velos  (last verified 2026-10-28)

---

### Veltha

- **YC batch:** Fall 2026  |  **Industry:** Insurance  |  **Website:** https://veltha.ai/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Led Service Delivery  |  **Evidence:** medium

**1. What the company does.** AI claims adjusting (TPA-style whole-file review)

**2. Traditional service replaced.** Claims adjuster file review: reading claim documents, checking coverage against policy, drafting the decision

**3. Target customer and what they buy.** Insurers and MGAs (starting with crop insurance). A reviewed claim file with a drafted payment recommendation, produced from the raw claim documents

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Whole-file intake** — 'Photos, video, and scans dropped in and sorted by type' - any data in the file is ingested. | `ai` | https://veltha.ai/ |
| 2 | **Policy check** — 'Insured, dates, covered property, cause of loss, notice, and coverage compared against the policy.' | `ai` | https://veltha.ai/ |
| 3 | **Error fixing & line checking** — 'takes any data in the file ... checks each line against the policy, fixes the errors, and lines up the decision'. | `ai` | https://veltha.ai/ |
| 4 | **Decision drafting** — 'draft the decision for your adjuster to approve'. | `hybrid` | https://veltha.ai/ |
| 5 | **Adjuster approval** — The drafted decision is explicitly 'for your adjuster to approve' - a licensed human retains authority. | `human` | https://veltha.ai/ |

**5. Where humans remain involved.** AI-led execution with exception-based human review (adjuster approves the drafted decision)

**6. How the company makes money.** Not publicly disclosed; positioned as replacing the cost of claim file handling for carriers/MGAs

**7. Evidence — publicly reported metrics.**

- Illustrative crop claim: recommendation of a $27,355.03 payment with the math and each check tied to a source page

**8. What remains unknown.**

- Illustrative walkthrough, not a customer outcome
- Pricing undisclosed
- Whether the adjuster must re-check every file or only flagged ones is not stated
- Very early (Fall 2026 batch)

**Sources.** https://veltha.ai/, https://www.ycombinator.com/companies/veltha  (last verified 2026-10-28)

---

### Wingman Law

- **YC batch:** Fall 2026  |  **Industry:** Legal  |  **Website:** https://www.wingmanlaw.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Assisted  |  **Evidence:** medium

**1. What the company does.** AI-native personal injury law firm

**2. Traditional service replaced.** Personal injury law firm services for car accident claimants (case evaluation, demand, negotiation with insurers)

**3. Target customer and what they buy.** Personal injury claimants (California), including non-English speakers (Korean, Spanish, Vietnamese). Legal representation on contingency: 'No legal fees unless you win'

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Free case review** — 'Free Case Review' intake for prospective claimants. | `hybrid` | https://www.wingmanlaw.com |
| 2 | **Case data systems** — 'We turn claim data, policy language, medical evidence, and insurer behavior into systems that help our attorneys build sharper cases and challenge low offers.' | `ai` | https://www.wingmanlaw.com |
| 3 | **Case outcome modelling** — 'Gathering the case constellation' - an interface showing injury/outcome/year drawn from publicly available litigated-case data. | `ai` | https://www.wingmanlaw.com |
| 4 | **Attorney case work** — Attorneys build cases and challenge low offers; the firm describes itself as 'Firm engineered to fight insurance'. | `human` | https://www.wingmanlaw.com |

**5. Where humans remain involved.** Human-led with AI assistance (attorneys remain the delivery mechanism; AI supplies case analytics)

**6. How the company makes money.** Contingency fee: 'No upfront attorney's fees, and we only collect a fee if we recover money for you'

**7. Evidence — publicly reported metrics.**

- Multilingual intake (Korean, Spanish, Vietnamese)
- No upfront fees

**8. What remains unknown.**

- The site is a marketing/lead-gen surface; the AI stack is not described in operational detail
- No published outcome or settlement metrics
- Very early (Fall 2026)
- Legal services are regulated; attorney licensing detail is not published on the captured pages

**Sources.** https://www.wingmanlaw.com, https://www.ycombinator.com/companies/wingman-law  (last verified 2026-10-28)

---

### Zomma

- **YC batch:** Summer 2026  |  **Industry:** B2B / Fintech  |  **Website:** https://zommalabs.com
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** medium

**1. What the company does.** Computer-use agents for enterprise operations (AI BPO for financial services)

**2. Traditional service replaced.** Financial-services back-office and operations outsourcing: work performed in portals, registries, case managers and internal systems

**3. Target customer and what they buy.** Financial services and other enterprises with operations that 'can't fail'. Operations work executed by computer-use agents, validated on the customer's own past cases before going live

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Agent connection** — 'Zomma builds computer-use agents for the enterprise'; 'Connect - Agents with their own computers.' | `ai` | https://zommalabs.com |
| 2 | **Private benchmark validation** — 'Each one is proven on a private benchmark from your own past cases before it goes live, and again after every change'; 'We run it on work your team has already completed and compare its output with your team's decisions, item by item.' | `hybrid` | https://zommalabs.com |
| 3 | **Execution in customer systems** — 'bank and custodian portals, company registries, case managers, ticketing tools, PDFs, statements and spreadsheets, and your own internal systems, under credentials you control'. | `ai` | https://zommalabs.com |
| 4 | **Recommendation only** — 'Even live, it only recommends; your team makes every determination, and every step is recorded so the reviewer can see what was checked, what was found and why.' | `human` | https://zommalabs.com |

**5. Where humans remain involved.** Human-supervised AI execution (agents recommend; the customer's team makes every determination)

**6. How the company makes money.** Not publicly disclosed; positioned as an 'AI BPO for financial services, run by computer-use agents'

**7. Evidence — publicly reported metrics.**

- Private benchmark validation against the customer's own historical cases
- Full step-level audit records for reviewers

**8. What remains unknown.**

- 'Only recommends' means the customer's humans still make every determination
- Pricing not published
- No published client count or accuracy figures
- Very early (Summer 2026)

**Sources.** https://zommalabs.com, https://zommalabs.com/security, https://www.ycombinator.com/companies/zomma  (last verified 2026-10-28)

---

### throxy

- **YC batch:** Spring 2025  |  **Industry:** B2B  |  **Website:** https://throxy.com/
- **Classification:** ai_native_service  |  **Delivery band:** AI-Executed, Human-Supervised  |  **Evidence:** medium

**1. What the company does.** AI-native sales development agency (B2B outbound)

**2. Traditional service replaced.** B2B outbound sales development: hiring and training SDRs, list building, copywriting, sequencing and calling

**3. Target customer and what they buy.** B2B companies needing outbound pipeline. Booked meetings - 'throxy does the work for you' as a sales agency, with no SDRs to hire

**4. How the service is delivered now (workflow map).**

| # | Stage | Execution | Evidence |
|---|---|---|---|
| 1 | **Data discovery** — 'We run your entire outbound using our own custom-built tech that uncovers niche-specific data'. | `ai` | https://throxy.com/ |
| 2 | **Messaging at scale** — 'delivers unique messaging at scale, and keeps your emails landing in inboxes'. | `ai` | https://throxy.com/ |
| 3 | **Calling** — '71% More meetings with calling added' - calling is part of the delivered service. | `hybrid` | https://throxy.com/ |
| 4 | **Human SDR layer** — The YC one-liner reads 'Vertical AI agents running B2B outbound on autopilot, with human SDRs', i.e. humans remain part of delivery. | `human` | https://www.ycombinator.com/companies/throxy |

**5. Where humans remain involved.** Human-supervised AI execution (AI agents run outbound; human SDRs are part of the service)

**6. How the company makes money.** Agency retainer/performance model; positions against the cost of hiring and training SDRs ('0 People you need to hire or train')

**7. Evidence — publicly reported metrics.**

- 71% more meetings with calling added
- 121% more meetings booked per week since Maestro
- 11% booking rate on calls over 2 minutes
- 0 people you need to hire or train
- 12 meetings in 20 days for a named client in December

**8. What remains unknown.**

- Metrics are customer testimonials without published methodology
- The 'human SDRs' element means delivery is not fully autonomous
- Pricing not published
- 'First AI-native sales agency' is a self-applied label

**Sources.** https://throxy.com/, https://www.ycombinator.com/companies/throxy  (last verified 2026-10-28)

---
