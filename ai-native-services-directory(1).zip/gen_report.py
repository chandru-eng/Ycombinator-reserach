import json,csv,datetime
c=json.load(open('data/companies.json'))
def band(x):
    if x['classification'] in ('ai_copilot_or_tool','ai_enabled_service'): return 'AI-Assisted'
    s=x.get('autonomy_score',0)
    return {5:'Predominantly Autonomous',4:'AI-Led Service Delivery',3:'AI-Executed, Human-Supervised',2:'AI-Assisted'}.get(s,'Insufficient Evidence')
L=[]
w=L.append
w("# AI-Native Service Companies in the Y Combinator Ecosystem")
w("")
w("Research dataset and analysis. Generated %s. All metrics are company-published claims." % datetime.date(2026,10,28))
w("")
w("**Framework (from the YC RFS essay by Gustaf Alströmer):** Traditional Service → SaaS Software → AI Copilot → **AI-Native Service**.")
w("")
from collections import Counter
w("## Coverage")
w("")
w("| Metric | Count |")
w("|---|---|")
w("| YC companies screened | 6,349 |")
w("| Keyword candidates | 1,589 |")
w("| Shortlisted for review | 77 |")
w("| Fully investigated and classified | %d |" % len(c))
for k,v in Counter(x['classification'] for x in c).most_common():
    w("| — %s | %d |" % (k,v))
w("")
w("## Deliverable A — Company directory")
w("")
w("| Company | Batch | Industry | Classification | Delivery band | Evidence | Website |")
w("|---|---|---|---|---|---|---|")
for x in sorted(c,key=lambda z:(-(z.get('autonomy_score') or 0),z['company_name'])):
    w("| %s | %s | %s | %s | %s | %s | %s |" % (x['company_name'],x['yc_batch'],x['industry'],x['classification'],band(x),x['strength_of_evidence'],x['website']))
w("")
w("## Deliverable B & C — Deep dives and service delivery workflow maps")
w("")
for x in sorted(c,key=lambda z:z['company_name']):
    w("### %s" % x['company_name'])
    w("")
    w("- **YC batch:** %s  |  **Industry:** %s  |  **Website:** %s" % (x['yc_batch'],x['industry'],x['website']))
    w("- **Classification:** %s  |  **Delivery band:** %s  |  **Evidence:** %s" % (x['classification'],band(x),x['strength_of_evidence']))
    w("")
    w("**1. What the company does.** %s" % x['service_category'])
    w("")
    w("**2. Traditional service replaced.** %s" % x['traditional_service_replaced'])
    w("")
    w("**3. Target customer and what they buy.** %s. %s" % (x['target_customer'],x['customer_purchases']))
    w("")
    w("**4. How the service is delivered now (workflow map).**")
    w("")
    w("| # | Stage | Execution | Evidence |")
    w("|---|---|---|---|")
    for i,s in enumerate(x.get('ai_workflow',[]),1):
        w("| %d | **%s** — %s | `%s` | %s |" % (i,s['step'],s['description'],s['execution_mode'],s.get('evidence_url','')))
    w("")
    w("**5. Where humans remain involved.** %s" % x['human_involvement'])
    w("")
    w("**6. How the company makes money.** %s" % x['business_model'])
    w("")
    if x.get('publicly_reported_metrics'):
        w("**7. Evidence — publicly reported metrics.**")
        w("")
        for m in x['publicly_reported_metrics']: w("- %s" % m)
        w("")
    else:
        w("**7. Evidence.** No deployment metrics published.")
        w("")
    if x.get('limitations'):
        w("**8. What remains unknown.**")
        w("")
        for m in x['limitations']: w("- %s" % m)
        w("")
    w("**Sources.** %s  (last verified %s)" % (", ".join(x['sources']),x['last_verified']))
    w("")
    w("---")
    w("")
json.dump(c,open('data/companies.json','w'),indent=1)
open('REPORT.md','w').write("\n".join(L))
print("REPORT.md lines:",len(L))
# CSV
with open('companies.csv','w',newline='') as f:
    wr=csv.writer(f)
    wr.writerow(['company','batch','website','industry','service_category','classification','delivery_band','human_involvement','evidence','traditional_service_replaced','target_customer','customer_purchases','business_model','ai_steps','human_steps','hybrid_steps','sources'])
    for x in c:
        wf=x.get('ai_workflow',[])
        wr.writerow([x['company_name'],x['yc_batch'],x['website'],x['industry'],x['service_category'],x['classification'],band(x),x['human_involvement'],x['strength_of_evidence'],x['traditional_service_replaced'],x['target_customer'],x['customer_purchases'],x['business_model'],
            sum(1 for s in wf if s['execution_mode']=='ai'),sum(1 for s in wf if s['execution_mode']=='human'),sum(1 for s in wf if s['execution_mode']=='hybrid')," | ".join(x['sources'])])
print("CSV written")
